import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { AuthProvider } from "@/contexts/auth-context"
import { CartProvider } from "@/contexts/cart-context"
import Header from "@/components/header"
import { ActivityTrackerSafe } from "@/components/activity-tracker-safe"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Xillusions - Fashion E-commerce",
  description: "Custom fashion e-commerce platform",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <AuthProvider>
            <CartProvider>
              <Header />
              {children}
              <Toaster />
            </CartProvider>
          </AuthProvider>
        </ThemeProvider>
        {/* Activity tracking that doesn't depend on auth context */}
        <ActivityTrackerSafe />
      </body>
    </html>
  )
}


import './globals.css'