import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search } from "lucide-react"
import Link from "next/link"

// Mock order data
const orders = [
  {
    id: "XL2023405",
    date: "April 12, 2023",
    status: "Shipped",
    statusColor: "blue",
    paymentStatus: "Paid",
    paymentStatusColor: "green",
    total: 67.06,
    items: 2,
  },
  {
    id: "XL2023389",
    date: "March 28, 2023",
    status: "Delivered",
    statusColor: "green",
    paymentStatus: "Paid",
    paymentStatusColor: "green",
    total: 94.32,
    items: 3,
  },
  {
    id: "XL2023356",
    date: "February 15, 2023",
    status: "Delivered",
    statusColor: "green",
    paymentStatus: "Paid",
    paymentStatusColor: "green",
    total: 128.75,
    items: 4,
  },
  {
    id: "XL2023312",
    date: "January 3, 2023",
    status: "Delivered",
    statusColor: "green",
    paymentStatus: "Paid",
    paymentStatusColor: "green",
    total: 45.99,
    items: 1,
  },
  {
    id: "XL2022298",
    date: "December 18, 2022",
    status: "Delivered",
    statusColor: "green",
    paymentStatus: "Paid",
    paymentStatusColor: "green",
    total: 86.5,
    items: 2,
  },
  {
    id: "XL2022287",
    date: "December 5, 2022",
    status: "Cancelled",
    statusColor: "red",
    paymentStatus: "Refunded",
    paymentStatusColor: "yellow",
    total: 59.99,
    items: 1,
  },
]

export default function OrdersPage() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <h1 className="text-3xl font-bold mb-8">My Orders</h1>

      <div className="bg-white rounded-lg shadow-sm p-6">
        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input placeholder="Search orders by ID or product" className="pl-10" />
          </div>
          <Tabs defaultValue="all" className="w-full sm:w-auto">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="processing">Processing</TabsTrigger>
              <TabsTrigger value="shipped">Shipped</TabsTrigger>
              <TabsTrigger value="delivered">Delivered</TabsTrigger>
              <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 font-medium">Order ID</th>
                <th className="text-left py-3 px-4 font-medium">Date</th>
                <th className="text-left py-3 px-4 font-medium">Status</th>
                <th className="text-left py-3 px-4 font-medium">Payment</th>
                <th className="text-left py-3 px-4 font-medium">Items</th>
                <th className="text-right py-3 px-4 font-medium">Total</th>
                <th className="text-center py-3 px-4 font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} className="border-b hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <Link href={`/orders/${order.id}`} className="font-medium text-primary hover:underline">
                      #{order.id}
                    </Link>
                  </td>
                  <td className="py-4 px-4 text-muted-foreground">{order.date}</td>
                  <td className="py-4 px-4">
                    <Badge
                      variant="outline"
                      className={`bg-${order.statusColor}-50 text-${order.statusColor}-600 hover:bg-${order.statusColor}-50`}
                    >
                      {order.status}
                    </Badge>
                  </td>
                  <td className="py-4 px-4">
                    <Badge
                      variant="outline"
                      className={`bg-${order.paymentStatusColor}-50 text-${order.paymentStatusColor}-600 hover:bg-${order.paymentStatusColor}-50`}
                    >
                      {order.paymentStatus}
                    </Badge>
                  </td>
                  <td className="py-4 px-4">{order.items}</td>
                  <td className="py-4 px-4 text-right font-medium">${order.total.toFixed(2)}</td>
                  <td className="py-4 px-4 text-center">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/orders/${order.id}`}>View</Link>
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex justify-between items-center mt-6">
          <p className="text-sm text-muted-foreground">Showing 1-6 of 6 orders</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" disabled>
              Next
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
