"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useCart } from "@/contexts/cart-context"

type ProductCardButtonsProps = {
  product: {
    id: string
    name: string
    price: number
    image: string
  }
}

export function ProductCardButtons({ product }: ProductCardButtonsProps) {
  const [isWishlisted, setIsWishlisted] = useState(false)
  const { addItem } = useCart()
  const { toast } = useToast()

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: 1,
      image: product.image,
    })

    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    })
  }

  const handleToggleWishlist = () => {
    setIsWishlisted(!isWishlisted)

    toast({
      title: isWishlisted ? "Removed from wishlist" : "Added to wishlist",
      description: `${product.name} has been ${isWishlisted ? "removed from" : "added to"} your wishlist.`,
    })
  }

  return (
    <div className="flex gap-2 mt-2">
      <Button onClick={handleAddToCart} size="sm" className="flex-1">
        <ShoppingCart className="w-4 h-4 mr-2" />
        Add to Cart
      </Button>
      <Button onClick={handleToggleWishlist} size="sm" variant={isWishlisted ? "default" : "outline"} className="px-2">
        <Heart className="w-4 h-4" fill={isWishlisted ? "currentColor" : "none"} />
      </Button>
    </div>
  )
}
