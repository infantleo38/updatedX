import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { v4 as uuidv4 } from "uuid"

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl || "", supabaseKey || "", {
  auth: {
    persistSession: false,
  },
})

// Helper function to check if error is about missing table
function isTableNotExistError(error: any): boolean {
  if (!error) return false

  // Check if error has a message property that includes "does not exist"
  if (typeof error === "object" && error.message && typeof error.message === "string") {
    return error.message.includes("does not exist")
  }

  // Check if error has a code property that indicates a missing table
  if (typeof error === "object" && error.code) {
    return error.code === "42P01" // PostgreSQL code for undefined_table
  }

  // Convert error to string and check
  const errorStr = String(error)
  return errorStr.includes("does not exist") || errorStr.includes("42P01")
}

// Create tables using raw SQL
async function createTablesWithRawSQL() {
  try {
    // Create UUID extension if it doesn't exist
    const createExtensionQuery = `
      CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    `

    // Try to execute the extension query directly
    const { error: extensionError } = await supabase.rpc("exec_sql", {
      sql_query: createExtensionQuery,
    })

    if (extensionError) {
      console.error("Error creating UUID extension:", extensionError)
      // If RPC fails, try direct SQL query
      await supabase.from("_exec_sql").insert({ query: createExtensionQuery })
    }

    // Create user_activities table
    const createActivitiesTableQuery = `
      CREATE TABLE IF NOT EXISTS public.user_activities (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID,
        session_id TEXT NOT NULL,
        activity_type TEXT NOT NULL,
        page TEXT,
        duration INTEGER,
        ip_address TEXT,
        user_agent TEXT,
        device_type TEXT,
        referrer TEXT,
        metadata JSONB DEFAULT '{}'::jsonb,
        timestamp TIMESTAMPTZ DEFAULT NOW()
      );
    `

    // Try to execute the activities table query
    const { error: activitiesError } = await supabase.rpc("exec_sql", {
      sql_query: createActivitiesTableQuery,
    })

    if (activitiesError) {
      console.error("Error creating user_activities table:", activitiesError)
      // If RPC fails, try direct SQL query
      await supabase.from("_exec_sql").insert({ query: createActivitiesTableQuery })
    }

    console.log("Tables created successfully")
    return true
  } catch (error) {
    console.error("Error creating tables with raw SQL:", error)
    return false
  }
}

// Create a minimal activity table as a last resort
async function createMinimalActivityTable() {
  try {
    // Use the SQL API directly
    const { data, error } = await supabase.from("_minimal_activity_table").insert({
      create: true,
    })

    if (error) {
      console.error("Error creating minimal activity table:", error)
      return false
    }

    return true
  } catch (error) {
    console.error("Error in createMinimalActivityTable:", error)
    return false
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()

    // Generate a session ID if not provided
    const sessionId = data.sessionId || uuidv4()

    // Determine device type from user agent
    const deviceType = data.userAgent?.toLowerCase().includes("mobile") ? "mobile" : "desktop"

    // Try to insert the activity
    try {
      // First, check if the table exists
      const { count, error: checkError } = await supabase
        .from("user_activities")
        .select("*", { count: "exact", head: true })
        .limit(1)

      // If there's an error checking the table, it probably doesn't exist
      if (checkError) {
        console.log("Error checking table existence:", checkError)
        console.log("Table doesn't exist, creating it...")

        // Try to create tables
        const tablesCreated = await createTablesWithRawSQL()

        if (!tablesCreated) {
          // Try fallback method
          await createMinimalActivityTable()
        }
      }

      // Now try to insert the activity
      const { error } = await supabase.from("user_activities").insert({
        user_id: data.userId || null,
        session_id: sessionId,
        activity_type: data.activityType,
        page: data.page || null,
        ip_address: data.ipAddress || null,
        user_agent: data.userAgent || null,
        device_type: deviceType,
        referrer: data.referrer || null,
        metadata: data.metadata || {},
      })

      if (error) {
        console.error("Error recording activity via API:", error)

        // Try one more time with minimal data
        await supabase.from("user_activities").insert({
          session_id: sessionId,
          activity_type: data.activityType || "page_view",
        })
      }
    } catch (error) {
      // Silently fail - tracking should not affect user experience
      console.error("Error recording activity via API:", error)
    }

    // Always return success to avoid affecting user experience
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error in track API:", error)
    return NextResponse.json({ success: false })
  }
}
