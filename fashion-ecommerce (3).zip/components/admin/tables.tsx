import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Eye } from "lucide-react"

// Status badge component
function OrderStatusBadge({ status }: { status: string }) {
  let variant: "default" | "secondary" | "outline" | "destructive" = "outline"

  switch (status) {
    case "Processing":
      variant = "secondary"
      break
    case "Shipped":
      variant = "default"
      break
    case "Delivered":
      variant = "outline"
      break
    case "Cancelled":
      variant = "destructive"
      break
  }

  return <Badge variant={variant}>{status}</Badge>
}

// Recent Orders Table Component
export function RecentOrdersTable({ orders = [] }: { orders: any[] }) {
  return (
    <div className="rounded-md border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Order ID</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead className="hidden md:table-cell">Date</TableHead>
            <TableHead className="hidden md:table-cell">Amount</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.length > 0 ? (
            orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell className="font-medium">{order.id}</TableCell>
                <TableCell>
                  <div>
                    {order.users?.name || "Unknown"}
                    <div className="text-xs text-muted-foreground">{order.users?.email || "No email"}</div>
                  </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  {new Date(order.created_at).toLocaleDateString()}
                </TableCell>
                <TableCell className="hidden md:table-cell">${Number(order.total).toFixed(2)}</TableCell>
                <TableCell>
                  <OrderStatusBadge status={order.status} />
                </TableCell>
                <TableCell className="text-right">
                  <Link href={`/admin/orders/${order.id}`}>
                    <Button variant="ghost" size="icon">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </Link>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-4 text-muted-foreground">
                No orders found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  )
}
