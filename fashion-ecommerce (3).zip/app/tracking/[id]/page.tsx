import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { ChevronLeft, Package, Truck, CheckCircle, MapPin } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

interface TrackingPageProps {
  params: {
    id: string
  }
}

export default function TrackingPage({ params }: TrackingPageProps) {
  const { id } = params

  // Mock tracking data
  const tracking = {
    orderId: id,
    trackingId: "1Z999AA10123456784",
    carrier: "UPS",
    estimatedDelivery: "April 15, 2023",
    status: "In Transit",
    currentLocation: "New York, NY",
    events: [
      {
        date: "April 13, 2023",
        time: "10:23 AM",
        location: "New York, NY",
        status: "In Transit",
        description: "Package is in transit to the destination",
      },
      {
        date: "April 12, 2023",
        time: "4:15 PM",
        location: "New York, NY",
        status: "Shipped",
        description: "Package has left the carrier facility",
      },
      {
        date: "April 12, 2023",
        time: "11:42 AM",
        location: "New York, NY",
        status: "Processing",
        description: "Package has been processed at carrier facility",
      },
      {
        date: "April 12, 2023",
        time: "9:30 AM",
        location: "New York, NY",
        status: "Label Created",
        description: "Shipping label has been created",
      },
    ],
    items: [
      {
        id: 1,
        name: "Custom Round Neck T-Shirt",
        size: "M",
        color: "White",
        price: 25.0,
        quantity: 1,
      },
      {
        id: 2,
        name: "Custom V-Neck T-Shirt",
        size: "L",
        color: "Black",
        price: 28.0,
        quantity: 1,
      },
    ],
    shippingAddress: {
      name: "John Doe",
      address: "123 Main Street, Apt 4B",
      city: "New York",
      state: "NY",
      zip: "10001",
      country: "United States",
    },
  }

  // Get status icon based on event status
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Label Created":
        return <Package className="h-5 w-5" />
      case "Processing":
        return <Package className="h-5 w-5" />
      case "Shipped":
        return <Truck className="h-5 w-5" />
      case "In Transit":
        return <Truck className="h-5 w-5" />
      case "Out for Delivery":
        return <Truck className="h-5 w-5" />
      case "Delivered":
        return <CheckCircle className="h-5 w-5" />
      default:
        return <Package className="h-5 w-5" />
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <Button variant="outline" size="sm" asChild className="mb-6">
        <Link href={`/orders/${id}`}>
          <ChevronLeft className="mr-1 h-4 w-4" /> Back to Order
        </Link>
      </Button>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          {/* Tracking Information */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Truck className="mr-2 h-5 w-5" /> Tracking Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 mb-8">
                <div>
                  <p className="text-sm text-muted-foreground">Order Number</p>
                  <p className="font-medium">#{tracking.orderId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tracking Number</p>
                  <p className="font-medium">{tracking.trackingId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Carrier</p>
                  <p className="font-medium">{tracking.carrier}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="font-medium">{tracking.status}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Current Location</p>
                  <p className="font-medium">{tracking.currentLocation}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Estimated Delivery</p>
                  <p className="font-medium">{tracking.estimatedDelivery}</p>
                </div>
              </div>

              <h3 className="font-medium mb-4">Tracking History</h3>
              <div className="relative">
                {/* Timeline line */}
                <div className="absolute left-2.5 top-2 bottom-2 w-0.5 bg-gray-200"></div>

                {/* Timeline events */}
                <div className="space-y-6">
                  {tracking.events.map((event, index) => (
                    <div key={index} className="flex gap-4">
                      <div
                        className={`relative flex items-center justify-center w-5 h-5 rounded-full mt-1 ${
                          index === 0 ? "bg-primary text-primary-foreground" : "bg-gray-200"
                        }`}
                      >
                        {getStatusIcon(event.status)}
                      </div>
                      <div>
                        <p className="font-medium">{event.status}</p>
                        <p className="text-sm">{event.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {event.date} at {event.time} • {event.location}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Shipping Address */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="mr-2 h-5 w-5" /> Shipping Address
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-medium">{tracking.shippingAddress.name}</p>
              <p>{tracking.shippingAddress.address}</p>
              <p>
                {tracking.shippingAddress.city}, {tracking.shippingAddress.state} {tracking.shippingAddress.zip}
              </p>
              <p>{tracking.shippingAddress.country}</p>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-1">
          {/* Order Summary */}
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tracking.items.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <div className="w-16 h-16 bg-gray-100 rounded-md relative flex-shrink-0">
                      <Image src="/temp-tshirt.jpg" alt={item.name} fill className="object-contain p-1" />
                    </div>
                    <div className="flex-grow">
                      <p className="font-medium text-sm">{item.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Size: {item.size} • Color: {item.color} • Qty: {item.quantity}
                      </p>
                      <p className="text-sm mt-1">${item.price.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
                <Separator />
                <div className="flex justify-between">
                  <span className="font-medium">Total</span>
                  <span className="font-medium">
                    ${tracking.items.reduce((sum, item) => sum + item.price * item.quantity, 0).toFixed(2)}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
