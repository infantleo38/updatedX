import TShirtCustomizer from "@/components/t-shirt-customizer/t-shirt-customizer"

export default function CustomizePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold mb-2">Design Your Custom T-Shirt</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Choose your preferred t-shirt style, then customize it by uploading your own image or selecting from our
            gallery. Position, resize, and rotate your design to create your perfect custom t-shirt.
          </p>
        </div>
        <TShirtCustomizer />
      </div>
    </div>
  )
}
