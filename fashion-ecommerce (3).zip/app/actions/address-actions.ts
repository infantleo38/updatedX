"use server"

import { createClient } from "@supabase/supabase-js"
import { revalidatePath } from "next/cache"
import type { Address } from "@/lib/types"
import { getCurrentUserId } from "@/lib/auth"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

export async function getUserAddresses(): Promise<Address[]> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return []
    }

    const { data, error } = await supabase
      .from("addresses")
      .select("*")
      .eq("user_id", userId)
      .order("is_default", { ascending: false })

    if (error) {
      console.error("Error fetching addresses:", error)
      return []
    }

    return data.map(mapDatabaseAddressToAddress)
  } catch (error) {
    console.error("Error in getUserAddresses:", error)
    return []
  }
}

export async function addAddress(
  address: Omit<Address, "id">,
): Promise<{ success: boolean; id?: string; error?: string }> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return { success: false, error: "User not found" }
    }

    // If this is the default address, update all other addresses to not be default
    if (address.isDefault) {
      await updateDefaultAddressStatus(userId)
    }

    const { data, error } = await supabase
      .from("addresses")
      .insert([
        {
          user_id: userId,
          name: address.name,
          street: address.street,
          apartment: address.apartment,
          city: address.city,
          state: address.state,
          zip_code: address.zipCode,
          country: address.country,
          is_default: address.isDefault,
          phone: address.phone,
        },
      ])
      .select()

    if (error) {
      console.error("Error adding address:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/account")
    return { success: true, id: data[0].id }
  } catch (error) {
    console.error("Error in addAddress:", error)
    return { success: false, error: "Failed to add address" }
  }
}

export async function updateAddress(
  id: string,
  address: Partial<Address>,
): Promise<{ success: boolean; error?: string }> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return { success: false, error: "User not found" }
    }

    // If this is being set as the default address, update all other addresses
    if (address.isDefault) {
      await updateDefaultAddressStatus(userId)
    }

    const updateData: any = {}
    if (address.name !== undefined) updateData.name = address.name
    if (address.street !== undefined) updateData.street = address.street
    if (address.apartment !== undefined) updateData.apartment = address.apartment
    if (address.city !== undefined) updateData.city = address.city
    if (address.state !== undefined) updateData.state = address.state
    if (address.zipCode !== undefined) updateData.zip_code = address.zipCode
    if (address.country !== undefined) updateData.country = address.country
    if (address.isDefault !== undefined) updateData.is_default = address.isDefault
    if (address.phone !== undefined) updateData.phone = address.phone

    const { error } = await supabase.from("addresses").update(updateData).eq("id", id).eq("user_id", userId)

    if (error) {
      console.error("Error updating address:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/account")
    return { success: true }
  } catch (error) {
    console.error("Error in updateAddress:", error)
    return { success: false, error: "Failed to update address" }
  }
}

export async function deleteAddress(id: string): Promise<{ success: boolean; error?: string }> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return { success: false, error: "User not found" }
    }

    // Check if this is the default address
    const { data: addressData } = await supabase
      .from("addresses")
      .select("is_default")
      .eq("id", id)
      .eq("user_id", userId)
      .single()

    const { error } = await supabase.from("addresses").delete().eq("id", id).eq("user_id", userId)

    if (error) {
      console.error("Error deleting address:", error)
      return { success: false, error: error.message }
    }

    // If we deleted the default address, set a new default if any addresses remain
    if (addressData?.is_default) {
      const { data: remainingAddresses } = await supabase.from("addresses").select("id").eq("user_id", userId).limit(1)

      if (remainingAddresses && remainingAddresses.length > 0) {
        await supabase.from("addresses").update({ is_default: true }).eq("id", remainingAddresses[0].id)
      }
    }

    revalidatePath("/account")
    return { success: true }
  } catch (error) {
    console.error("Error in deleteAddress:", error)
    return { success: false, error: "Failed to delete address" }
  }
}

// Helper function to update all addresses to not be default
async function updateDefaultAddressStatus(userId: string): Promise<void> {
  try {
    await supabase.from("addresses").update({ is_default: false }).eq("user_id", userId)
  } catch (error) {
    console.error("Error updating default address status:", error)
  }
}

// Helper function to map database address to our Address type
function mapDatabaseAddressToAddress(dbAddress: any): Address {
  return {
    id: dbAddress.id,
    name: dbAddress.name,
    street: dbAddress.street,
    apartment: dbAddress.apartment || "",
    city: dbAddress.city,
    state: dbAddress.state,
    zipCode: dbAddress.zip_code,
    country: dbAddress.country,
    isDefault: dbAddress.is_default,
    phone: dbAddress.phone,
  }
}
