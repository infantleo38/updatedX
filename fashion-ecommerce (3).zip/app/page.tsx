import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"
import { ChevronRight, Star } from "lucide-react"

// Mock data for featured products
const trendingProducts = [
  {
    id: "1",
    name: "Classic T-Shirt",
    price: 29.99,
    image: "/classic-cotton-tee.png",
    category: "T-Shirts",
  },
  {
    id: "2",
    name: "Denim Jacket",
    price: 89.99,
    image: "/classic-denim-jacket.png",
    category: "Outerwear",
  },
  {
    id: "3",
    name: "Summer Dress",
    price: 59.99,
    image: "/breezy-floral-dress.png",
    category: "Dresses",
  },
  {
    id: "4",
    name: "Slim Fit Jeans",
    price: 49.99,
    image: "/denim-collection.png",
    category: "Pants",
  },
  {
    id: "5",
    name: "Graphic Print Tee",
    price: 34.99,
    image: "/abstract-geometric-tee.png",
    category: "T-Shirts",
  },
  {
    id: "6",
    name: "Leather Crossbody Bag",
    price: 79.99,
    image: "/classic-leather-messenger.png",
    category: "Accessories",
  },
]

// Mock data for testimonials
const testimonials = [
  {
    id: 1,
    name: "Sarah Johnson",
    avatar: "/serene-gaze.png",
    rating: 5,
    text: "The quality of the t-shirts is amazing, and the customization tool is so easy to use! I've ordered multiple custom designs and they all turned out perfect.",
  },
  {
    id: 2,
    name: "Michael Chen",
    avatar: "/thoughtful-gaze.png",
    rating: 5,
    text: "Fast shipping and excellent customer service. The fit is perfect and the fabric is so comfortable. Will definitely be ordering again!",
  },
  {
    id: 3,
    name: "Emma Rodriguez",
    avatar: "/joyful-portrait.png",
    rating: 5,
    text: "I love my custom designed t-shirt! The colors are vibrant and the print quality is outstanding. Highly recommend Xillusions for anyone looking for unique fashion.",
  },
]

export default function Home() {
  return (
    <main className="flex flex-col min-h-screen">
      {/* Hero Section with Carousel */}
      <section className="relative w-full h-[600px] md:h-[700px] overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent z-10"></div>

        {/* Hero Image */}
        <Image
          src="/placeholder.svg?height=700&width=1920&query=fashion models runway"
          alt="Fashion Collection"
          fill
          className="object-cover"
          priority
        />

        {/* Hero Content */}
        <div className="relative z-20 container mx-auto h-full flex flex-col justify-center px-4">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 max-w-2xl">
            Elevate Your Style This Season
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-xl">
            Discover the latest trends and express yourself with our premium collection
          </p>
          <div className="flex flex-wrap gap-4">
            <Button asChild size="lg" className="bg-white text-black hover:bg-white/90">
              <Link href="/categories/men">Shop Men</Link>
            </Button>
            <Button asChild size="lg" className="bg-white text-black hover:bg-white/90">
              <Link href="/categories/women">Shop Women</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              <Link href="/customize">Customize Your T-shirt</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2 text-center">Shop by Category</h2>
          <p className="text-center text-muted-foreground mb-10">Find the perfect style for everyone</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Men Category */}
            <div className="group relative overflow-hidden rounded-xl shadow-md">
              <div className="aspect-[3/4] overflow-hidden">
                <Image
                  src="/placeholder.svg?height=600&width=450&query=men fashion model"
                  alt="Men's Collection"
                  width={450}
                  height={600}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Men</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Link
                    href="/categories/men?subcategory=tshirts"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    T-Shirts
                  </Link>
                  <Link
                    href="/categories/men?subcategory=pants"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Pants
                  </Link>
                  <Link
                    href="/categories/men?subcategory=outerwear"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Outerwear
                  </Link>
                </div>
                <Button
                  asChild
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-black w-full"
                >
                  <Link href="/categories/men" className="flex items-center justify-center">
                    Shop Men <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Women Category */}
            <div className="group relative overflow-hidden rounded-xl shadow-md">
              <div className="aspect-[3/4] overflow-hidden">
                <Image
                  src="/placeholder.svg?height=600&width=450&query=women fashion model"
                  alt="Women's Collection"
                  width={450}
                  height={600}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Women</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Link
                    href="/categories/women?subcategory=dresses"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Dresses
                  </Link>
                  <Link
                    href="/categories/women?subcategory=tops"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Tops
                  </Link>
                  <Link
                    href="/categories/women?subcategory=accessories"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Accessories
                  </Link>
                </div>
                <Button
                  asChild
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-black w-full"
                >
                  <Link href="/categories/women" className="flex items-center justify-center">
                    Shop Women <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Kids Category */}
            <div className="group relative overflow-hidden rounded-xl shadow-md">
              <div className="aspect-[3/4] overflow-hidden">
                <Image
                  src="/placeholder.svg?height=600&width=450&query=kids fashion"
                  alt="Kids' Collection"
                  width={450}
                  height={600}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Kids</h3>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Link
                    href="/categories/kids?subcategory=tshirts"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    T-Shirts
                  </Link>
                  <Link
                    href="/categories/kids?subcategory=pants"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Pants
                  </Link>
                  <Link
                    href="/categories/kids?subcategory=accessories"
                    className="text-sm text-white/90 hover:text-white bg-white/20 px-3 py-1 rounded-full"
                  >
                    Accessories
                  </Link>
                </div>
                <Button
                  asChild
                  variant="outline"
                  className="border-white text-white hover:bg-white hover:text-black w-full"
                >
                  <Link href="/categories/kids" className="flex items-center justify-center">
                    Shop Kids <ChevronRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* T-shirt Customization Promo */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-blue-500">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Design Your Perfect T-shirt</h2>
              <p className="text-white/90 text-lg mb-6">
                Express your unique style with our easy-to-use customization tool. Add text, upload images, or choose
                from our gallery of designs.
              </p>
              <ul className="mb-8 space-y-2">
                <li className="flex items-center text-white">
                  <div className="mr-2 rounded-full bg-white/20 p-1">
                    <svg
                      className="h-4 w-4 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  Choose from multiple t-shirt styles
                </li>
                <li className="flex items-center text-white">
                  <div className="mr-2 rounded-full bg-white/20 p-1">
                    <svg
                      className="h-4 w-4 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  Add custom text, images, and designs
                </li>
                <li className="flex items-center text-white">
                  <div className="mr-2 rounded-full bg-white/20 p-1">
                    <svg
                      className="h-4 w-4 text-white"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                  </div>
                  Preview your design in real-time
                </li>
              </ul>
              <Button asChild size="lg" className="bg-white text-purple-600 hover:bg-white/90">
                <Link href="/customize">Start Designing Now</Link>
              </Button>
            </div>
            <div className="md:w-1/2 mt-8 md:mt-0">
              <div className="relative">
                <Image
                  src="/personalized-tee-design.png"
                  alt="T-shirt Customization"
                  width={600}
                  height={500}
                  className="rounded-lg shadow-xl"
                />
                <div className="absolute -bottom-4 -right-4 bg-white rounded-lg px-4 py-2 shadow-lg">
                  <p className="text-sm font-medium">Design in minutes!</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Promotions & Offers */}
      <section className="py-6 bg-black text-white">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between px-4">
            <div className="flex items-center mb-4 md:mb-0">
              <svg
                className="h-6 w-6 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                ></path>
              </svg>
              <p className="font-medium">
                Limited Time: 20% OFF all orders with code <span className="font-bold">SUMMER20</span>
              </p>
            </div>
            <div className="flex items-center">
              <svg
                className="h-6 w-6 mr-2"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
              <p className="font-medium">Free shipping on orders over $50</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2 text-center">Trending Now</h2>
          <p className="text-center text-muted-foreground mb-10">Our most popular styles this season</p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {trendingProducts.slice(0, 8).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild size="lg">
              <Link href="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-2 text-center">What Our Customers Say</h2>
          <p className="text-center text-muted-foreground mb-10">Trusted by fashion enthusiasts worldwide</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="bg-gray-50 p-6 rounded-xl shadow-sm">
                <div className="flex items-center mb-4">
                  <Image
                    src={testimonial.avatar || "/placeholder.svg"}
                    alt={testimonial.name}
                    width={50}
                    height={50}
                    className="rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-medium">{testimonial.name}</h4>
                    <div className="flex">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">"{testimonial.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Our Newsletter</h2>
          <p className="mb-8 max-w-2xl mx-auto">
            Subscribe to get special offers, free giveaways, and once-in-a-lifetime deals.
          </p>
          <form className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Your email address"
              className="flex-1 px-4 py-2 rounded-md text-gray-900"
              required
            />
            <Button type="submit">Subscribe</Button>
          </form>
        </div>
      </section>
    </main>
  )
}
