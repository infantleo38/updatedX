import Image from "next/image"
import Link from "next/link"
import { ChevronRight } from "lucide-react"

interface CategoryCardProps {
  title: string
  description: string
  image: string
  href: string
}

export default function CategoryCard({ title, description, image, href }: CategoryCardProps) {
  return (
    <Link href={href} className="group relative overflow-hidden rounded-lg">
      <div className="relative h-[300px] w-full overflow-hidden">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-6">
        <h3 className="text-xl font-bold text-white">{title}</h3>
        <p className="mt-1 text-sm text-white/80">{description}</p>
        <div className="mt-4 flex items-center text-sm font-medium text-white">
          Shop Now <ChevronRight className="ml-1 h-4 w-4" />
        </div>
      </div>
    </Link>
  )
}
