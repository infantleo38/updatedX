"use client"

import { useRef, useEffect, type RefObject } from "react"

interface UseDraggableOptions {
  onDrag?: (deltaX: number, deltaY: number) => void
  bounds?: RefObject<HTMLElement>
}

export function useDraggable(elementRef: RefObject<HTMLElement>, options: UseDraggableOptions = {}) {
  const { onDrag, bounds } = options

  const isDragging = useRef(false)
  const lastPosition = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const element = elementRef.current
    if (!element) return

    const handleMouseDown = (e: MouseEvent) => {
      isDragging.current = true
      lastPosition.current = { x: e.clientX, y: e.clientY }
      e.preventDefault()
    }

    const handleTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging.current = true
        lastPosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }
      }
    }

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging.current) return

      const deltaX = e.clientX - lastPosition.current.x
      const deltaY = e.clientY - lastPosition.current.y

      lastPosition.current = { x: e.clientX, y: e.clientY }

      if (onDrag) {
        onDrag(deltaX, deltaY)
      }
    }

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging.current || e.touches.length !== 1) return

      const deltaX = e.touches[0].clientX - lastPosition.current.x
      const deltaY = e.touches[0].clientY - lastPosition.current.y

      lastPosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }

      if (onDrag) {
        onDrag(deltaX, deltaY)
      }

      e.preventDefault()
    }

    const handleMouseUp = () => {
      isDragging.current = false
    }

    const handleTouchEnd = () => {
      isDragging.current = false
    }

    element.addEventListener("mousedown", handleMouseDown)
    element.addEventListener("touchstart", handleTouchStart)
    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("touchmove", handleTouchMove, { passive: false })
    window.addEventListener("mouseup", handleMouseUp)
    window.addEventListener("touchend", handleTouchEnd)

    return () => {
      element.removeEventListener("mousedown", handleMouseDown)
      element.removeEventListener("touchstart", handleTouchStart)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("touchmove", handleTouchMove)
      window.removeEventListener("mouseup", handleMouseUp)
      window.removeEventListener("touchend", handleTouchEnd)
    }
  }, [elementRef, onDrag, bounds])
}
