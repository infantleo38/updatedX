"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "../context/auth-context"
import { Loader2 } from "lucide-react"

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, isLoading, isAdmin } = useAuth()
  const router = useRouter()
  const [checking, setChecking] = useState(true)

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        console.log("No user found, redirecting to login")
        router.push("/auth/db-login")
      } else if (!isAdmin) {
        console.log("User is not admin, redirecting to account")
        router.push("/account")
      } else {
        setChecking(false)
      }
    }
  }, [user, isLoading, isAdmin, router])

  if (isLoading || checking) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="text-center">
          <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
          <p className="mt-2 text-muted-foreground">Checking authentication...</p>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
