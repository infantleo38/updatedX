"use client"

import type React from "react"

import { Check } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import type { DesignState } from "./t-shirt-customizer"

interface TShirtOptionsProps {
  designState: DesignState
  setDesignState: React.Dispatch<React.SetStateAction<DesignState>>
}

const TSHIRT_COLORS = [
  { name: "White", value: "#FFFFFF" },
  { name: "Black", value: "#000000" },
  { name: "Navy", value: "#0A2463" },
  { name: "Red", value: "#D90429" },
  { name: "Green", value: "#2B9348" },
]

const TSHIRT_SIZES = ["XS", "S", "M", "L", "XL", "XXL"]

export function TShirtOptions({ designState, setDesignState }: TShirtOptionsProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold mb-4">T-Shirt Options</h2>

      {/* Color Selection */}
      <div className="mb-6">
        <h3 className="text-sm font-medium mb-3">Color</h3>
        <div className="flex flex-wrap gap-2">
          {TSHIRT_COLORS.map((color) => (
            <button
              key={color.value}
              className={`w-8 h-8 rounded-full flex items-center justify-center ${
                color.value === "#FFFFFF" ? "border border-gray-200" : ""
              } ${designState.tshirtColor === color.value ? "ring-2 ring-primary ring-offset-2" : ""}`}
              style={{ backgroundColor: color.value }}
              onClick={() => setDesignState((prev) => ({ ...prev, tshirtColor: color.value }))}
              title={color.name}
            >
              {designState.tshirtColor === color.value && color.value === "#FFFFFF" && (
                <Check className="h-4 w-4 text-black" />
              )}
              {designState.tshirtColor === color.value && color.value !== "#FFFFFF" && (
                <Check className="h-4 w-4 text-white" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Size Selection */}
      <div>
        <h3 className="text-sm font-medium mb-3">Size</h3>
        <RadioGroup
          value={designState.tshirtSize}
          onValueChange={(value) => setDesignState((prev) => ({ ...prev, tshirtSize: value }))}
          className="flex flex-wrap gap-2"
        >
          {TSHIRT_SIZES.map((size) => (
            <div key={size} className="flex items-center space-x-2">
              <RadioGroupItem value={size} id={`size-${size}`} className="peer sr-only" />
              <Label
                htmlFor={`size-${size}`}
                className="flex h-10 w-10 items-center justify-center rounded-md border border-muted bg-popover hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10"
              >
                {size}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </div>
    </div>
  )
}
