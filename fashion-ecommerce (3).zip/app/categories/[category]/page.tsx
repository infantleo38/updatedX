import { notFound } from "next/navigation"
import { ChevronRight } from "lucide-react"

import ProductCard from "@/components/product-card"
import { getProductsByCategory } from "@/lib/products"
import { ProductFilters } from "@/components/product-filters"

interface CategoryPageProps {
  params: {
    category: string
  }
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { category } = params

  // Validate category
  const validCategories = ["men", "women", "kids"]
  if (!validCategories.includes(category.toLowerCase())) {
    notFound()
  }

  // Get formatted category name
  const categoryName = category.charAt(0).toUpperCase() + category.slice(1)

  // Get products for this category
  const products = await getProductsByCategory(categoryName)

  return (
    <main className="flex-1">
      <div className="container px-4 md:px-6 py-6 md:py-8">
        <div className="flex items-center gap-1 text-sm text-muted-foreground mb-4">
          <a href="/" className="hover:text-primary">
            Home
          </a>
          <ChevronRight className="h-4 w-4" />
          <span className="font-medium text-foreground">{categoryName}'s Fashion</span>
        </div>

        <h1 className="text-3xl font-bold mb-8">{categoryName}'s Fashion</h1>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="hidden md:block">
            <ProductFilters category={categoryName} />
          </div>

          <div className="md:col-span-3">
            {products.length === 0 ? (
              <div className="text-center py-12">
                <h2 className="text-xl font-medium">No products found</h2>
                <p className="text-muted-foreground mt-2">Try adjusting your filters or check back later.</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  )
}
