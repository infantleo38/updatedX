import { createClient } from "@supabase/supabase-js"
import type { Product } from "./types"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

// Fetch featured products
export async function getFeaturedProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(8)

    if (error) {
      console.error("Error fetching featured products:", error)
      throw error
    }

    return data.map(mapDatabaseProductToProduct)
  } catch (error) {
    console.error("Error in getFeaturedProducts:", error)
    return []
  }
}

// Fetch products by category
export async function getProductsByCategory(category: string): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("category", category)
      .order("created_at", { ascending: false })

    if (error) {
      console.error(`Error fetching ${category} products:`, error)
      throw error
    }

    return data.map(mapDatabaseProductToProduct)
  } catch (error) {
    console.error(`Error in getProductsByCategory for ${category}:`, error)
    return []
  }
}

// Fetch product by ID
export async function getProductById(id: string): Promise<Product | null> {
  try {
    const { data, error } = await supabase.from("products").select("*").eq("id", id).single()

    if (error) {
      console.error(`Error fetching product with ID ${id}:`, error)
      throw error
    }

    return mapDatabaseProductToProduct(data)
  } catch (error) {
    console.error(`Error in getProductById for ${id}:`, error)
    return null
  }
}

// Fetch new arrivals
export async function getNewArrivals(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("is_new", true)
      .order("created_at", { ascending: false })
      .limit(8)

    if (error) {
      console.error("Error fetching new arrivals:", error)
      throw error
    }

    return data.map(mapDatabaseProductToProduct)
  } catch (error) {
    console.error("Error in getNewArrivals:", error)
    return []
  }
}

// Fetch sale products
export async function getSaleProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("is_sale", true)
      .order("created_at", { ascending: false })
      .limit(8)

    if (error) {
      console.error("Error fetching sale products:", error)
      throw error
    }

    return data.map(mapDatabaseProductToProduct)
  } catch (error) {
    console.error("Error in getSaleProducts:", error)
    return []
  }
}

// Search products
export async function searchProducts(query: string): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .ilike("name", `%${query}%`)
      .order("name", { ascending: true })
      .limit(20)

    if (error) {
      console.error(`Error searching products with query "${query}":`, error)
      throw error
    }

    return data.map(mapDatabaseProductToProduct)
  } catch (error) {
    console.error(`Error in searchProducts for "${query}":`, error)
    return []
  }
}

// Helper function to map database product to our Product type
function mapDatabaseProductToProduct(dbProduct: any): Product {
  return {
    id: dbProduct.id,
    name: dbProduct.name,
    description: dbProduct.description || "",
    price: Number.parseFloat(dbProduct.price),
    originalPrice: dbProduct.original_price ? Number.parseFloat(dbProduct.original_price) : undefined,
    rating: Number.parseFloat(dbProduct.rating),
    image: dbProduct.image,
    images: dbProduct.images || [],
    category: dbProduct.category,
    subcategory: dbProduct.subcategory || "",
    tags: dbProduct.tags || [],
    sizes: dbProduct.sizes || [],
    colors: dbProduct.colors || [],
    isNew: dbProduct.is_new || false,
    isSale: dbProduct.is_sale || false,
    stock: dbProduct.stock || 0,
  }
}
