"use server"

import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

export async function getAdminUserId() {
  try {
    const { data, error } = await supabase
      .from("users")
      .select("id")
      .eq("role", "admin")
      .eq("email", "admin@xillusions.com")
      .single()

    if (error) {
      console.error("Error fetching admin user:", error)
      return { id: null, error: error.message }
    }

    return { id: data?.id || null, error: null }
  } catch (error: any) {
    console.error("Error in getAdminUserId:", error)
    return { id: null, error: error.message || "An unexpected error occurred" }
  }
}
