"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"
import { useRouter } from "next/navigation"

type User = {
  id: string
  email: string
  name: string
  role: string
  avatar?: string
}

type AuthContextType = {
  user: User | null
  isLoading: boolean
  isAdmin: boolean
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  signUp: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createClientComponentClient()
  const router = useRouter()

  useEffect(() => {
    const fetchUser = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()

      if (session?.user) {
        // Fetch user data including role
        const { data } = await supabase.from("users").select("*").eq("id", session.user.id).single()

        if (data) {
          setUser({
            id: session.user.id,
            email: session.user.email!,
            name: data.name,
            role: data.role,
            avatar: data.avatar_url,
          })
        }
      }

      setIsLoading(false)
    }

    fetchUser()

    // Set up auth state listener
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        // Fetch user data including role
        const { data } = await supabase.from("users").select("*").eq("id", session.user.id).single()

        if (data) {
          setUser({
            id: session.user.id,
            email: session.user.email!,
            name: data.name,
            role: data.role,
            avatar: data.avatar_url,
          })
        }
      } else {
        setUser(null)
      }

      router.refresh()
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [supabase, router])

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        return { success: false, error: error.message }
      }

      // Fetch user role
      const { data: userData, error: userError } = await supabase
        .from("users")
        .select("role, name")
        .eq("id", data.user.id)
        .single()

      if (userError) {
        console.error("Error fetching user role:", userError)
        return { success: true } // Default to user role if error
      }

      // Redirect based on role
      if (userData.role === "admin") {
        router.push("/admin")
      } else {
        router.push("/account")
      }

      return { success: true }
    } catch (error: any) {
      return { success: false, error: error.message || "An unexpected error occurred" }
    }
  }

  const signUp = async (email: string, password: string, name: string) => {
    try {
      // Create auth user
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      })

      if (error || !data.user) {
        return { success: false, error: error?.message || "Failed to create user" }
      }

      // Add user data to users table
      const { error: userError } = await supabase.from("users").insert({
        id: data.user.id,
        email,
        name,
        role: "user", // Default role for sign-ups
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (userError) {
        console.error("Error creating user record:", userError)
        return { success: false, error: userError.message }
      }

      router.push("/auth/verify-email")
      return { success: true }
    } catch (error: any) {
      return { success: false, error: error.message || "An unexpected error occurred" }
    }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAdmin: user?.role === "admin",
        signIn,
        signUp,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)

  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }

  return context
}
