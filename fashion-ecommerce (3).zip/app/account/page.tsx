"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/contexts/auth-context"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

// Account page components
import ProfileSection from "@/components/account/profile-section"
import AddressesSection from "@/components/account/addresses-section"
import OrderHistorySection from "@/components/account/order-history-section"
import SecuritySection from "@/components/account/security-section"

// Server actions
import { updateUserProfile } from "@/app/actions/user-actions"
import { getUserAddresses, addAddress, updateAddress, deleteAddress } from "@/app/actions/address-actions"
import { getUserOrders } from "@/app/actions/order-actions"

// Types
import type { User, Address, Order } from "@/lib/types"

export default function AccountPage() {
  const router = useRouter()
  const { toast } = useToast()
  const { user: authUser, signOut } = useAuth()
  const [activeTab, setActiveTab] = useState("profile")
  const [isLoading, setIsLoading] = useState(true)
  const [userData, setUserData] = useState<User | null>(null)
  const [addresses, setAddresses] = useState<Address[]>([])
  const [orders, setOrders] = useState<Order[]>([])

  // Fetch user data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)

        if (!authUser) {
          router.push("/auth/login")
          return
        }

        // Set user data from auth context
        setUserData({
          id: authUser.id,
          name: authUser.name,
          email: authUser.email,
          phone: authUser.phone || "",
          avatar: authUser.avatar || "",
          createdAt: new Date().toISOString(), // This would ideally come from the database
        })

        // Fetch addresses
        const userAddresses = await getUserAddresses()
        setAddresses(userAddresses)

        // Fetch orders
        const userOrders = await getUserOrders()
        setOrders(userOrders)
      } catch (error) {
        console.error("Error fetching user data:", error)
        toast({
          title: "Error",
          description: "Failed to load account information. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [authUser, router, toast])

  // Handle profile update
  const handleUpdateProfile = async (updatedData: Partial<User>) => {
    try {
      const { success, error } = await updateUserProfile(updatedData)

      if (!success) {
        toast({
          title: "Error",
          description: error || "Failed to update profile. Please try again.",
          variant: "destructive",
        })
        return false
      }

      // Update local state
      setUserData((prev) => (prev ? { ...prev, ...updatedData } : null))

      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      })

      return true
    } catch (error) {
      console.error("Error updating profile:", error)
      toast({
        title: "Error",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  // Handle address operations
  const handleAddAddress = async (newAddress: Omit<Address, "id">) => {
    try {
      const { success, id, error } = await addAddress(newAddress)

      if (!success || !id) {
        toast({
          title: "Error",
          description: error || "Failed to add address. Please try again.",
          variant: "destructive",
        })
        return false
      }

      // Update local state
      const address: Address = { id, ...newAddress }

      // If this is the first address or marked as default, update other addresses
      if (newAddress.isDefault || addresses.length === 0) {
        setAddresses((prev) =>
          prev.map((addr) => ({ ...addr, isDefault: false })).concat({ ...address, isDefault: true }),
        )
      } else {
        setAddresses((prev) => [...prev, address])
      }

      toast({
        title: "Address added",
        description: "Your new address has been added successfully.",
      })

      return true
    } catch (error) {
      console.error("Error adding address:", error)
      toast({
        title: "Error",
        description: "Failed to add address. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  const handleUpdateAddress = async (id: string, updatedAddress: Partial<Address>) => {
    try {
      const { success, error } = await updateAddress(id, updatedAddress)

      if (!success) {
        toast({
          title: "Error",
          description: error || "Failed to update address. Please try again.",
          variant: "destructive",
        })
        return false
      }

      // Update local state
      if (updatedAddress.isDefault) {
        setAddresses((prev) =>
          prev.map((addr) =>
            addr.id === id ? { ...addr, ...updatedAddress, isDefault: true } : { ...addr, isDefault: false },
          ),
        )
      } else {
        setAddresses((prev) => prev.map((addr) => (addr.id === id ? { ...addr, ...updatedAddress } : addr)))
      }

      toast({
        title: "Address updated",
        description: "Your address has been updated successfully.",
      })

      return true
    } catch (error) {
      console.error("Error updating address:", error)
      toast({
        title: "Error",
        description: "Failed to update address. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  const handleDeleteAddress = async (id: string) => {
    try {
      const { success, error } = await deleteAddress(id)

      if (!success) {
        toast({
          title: "Error",
          description: error || "Failed to delete address. Please try again.",
          variant: "destructive",
        })
        return false
      }

      // Update local state
      const addressToDelete = addresses.find((addr) => addr.id === id)
      setAddresses((prev) => prev.filter((addr) => addr.id !== id))

      // If we deleted the default address and there are other addresses,
      // make the first one the default
      if (addressToDelete?.isDefault && addresses.length > 1) {
        const remainingAddresses = addresses.filter((addr) => addr.id !== id)
        setAddresses([{ ...remainingAddresses[0], isDefault: true }, ...remainingAddresses.slice(1)])
      }

      toast({
        title: "Address deleted",
        description: "Your address has been deleted successfully.",
      })

      return true
    } catch (error) {
      console.error("Error deleting address:", error)
      toast({
        title: "Error",
        description: "Failed to delete address. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  // Handle password change
  const handleChangePassword = async (currentPassword: string, newPassword: string) => {
    try {
      const supabase = createClientComponentClient()

      // Update password through Supabase Auth
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      })

      if (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive",
        })
        return false
      }

      toast({
        title: "Password changed",
        description: "Your password has been changed successfully.",
      })

      return true
    } catch (error: any) {
      console.error("Error changing password:", error)
      toast({
        title: "Error",
        description: "Failed to change password. Please try again.",
        variant: "destructive",
      })
      return false
    }
  }

  // Handle logout
  const handleLogout = async () => {
    await signOut()

    toast({
      title: "Logged out",
      description: "You have been logged out successfully.",
    })
  }

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="flex justify-center items-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-lg text-muted-foreground">Loading your account information...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!userData) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <Card className="p-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Account Not Found</h2>
          <p className="text-muted-foreground mb-6">
            We couldn't find your account information. Please try logging in again.
          </p>
          <Button onClick={() => router.push("/auth/login")}>Sign In</Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <h1 className="text-3xl font-bold mb-8">My Account</h1>

      <div className="grid md:grid-cols-4 gap-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="md:col-span-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <Card className="p-6">
                <TabsList className="flex flex-col h-auto items-stretch gap-1">
                  <TabsTrigger value="profile" className="justify-start">
                    Profile
                  </TabsTrigger>
                  <TabsTrigger value="addresses" className="justify-start">
                    Addresses
                  </TabsTrigger>
                  <TabsTrigger value="orders" className="justify-start">
                    Order History
                  </TabsTrigger>
                  <TabsTrigger value="security" className="justify-start">
                    Security
                  </TabsTrigger>
                </TabsList>

                <Separator className="my-4" />

                <Button
                  variant="outline"
                  className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
                  onClick={handleLogout}
                >
                  Logout
                </Button>
              </Card>
            </div>

            {/* Main Content */}
            <div className="md:col-span-3">
              <TabsContent value="profile" className="mt-0">
                <ProfileSection user={userData} onUpdateProfile={handleUpdateProfile} />
              </TabsContent>

              <TabsContent value="addresses" className="mt-0">
                <AddressesSection
                  addresses={addresses}
                  onAddAddress={handleAddAddress}
                  onUpdateAddress={handleUpdateAddress}
                  onDeleteAddress={handleDeleteAddress}
                />
              </TabsContent>

              <TabsContent value="orders" className="mt-0">
                <OrderHistorySection orders={orders} />
              </TabsContent>

              <TabsContent value="security" className="mt-0">
                <SecuritySection onChangePassword={handleChangePassword} />
              </TabsContent>
            </div>
          </div>
        </Tabs>
      </div>
    </div>
  )
}
