"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { LogOut, User, Lock, MapPin, ShoppingBag, Palette } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"

export default function ProfilePage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("profile")

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully.",
    })
  }

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Password changed",
      description: "Your password has been changed successfully.",
    })
  }

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: "Address added",
      description: "Your new address has been added successfully.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <h1 className="text-3xl font-bold mb-8">My Account</h1>

      <div className="grid md:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div className="flex items-center space-x-4 mb-6">
              <Avatar className="h-12 w-12">
                <AvatarImage src="/placeholder.svg" alt="User" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">John Doe</p>
                <p className="text-sm text-muted-foreground">john.doe@example.com</p>
              </div>
            </div>

            <nav className="space-y-1">
              <Button
                variant={activeTab === "profile" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("profile")}
              >
                <User className="mr-2 h-4 w-4" /> Profile
              </Button>
              <Button
                variant={activeTab === "password" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("password")}
              >
                <Lock className="mr-2 h-4 w-4" /> Password
              </Button>
              <Button
                variant={activeTab === "addresses" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("addresses")}
              >
                <MapPin className="mr-2 h-4 w-4" /> Addresses
              </Button>
              <Button
                variant={activeTab === "orders" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("orders")}
              >
                <ShoppingBag className="mr-2 h-4 w-4" /> Orders
              </Button>
              <Button
                variant={activeTab === "designs" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("designs")}
              >
                <Palette className="mr-2 h-4 w-4" /> Saved Designs
              </Button>
              <Separator className="my-2" />
              <Button variant="ghost" className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50">
                <LogOut className="mr-2 h-4 w-4" /> Logout
              </Button>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="md:col-span-3">
          {/* Profile Tab */}
          {activeTab === "profile" && (
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSaveProfile}>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input id="firstName" defaultValue="John" />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input id="lastName" defaultValue="Doe" />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" defaultValue="john.doe@example.com" />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input id="phone" type="tel" defaultValue="+1 (555) 123-4567" />
                    </div>
                  </div>
                  <Button type="submit" className="mt-6">
                    Save Changes
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          {/* Password Tab */}
          {activeTab === "password" && (
            <Card>
              <CardHeader>
                <CardTitle>Change Password</CardTitle>
                <CardDescription>Update your password to keep your account secure</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword}>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="currentPassword">Current Password</Label>
                      <Input id="currentPassword" type="password" />
                    </div>
                    <div>
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input id="newPassword" type="password" />
                    </div>
                    <div>
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input id="confirmPassword" type="password" />
                    </div>
                  </div>
                  <Button type="submit" className="mt-6">
                    Change Password
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}

          {/* Addresses Tab */}
          {activeTab === "addresses" && (
            <Card>
              <CardHeader>
                <CardTitle>Saved Addresses</CardTitle>
                <CardDescription>Manage your shipping and billing addresses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Existing Address */}
                  <div className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium">Home</h3>
                          <Badge variant="outline">Default</Badge>
                        </div>
                        <p className="text-sm">John Doe</p>
                        <p className="text-sm">123 Main Street, Apt 4B</p>
                        <p className="text-sm">New York, NY 10001</p>
                        <p className="text-sm">United States</p>
                        <p className="text-sm">+1 (555) 123-4567</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                        <Button variant="outline" size="sm">
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Add New Address */}
                  <div className="border rounded-lg p-4">
                    <h3 className="font-medium mb-4">Add New Address</h3>
                    <form onSubmit={handleAddAddress}>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="addressName">Address Name</Label>
                          <Input id="addressName" placeholder="Home, Work, etc." />
                        </div>
                        <div>
                          <Label htmlFor="addressFullName">Full Name</Label>
                          <Input id="addressFullName" placeholder="John Doe" />
                        </div>
                        <div className="sm:col-span-2">
                          <Label htmlFor="addressLine1">Address Line 1</Label>
                          <Input id="addressLine1" placeholder="Street address, apartment, etc." />
                        </div>
                        <div className="sm:col-span-2">
                          <Label htmlFor="addressLine2">Address Line 2 (Optional)</Label>
                          <Input id="addressLine2" placeholder="Apartment, suite, unit, etc." />
                        </div>
                        <div>
                          <Label htmlFor="addressCity">City</Label>
                          <Input id="addressCity" placeholder="New York" />
                        </div>
                        <div>
                          <Label htmlFor="addressState">State / Province</Label>
                          <Input id="addressState" placeholder="NY" />
                        </div>
                        <div>
                          <Label htmlFor="addressZip">ZIP / Postal Code</Label>
                          <Input id="addressZip" placeholder="10001" />
                        </div>
                        <div>
                          <Label htmlFor="addressCountry">Country</Label>
                          <Input id="addressCountry" placeholder="United States" />
                        </div>
                        <div className="sm:col-span-2">
                          <Label htmlFor="addressPhone">Phone</Label>
                          <Input id="addressPhone" placeholder="+1 (555) 123-4567" />
                        </div>
                      </div>
                      <div className="mt-4">
                        <Button type="submit">Add Address</Button>
                      </div>
                    </form>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Orders Tab */}
          {activeTab === "orders" && (
            <Card>
              <CardHeader>
                <CardTitle>Order History</CardTitle>
                <CardDescription>View and track your orders</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Link
                    href="/orders/XL2023405"
                    className="block border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <p className="font-medium">#XL2023405</p>
                        <p className="text-sm text-muted-foreground">Placed on April 12, 2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="bg-blue-50 text-blue-600 hover:bg-blue-50">
                          Shipped
                        </Badge>
                        <span className="text-sm font-medium">$67.06</span>
                      </div>
                    </div>
                  </Link>

                  <Link
                    href="/orders/XL2023389"
                    className="block border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <p className="font-medium">#XL2023389</p>
                        <p className="text-sm text-muted-foreground">Placed on March 28, 2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="bg-green-50 text-green-600 hover:bg-green-50">
                          Delivered
                        </Badge>
                        <span className="text-sm font-medium">$94.32</span>
                      </div>
                    </div>
                  </Link>

                  <Link
                    href="/orders/XL2023356"
                    className="block border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <p className="font-medium">#XL2023356</p>
                        <p className="text-sm text-muted-foreground">Placed on February 15, 2023</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="bg-green-50 text-green-600 hover:bg-green-50">
                          Delivered
                        </Badge>
                        <span className="text-sm font-medium">$128.75</span>
                      </div>
                    </div>
                  </Link>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" asChild className="w-full">
                  <Link href="/orders">View All Orders</Link>
                </Button>
              </CardFooter>
            </Card>
          )}

          {/* Saved Designs Tab */}
          {activeTab === "designs" && (
            <Card>
              <CardHeader>
                <CardTitle>Saved Designs</CardTitle>
                <CardDescription>Your custom T-shirt designs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {[1, 2, 3, 4, 5].map((design) => (
                    <div key={design} className="border rounded-lg overflow-hidden">
                      <div className="aspect-square relative">
                        <Image src="/temp-tshirt.jpg" alt="T-shirt design" fill className="object-cover" />
                      </div>
                      <div className="p-3">
                        <p className="font-medium">Design #{design}</p>
                        <p className="text-sm text-muted-foreground">Created on April 10, 2023</p>
                        <div className="flex gap-2 mt-2">
                          <Button size="sm" variant="outline" asChild className="flex-1">
                            <Link href={`/customize?design=${design}`}>Edit</Link>
                          </Button>
                          <Button size="sm" variant="outline" className="flex-1">
                            Add to Cart
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/customize">Create New Design</Link>
                </Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
