"use client"

import { useState, useRef } from "react"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import {
  Upload,
  RotateCw,
  RotateCcw,
  Trash2,
  RefreshCw,
  Download,
  ZoomIn,
  ZoomOut,
  ShoppingCart,
  Save,
  ChevronLeft,
} from "lucide-react"
import ImageUploader from "./image-uploader"
import DesignCanvas from "./design-canvas"
import ColorSelector from "./color-selector"

const TSHIRT_COLORS = [
  { name: "White", value: "#FFFFFF" },
  { name: "Black", value: "#000000" },
  { name: "Navy", value: "#0A2463" },
  { name: "Red", value: "#D90429" },
  { name: "Green", value: "#2B9348" },
]

export default function TShirtCustomizer() {
  const [activeView, setActiveView] = useState<"front" | "back">("front")
  const [tshirtColor, setTshirtColor] = useState(TSHIRT_COLORS[0])
  const [designImage, setDesignImage] = useState<string | null>(null)
  const [designPosition, setDesignPosition] = useState({ x: 0, y: 0 })
  const [designScale, setDesignScale] = useState(1)
  const [designRotation, setDesignRotation] = useState(0)
  const canvasRef = useRef<HTMLDivElement>(null)

  const handleImageUpload = (imageDataUrl: string) => {
    setDesignImage(imageDataUrl)
    // Reset position, scale and rotation when a new image is uploaded
    setDesignPosition({ x: 0, y: 0 })
    setDesignScale(1)
    setDesignRotation(0)
  }

  const handleDeleteImage = () => {
    setDesignImage(null)
    setDesignPosition({ x: 0, y: 0 })
    setDesignScale(1)
    setDesignRotation(0)
  }

  const handleResetPosition = () => {
    setDesignPosition({ x: 0, y: 0 })
    setDesignScale(1)
    setDesignRotation(0)
  }

  const handleDownloadPreview = () => {
    // In a real implementation, this would generate and download a preview image
    alert("Download preview functionality would be implemented here")
  }

  const handleRotateLeft = () => {
    setDesignRotation((prev) => prev - 15)
  }

  const handleRotateRight = () => {
    setDesignRotation((prev) => prev + 15)
  }

  const handleScaleChange = (value: number[]) => {
    setDesignScale(value[0])
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Left Column - T-shirt Preview */}
      <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-6">
        <Tabs defaultValue="front" onValueChange={(value) => setActiveView(value as "front" | "back")}>
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="front">Front View</TabsTrigger>
              <TabsTrigger value="back">Back View</TabsTrigger>
            </TabsList>
            <ColorSelector colors={TSHIRT_COLORS} activeColor={tshirtColor} onChange={setTshirtColor} />
          </div>

          <div className="relative aspect-[3/4] max-h-[600px] mx-auto">
            <TabsContent value="front" className="h-full">
              <DesignCanvas
                tshirtColor={tshirtColor.value}
                designImage={designImage}
                designPosition={designPosition}
                designScale={designScale}
                designRotation={designRotation}
                onPositionChange={setDesignPosition}
                view="front"
                ref={canvasRef}
              />
            </TabsContent>
            <TabsContent value="back" className="h-full">
              <DesignCanvas
                tshirtColor={tshirtColor.value}
                designImage={designImage}
                designPosition={designPosition}
                designScale={designScale}
                designRotation={designRotation}
                onPositionChange={setDesignPosition}
                view="back"
                ref={canvasRef}
              />
            </TabsContent>
          </div>
        </Tabs>
      </div>

      {/* Right Column - Controls */}
      <div className="space-y-6">
        {/* Image Upload Section */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold mb-4">Upload Your Design</h2>
          {!designImage ? (
            <ImageUploader onImageUpload={handleImageUpload} />
          ) : (
            <div className="space-y-4">
              <div className="aspect-square w-full max-w-[200px] mx-auto relative border rounded-md overflow-hidden">
                <Image src={designImage || "/placeholder.svg"} alt="Your design" fill className="object-contain" />
              </div>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => document.getElementById("design-upload")?.click()}
              >
                <Upload className="mr-2 h-4 w-4" /> Upload New Image
                <input
                  id="design-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0]
                    if (file) {
                      const reader = new FileReader()
                      reader.onload = (e) => {
                        if (e.target?.result) {
                          handleImageUpload(e.target.result as string)
                        }
                      }
                      reader.readAsDataURL(file)
                    }
                  }}
                />
              </Button>
            </div>
          )}
        </div>

        {/* Design Controls */}
        {designImage && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">Adjust Your Design</h2>

            {/* Scale Control */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Size</span>
                <div className="flex items-center">
                  <Button variant="ghost" size="icon" onClick={() => setDesignScale(Math.max(0.5, designScale - 0.1))}>
                    <ZoomOut className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => setDesignScale(Math.min(2, designScale + 0.1))}>
                    <ZoomIn className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <Slider value={[designScale]} min={0.5} max={2} step={0.01} onValueChange={handleScaleChange} />
            </div>

            {/* Rotation Control */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium">Rotation</span>
                <div className="flex items-center">
                  <Button variant="ghost" size="icon" onClick={handleRotateLeft}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={handleRotateRight}>
                    <RotateCw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="text-center text-sm text-muted-foreground">{designRotation}°</div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" onClick={handleResetPosition}>
                <RefreshCw className="mr-2 h-4 w-4" /> Reset
              </Button>
              <Button variant="outline" onClick={handleDeleteImage}>
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </Button>
              <Button variant="outline" className="col-span-2" onClick={handleDownloadPreview}>
                <Download className="mr-2 h-4 w-4" /> Download Preview
              </Button>
            </div>
          </div>
        )}

        {/* Call to Action */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="space-y-3">
            <Button className="w-full" size="lg">
              <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
            </Button>
            <Button variant="outline" className="w-full">
              <Save className="mr-2 h-4 w-4" /> Save Design
            </Button>
            <Button variant="ghost" className="w-full">
              <ChevronLeft className="mr-2 h-4 w-4" /> Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
