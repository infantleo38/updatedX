"use server"

import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

// Set a password for a user
export async function setUserPassword(userId: string, password: string) {
  try {
    const { data, error } = await supabase.rpc("hash_password", {
      password,
    })

    if (error) {
      console.error("Error hashing password:", error)
      return { success: false, error: error.message }
    }

    const passwordHash = data

    const { error: updateError } = await supabase.from("users").update({ password_hash: passwordHash }).eq("id", userId)

    if (updateError) {
      console.error("Error updating user password:", updateError)
      return { success: false, error: updateError.message }
    }

    return { success: true }
  } catch (error: any) {
    console.error("Error in setUserPassword:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Verify a user's password
export async function verifyUserPassword(userId: string, password: string) {
  try {
    // Get the user's password hash
    const { data: user, error: userError } = await supabase
      .from("users")
      .select("password_hash")
      .eq("id", userId)
      .single()

    if (userError || !user) {
      console.error("Error fetching user:", userError)
      return { success: false, error: userError?.message || "User not found" }
    }

    if (!user.password_hash) {
      return { success: false, error: "User has no password set" }
    }

    // Verify the password
    const { data: isValid, error: verifyError } = await supabase.rpc("verify_password", {
      password,
      password_hash: user.password_hash,
    })

    if (verifyError) {
      console.error("Error verifying password:", verifyError)
      return { success: false, error: verifyError.message }
    }

    return { success: isValid }
  } catch (error: any) {
    console.error("Error in verifyUserPassword:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Change a user's password (requires old password verification)
export async function changeUserPassword(userId: string, currentPassword: string, newPassword: string) {
  try {
    // First verify the current password
    const { success: isValid, error: verifyError } = await verifyUserPassword(userId, currentPassword)

    if (verifyError) {
      return { success: false, error: verifyError }
    }

    if (!isValid) {
      return { success: false, error: "Current password is incorrect" }
    }

    // Set the new password
    return await setUserPassword(userId, newPassword)
  } catch (error: any) {
    console.error("Error in changeUserPassword:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Admin function to reset a user's password
export async function adminResetUserPassword(userId: string, newPassword: string) {
  try {
    return await setUserPassword(userId, newPassword)
  } catch (error: any) {
    console.error("Error in adminResetUserPassword:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Login with email and password
export async function loginWithPassword(email: string, password: string) {
  console.log("Server: Login attempt for email:", email)

  try {
    // Get the user by email
    const { data: user, error: userError } = await supabase
      .from("users")
      .select("id, email, name, role, password_hash")
      .eq("email", email)
      .single()

    if (userError || !user) {
      console.error("Server: Error fetching user:", userError)
      return { success: false, error: "Invalid email or password" }
    }

    console.log("Server: User found:", { id: user.id, email: user.email, role: user.role })

    if (!user.password_hash) {
      console.log("Server: User has no password set")
      return { success: false, error: "User has no password set" }
    }

    // Verify the password
    const { data: isValid, error: verifyError } = await supabase.rpc("verify_password", {
      password,
      password_hash: user.password_hash,
    })

    if (verifyError) {
      console.error("Server: Error verifying password:", verifyError)
      return { success: false, error: "Authentication error" }
    }

    if (!isValid) {
      console.log("Server: Invalid password")
      return { success: false, error: "Invalid email or password" }
    }

    console.log("Server: Password verified successfully")

    // Set a cookie for server-side authentication
    const cookieStore = cookies()
    cookieStore.set("user_id", user.id, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: "/",
    })
    cookieStore.set("user_role", user.role, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 1 week
      path: "/",
    })

    // Return user data for client-side use
    return {
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
    }
  } catch (error: any) {
    console.error("Server: Error in loginWithPassword:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Register a new user with password
export async function registerWithPassword(email: string, password: string, name: string, role = "user") {
  try {
    // Check if user already exists
    const { data: existingUser, error: checkError } = await supabase
      .from("users")
      .select("id")
      .eq("email", email)
      .single()

    if (existingUser) {
      return { success: false, error: "Email already in use" }
    }

    // Hash the password
    const { data: passwordHash, error: hashError } = await supabase.rpc("hash_password", {
      password,
    })

    if (hashError) {
      console.error("Error hashing password:", hashError)
      return { success: false, error: hashError.message }
    }

    // Create the user
    const { data: newUser, error: createError } = await supabase
      .from("users")
      .insert({
        email,
        name,
        role,
        password_hash: passwordHash,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .select()

    if (createError) {
      console.error("Error creating user:", createError)
      return { success: false, error: createError.message }
    }

    return { success: true, userId: newUser?.[0]?.id }
  } catch (error: any) {
    console.error("Error in registerWithPassword:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}
