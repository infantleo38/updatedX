"use server"

import { createClient } from "@supabase/supabase-js"
import type { Order, OrderItem } from "@/lib/types"
import { getCurrentUserId } from "@/lib/auth"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

export async function getUserOrders(): Promise<Order[]> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return []
    }

    // First, get all orders for the user
    const { data: orders, error: ordersError } = await supabase
      .from("orders")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (ordersError) {
      console.error("Error fetching orders:", ordersError)
      return []
    }

    // If no orders, return empty array
    if (!orders || orders.length === 0) {
      return []
    }

    // For each order, get its items
    const ordersWithItems = await Promise.all(
      orders.map(async (order) => {
        const { data: items, error: itemsError } = await supabase
          .from("order_items")
          .select("*")
          .eq("order_id", order.id)

        if (itemsError) {
          console.error(`Error fetching items for order ${order.id}:`, itemsError)
          return mapDatabaseOrderToOrder(order, [])
        }

        return mapDatabaseOrderToOrder(order, items || [])
      }),
    )

    return ordersWithItems
  } catch (error) {
    console.error("Error in getUserOrders:", error)
    return []
  }
}

export async function getOrderById(orderId: string): Promise<Order | null> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return null
    }

    // Get the order
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select("*")
      .eq("id", orderId)
      .eq("user_id", userId)
      .single()

    if (orderError) {
      console.error(`Error fetching order ${orderId}:`, orderError)
      return null
    }

    // Get the order items
    const { data: items, error: itemsError } = await supabase.from("order_items").select("*").eq("order_id", orderId)

    if (itemsError) {
      console.error(`Error fetching items for order ${orderId}:`, itemsError)
      return mapDatabaseOrderToOrder(order, [])
    }

    return mapDatabaseOrderToOrder(order, items || [])
  } catch (error) {
    console.error("Error in getOrderById:", error)
    return null
  }
}

// Helper function to map database order to our Order type
function mapDatabaseOrderToOrder(dbOrder: any, dbItems: any[]): Order {
  const items: OrderItem[] = dbItems.map((item) => ({
    id: item.id,
    name: item.name,
    quantity: item.quantity,
    price: Number(item.price),
    image: item.image || "/placeholder.svg",
  }))

  return {
    id: dbOrder.id,
    date: dbOrder.created_at,
    items,
    total: Number(dbOrder.total),
    status: dbOrder.status,
    paymentStatus: dbOrder.payment_status,
    trackingNumber: dbOrder.tracking_number || "",
    carrier: dbOrder.carrier || "",
  }
}
