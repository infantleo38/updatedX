export interface Product {
  id: string
  name: string
  description?: string
  price: number
  originalPrice?: number
  rating: number
  image: string
  images?: string[]
  category: string
  subcategory?: string
  tags?: string[]
  sizes?: string[]
  colors?: string[]
  isNew?: boolean
  isSale?: boolean
  stock?: number
}

export interface User {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
  createdAt: string
}

export interface Address {
  id: string
  name: string
  street: string
  apartment?: string
  city: string
  state: string
  zipCode: string
  country: string
  isDefault: boolean
  phone: string
}

export interface OrderItem {
  id: string
  name: string
  quantity: number
  price: number
  image: string
}

export interface Order {
  id: string
  date: string
  items: OrderItem[]
  total: number
  status: string
  paymentStatus: string
  trackingNumber?: string
  carrier?: string
}

export interface TrackingEvent {
  date: string
  time: string
  location: string
  status: string
  description: string
}

export interface TrackingInfo {
  orderId: string
  trackingId: string
  carrier: string
  estimatedDelivery: string
  status: string
  currentLocation: string
  events: TrackingEvent[]
}
