"use client"

import type React from "react"

import Image from "next/image"
import { cn } from "@/lib/utils"
import { Check } from "lucide-react"
import type { DesignState } from "./t-shirt-customizer"

interface TShirtModelSelectorProps {
  designState: DesignState
  setDesignState: React.Dispatch<React.SetStateAction<DesignState>>
}

const TSHIRT_MODELS = [
  {
    id: "round-neck",
    name: "Round Neck",
    description: "Classic crew neck t-shirt",
    price: 25,
  },
  {
    id: "v-neck",
    name: "V-Neck",
    description: "Stylish v-neck design",
    price: 28,
  },
  {
    id: "full-sleeve",
    name: "Full Sleeve",
    description: "Long sleeve t-shirt",
    price: 32,
  },
  {
    id: "crop-top",
    name: "Crop Top",
    description: "Trendy cropped style",
    price: 30,
  },
] as const

export function TShirtModelSelector({ designState, setDesignState }: TShirtModelSelectorProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {TSHIRT_MODELS.map((model) => (
        <div
          key={model.id}
          className={cn(
            "border rounded-lg p-4 cursor-pointer transition-all",
            designState.model === model.id
              ? "border-primary bg-primary/5 ring-2 ring-primary ring-offset-2"
              : "hover:border-gray-300 hover:bg-gray-50",
          )}
          onClick={() => setDesignState((prev) => ({ ...prev, model: model.id as DesignState["model"] }))}
        >
          <div className="aspect-square relative mb-3">
            {/* Using the same temporary image for all models */}
            <Image src="/temp-tshirt.jpg" alt={model.name} fill className="object-contain p-2" />
            {designState.model === model.id && (
              <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                <Check className="h-4 w-4" />
              </div>
            )}
          </div>
          <h3 className="font-medium text-center">{model.name}</h3>
          <p className="text-xs text-muted-foreground text-center mt-1">{model.description}</p>
          <p className="text-sm font-medium text-center mt-2">${model.price}</p>
        </div>
      ))}
    </div>
  )
}
