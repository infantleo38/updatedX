"use client"

import { Line, Bar } from "react-chartjs-2"
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  type ChartOptions,
} from "chart.js"

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend)

// Sales Chart Component
export function SalesChart({ data = [] }: { data?: Array<{ date: string; total: number }> }) {
  // If no data is provided, use sample data
  const chartData = data.length
    ? data
    : Array.from({ length: 30 }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() - (29 - i))
        return {
          date: date.toISOString().split("T")[0],
          total: Math.floor(Math.random() * 1000) + 500,
        }
      })

  const labels = chartData.map((item) => {
    const date = new Date(item.date)
    return `${date.getMonth() + 1}/${date.getDate()}`
  })

  const values = chartData.map((item) => item.total)

  const options: ChartOptions<"line"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: (context) => `$${context.parsed.y.toFixed(2)}`,
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
      },
      y: {
        beginAtZero: true,
        ticks: {
          callback: (value) => `$${value}`,
        },
      },
    },
  }

  const chartDataConfig = {
    labels,
    datasets: [
      {
        label: "Sales",
        data: values,
        borderColor: "rgb(99, 102, 241)",
        backgroundColor: "rgba(99, 102, 241, 0.1)",
        borderWidth: 2,
        fill: true,
        tension: 0.4,
      },
    ],
  }

  return (
    <div className="h-[300px] w-full">
      <Line options={options} data={chartDataConfig} />
    </div>
  )
}

// Product Popularity Chart
export function ProductPopularityChart({ data = [] }: { data?: Array<{ name: string; count: number }> }) {
  // If no data is provided, use sample data
  const chartData = data.length
    ? data
    : [
        { name: "Round Neck", count: 120 },
        { name: "V-Neck", count: 98 },
        { name: "Full Sleeve", count: 65 },
        { name: "Crop Top", count: 45 },
        { name: "Hoodie", count: 30 },
      ]

  const labels = chartData.map((item) => item.name)
  const values = chartData.map((item) => item.count)

  const options: ChartOptions<"bar"> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
      },
      y: {
        beginAtZero: true,
      },
    },
  }

  const chartDataConfig = {
    labels,
    datasets: [
      {
        label: "Orders",
        data: values,
        backgroundColor: [
          "rgba(99, 102, 241, 0.8)",
          "rgba(79, 70, 229, 0.8)",
          "rgba(67, 56, 202, 0.8)",
          "rgba(55, 48, 163, 0.8)",
          "rgba(49, 46, 129, 0.8)",
        ],
        borderWidth: 0,
        borderRadius: 4,
      },
    ],
  }

  return (
    <div className="h-[300px] w-full">
      <Bar options={options} data={chartDataConfig} />
    </div>
  )
}
