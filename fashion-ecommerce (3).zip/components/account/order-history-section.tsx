"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Search, Package, Truck, CheckCircle, AlertCircle, ChevronRight } from "lucide-react"
import { formatDate, formatCurrency } from "@/lib/utils"
import type { Order, TrackingInfo } from "@/lib/types"

interface OrderHistorySectionProps {
  orders: Order[]
}

export default function OrderHistorySection({ orders }: OrderHistorySectionProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isTrackingOpen, setIsTrackingOpen] = useState(false)
  const [trackingInfo, setTrackingInfo] = useState<TrackingInfo | null>(null)

  // Filter orders based on search query and status filter
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.items.some((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesStatus = statusFilter === "all" || order.status.toLowerCase() === statusFilter.toLowerCase()

    return matchesSearch && matchesStatus
  })

  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return "bg-blue-50 text-blue-600 hover:bg-blue-50"
      case "shipped":
        return "bg-amber-50 text-amber-600 hover:bg-amber-50"
      case "delivered":
        return "bg-green-50 text-green-600 hover:bg-green-50"
      case "cancelled":
        return "bg-red-50 text-red-600 hover:bg-red-50"
      default:
        return "bg-gray-50 text-gray-600 hover:bg-gray-50"
    }
  }

  // Get payment status badge color
  const getPaymentStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "paid":
        return "bg-green-50 text-green-600 hover:bg-green-50"
      case "pending":
        return "bg-amber-50 text-amber-600 hover:bg-amber-50"
      case "failed":
        return "bg-red-50 text-red-600 hover:bg-red-50"
      case "refunded":
        return "bg-purple-50 text-purple-600 hover:bg-purple-50"
      default:
        return "bg-gray-50 text-gray-600 hover:bg-gray-50"
    }
  }

  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "processing":
        return <Package className="h-5 w-5" />
      case "shipped":
        return <Truck className="h-5 w-5" />
      case "delivered":
        return <CheckCircle className="h-5 w-5" />
      case "cancelled":
        return <AlertCircle className="h-5 w-5" />
      default:
        return <Package className="h-5 w-5" />
    }
  }

  // Handle tracking button click
  const handleTrackOrder = (order: Order) => {
    setSelectedOrder(order)

    // In a real app, this would be an API call to get tracking info
    // For now, we'll simulate with mock data
    const mockTrackingInfo: TrackingInfo = {
      orderId: order.id,
      trackingId: order.trackingNumber || "Not available",
      carrier: order.carrier || "Not assigned",
      estimatedDelivery: "April 15, 2023",
      status: order.status,
      currentLocation: "New York, NY",
      events: [
        {
          date: "April 13, 2023",
          time: "10:23 AM",
          location: "New York, NY",
          status: "In Transit",
          description: "Package is in transit to the destination",
        },
        {
          date: "April 12, 2023",
          time: "4:15 PM",
          location: "New York, NY",
          status: "Shipped",
          description: "Package has left the carrier facility",
        },
        {
          date: "April 12, 2023",
          time: "11:42 AM",
          location: "New York, NY",
          status: "Processing",
          description: "Package has been processed at carrier facility",
        },
        {
          date: "April 12, 2023",
          time: "9:30 AM",
          location: "New York, NY",
          status: "Label Created",
          description: "Shipping label has been created",
        },
      ],
    }

    setTrackingInfo(mockTrackingInfo)
    setIsTrackingOpen(true)
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Order History</CardTitle>
          <CardDescription>View and track your previous orders</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search orders by ID or product"
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Tabs value={statusFilter} onValueChange={setStatusFilter} className="w-full sm:w-auto">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="processing">Processing</TabsTrigger>
                <TabsTrigger value="shipped">Shipped</TabsTrigger>
                <TabsTrigger value="delivered">Delivered</TabsTrigger>
                <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Orders List */}
          {filteredOrders.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No orders found matching your criteria.</p>
              <Button
                onClick={() => {
                  setSearchQuery("")
                  setStatusFilter("all")
                }}
              >
                Clear Filters
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => (
                <div key={order.id} className="border rounded-lg overflow-hidden">
                  {/* Order Header */}
                  <div className="bg-muted/30 p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-medium">Order #{order.id}</h3>
                          <Badge variant="outline" className={getStatusColor(order.status)}>
                            {order.status}
                          </Badge>
                          <Badge variant="outline" className={getPaymentStatusColor(order.paymentStatus)}>
                            {order.paymentStatus}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Placed on {formatDate(order.date)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleTrackOrder(order)}
                          disabled={!order.trackingNumber}
                        >
                          <Truck className="mr-2 h-4 w-4" /> Track Order
                        </Button>
                        <Button size="sm" asChild>
                          <Link href={`/orders/${order.id}`}>View Details</Link>
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="p-4">
                    <div className="space-y-4">
                      {order.items.map((item) => (
                        <div key={item.id} className="flex items-start gap-4">
                          <div className="w-16 h-16 bg-gray-100 rounded-md relative flex-shrink-0">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-contain p-1"
                            />
                          </div>
                          <div className="flex-grow">
                            <p className="font-medium">{item.name}</p>
                            <p className="text-sm text-muted-foreground">
                              Qty: {item.quantity} × ${item.price.toFixed(2)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 pt-4 border-t flex justify-between items-center">
                      <div>
                        <p className="text-sm text-muted-foreground">
                          {order.items.reduce((sum, item) => sum + item.quantity, 0)} items
                        </p>
                      </div>
                      <p className="font-medium">Total: {formatCurrency(order.total)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tracking Dialog */}
      <Dialog open={isTrackingOpen} onOpenChange={setIsTrackingOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Track Order #{selectedOrder?.id}</DialogTitle>
            <DialogDescription>Real-time tracking information for your order</DialogDescription>
          </DialogHeader>

          {trackingInfo && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Tracking Number</p>
                  <p className="font-medium">{trackingInfo.trackingId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Carrier</p>
                  <p className="font-medium">{trackingInfo.carrier}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="font-medium">{trackingInfo.status}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Estimated Delivery</p>
                  <p className="font-medium">{trackingInfo.estimatedDelivery}</p>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-4">Tracking History</h3>
                <div className="relative">
                  {/* Timeline line */}
                  <div className="absolute left-2.5 top-2 bottom-2 w-0.5 bg-gray-200"></div>

                  {/* Timeline events */}
                  <div className="space-y-6">
                    {trackingInfo.events.map((event, index) => (
                      <div key={index} className="flex gap-4">
                        <div
                          className={`relative flex items-center justify-center w-5 h-5 rounded-full mt-1 ${
                            index === 0 ? "bg-primary text-primary-foreground" : "bg-gray-200"
                          }`}
                        >
                          {getStatusIcon(event.status)}
                        </div>
                        <div>
                          <p className="font-medium">{event.status}</p>
                          <p className="text-sm">{event.description}</p>
                          <p className="text-xs text-muted-foreground">
                            {event.date} at {event.time} • {event.location}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setIsTrackingOpen(false)}>
                  Close
                </Button>
                <Button asChild>
                  <Link href={`/orders/${selectedOrder?.id}`}>
                    View Order Details <ChevronRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  )
}
