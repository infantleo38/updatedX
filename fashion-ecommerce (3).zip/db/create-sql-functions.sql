-- Function to execute arbitrary SQL
CREATE OR REPLACE FUNCTION exec_sql(sql_query TEXT)
RETURNS VOID AS $$
BEGIN
  EXECUTE sql_query;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create UUID extension if it doesn't exist
CREATE OR REPLACE FUNCTION create_uuid_extension_if_not_exists()
RETURNS VOID AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_extension WHERE extname = 'uuid-ossp'
  ) THEN
    CREATE EXTENSION "uuid-ossp";
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create UUID extension directly
CREATE OR REPLACE FUNCTION create_uuid_extension()
RETURNS VOID AS $$
BEGIN
  CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create user_activities table
CREATE OR REPLACE FUNCTION create_user_activities_table()
RETURNS VOID AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS public.user_activities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID,
    session_id TEXT NOT NULL,
    activity_type TEXT NOT NULL,
    page TEXT,
    duration INTEGER,
    ip_address TEXT,
    user_agent TEXT,
    device_type TEXT,
    referrer TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    timestamp TIMESTAMPTZ DEFAULT NOW()
  );
  
  CREATE INDEX IF NOT EXISTS idx_user_activities_user_id ON public.user_activities(user_id);
  CREATE INDEX IF NOT EXISTS idx_user_activities_session_id ON public.user_activities(session_id);
  CREATE INDEX IF NOT EXISTS idx_user_activities_activity_type ON public.user_activities(activity_type);
  CREATE INDEX IF NOT EXISTS idx_user_activities_timestamp ON public.user_activities(timestamp);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create search_queries table
CREATE OR REPLACE FUNCTION create_search_queries_table()
RETURNS VOID AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS public.search_queries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID,
    session_id TEXT NOT NULL,
    query TEXT NOT NULL,
    results_count INTEGER DEFAULT 0,
    timestamp TIMESTAMPTZ DEFAULT NOW()
  );
  
  CREATE INDEX IF NOT EXISTS idx_search_queries_query ON public.search_queries(query);
  CREATE INDEX IF NOT EXISTS idx_search_queries_timestamp ON public.search_queries(timestamp);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
