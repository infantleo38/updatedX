import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs"

export async function middleware(req: NextRequest) {
  const res = NextResponse.next()
  const supabase = createMiddlewareClient({ req, res })

  // Check if we have a session
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Get the pathname
  const path = req.nextUrl.pathname

  // Admin routes protection
  if (path.startsWith("/admin")) {
    if (!session) {
      // Redirect to login if no session
      return NextResponse.redirect(new URL("/auth/login", req.url))
    }

    // Check if user has admin role
    const { data: userData, error } = await supabase.from("users").select("role").eq("id", session.user.id).single()

    if (error || !userData || userData.role !== "admin") {
      // Redirect to unauthorized page if not admin
      return NextResponse.redirect(new URL("/unauthorized", req.url))
    }
  }

  // Protected user routes
  if (path.startsWith("/account") || path.startsWith("/checkout") || path.startsWith("/orders")) {
    if (!session) {
      // Redirect to login if no session
      return NextResponse.redirect(new URL("/auth/login", req.url))
    }
  }

  return res
}

// Only run middleware on matching routes
export const config = {
  matcher: ["/admin/:path*", "/account/:path*", "/checkout/:path*", "/orders/:path*"],
}
