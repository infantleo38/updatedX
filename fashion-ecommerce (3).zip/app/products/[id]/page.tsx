import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ChevronRight, Star, Truck, RotateCcw, Shield } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getProductById, getFeaturedProducts } from "@/lib/products"
import ProductCard from "@/components/product-card"
import { ProductCardButtons } from "@/components/product-card-buttons"

interface ProductPageProps {
  params: {
    id: string
  }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { id } = params

  // Get product details
  const product = await getProductById(id)

  if (!product) {
    notFound()
  }

  // Get related products
  const relatedProducts = await getFeaturedProducts()

  return (
    <main className="flex-1">
      <div className="container px-4 md:px-6 py-6 md:py-8">
        <div className="flex items-center gap-1 text-sm text-muted-foreground mb-4">
          <Link href="/" className="hover:text-primary">
            Home
          </Link>
          <ChevronRight className="h-4 w-4" />
          <Link href={`/categories/${product.category.toLowerCase()}`} className="hover:text-primary">
            {product.category}
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span className="font-medium text-foreground">{product.name}</span>
        </div>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square overflow-hidden rounded-lg border bg-muted">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={600}
                height={600}
                className="h-full w-full object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square overflow-hidden rounded-lg border bg-muted">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={`${product.name} thumbnail ${i + 1}`}
                    width={150}
                    height={150}
                    className="h-full w-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <div className="mt-2 flex items-center gap-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-5 w-5 ${i < product.rating ? "fill-primary text-primary" : "fill-muted text-muted"}`}
                    />
                  ))}
                  <span className="ml-2 text-sm text-muted-foreground">{product.rating.toFixed(1)} (24 reviews)</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-3xl font-bold">${product.price.toFixed(2)}</span>
              {product.originalPrice && (
                <span className="text-xl text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
              )}
              {product.originalPrice && (
                <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-sm font-medium text-red-800">
                  {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                </span>
              )}
            </div>

            <p className="text-muted-foreground">
              {product.description || "No description available for this product."}
            </p>

            <div className="space-y-4">
              <div>
                <label htmlFor="size" className="text-sm font-medium">
                  Size
                </label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {["XS", "S", "M", "L", "XL"].map((size) => (
                    <Button key={size} variant="outline" className="h-10 w-10 rounded-md p-0">
                      {size}
                    </Button>
                  ))}
                </div>
              </div>

              <div>
                <label htmlFor="color" className="text-sm font-medium">
                  Color
                </label>
                <div className="mt-2 flex flex-wrap gap-2">
                  {["Black", "White", "Blue", "Red"].map((color) => (
                    <Button key={color} variant="outline" className="rounded-md">
                      {color}
                    </Button>
                  ))}
                </div>
              </div>
            </div>

            {/* Updated to use ProductCardButtons */}
            <div className="mt-6">
              <ProductCardButtons product={product} size="lg" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="flex items-center gap-2">
                <Truck className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm">Free shipping</span>
              </div>
              <div className="flex items-center gap-2">
                <RotateCcw className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm">30-day returns</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm">2-year warranty</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12">
          <Tabs defaultValue="description">
            <TabsList className="w-full justify-start border-b rounded-none">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="reviews">Reviews (24)</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="pt-4">
              <div className="prose max-w-none">
                <p>{product.description || "No description available for this product."}</p>
              </div>
            </TabsContent>
            <TabsContent value="details" className="pt-4">
              <div className="prose max-w-none">
                <ul>
                  <li>Material: 100% Cotton</li>
                  <li>Care: Machine wash cold</li>
                  <li>Imported</li>
                  <li>Model is 6'0" and wears size M</li>
                </ul>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="pt-4">
              <div className="space-y-4">
                <p>Customer reviews will be displayed here.</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <section className="mt-16">
          <h2 className="text-2xl font-bold mb-6">You May Also Like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {relatedProducts.slice(0, 4).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </div>
    </main>
  )
}
