"use client"

import { useEffect, useState } from "react"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"

export function ActivityTracker() {
  const pathname = usePathname()
  const [userId, setUserId] = useState<string | undefined>(undefined)
  const [authReady, setAuthReady] = useState(false)

  useEffect(() => {
    try {
      const auth = useAuth()
      setUserId(auth?.user?.id)
    } catch (error) {
      console.log("Auth context not available, tracking as anonymous user")
    } finally {
      setAuthReady(true)
    }
  }, [])

  useEffect(() => {
    if (!authReady) return

    // Skip tracking for admin pages
    if (pathname.startsWith("/admin")) return

    // Simple client-side tracking as a fallback
    const trackPageView = async () => {
      try {
        // Use fetch API directly as a fallback
        await fetch("/api/track", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId: userId || "anonymous",
            activityType: "page_view",
            page: pathname,
            referrer: document.referrer || "direct",
            userAgent: navigator.userAgent,
          }),
        })
      } catch (error) {
        // Silently fail - tracking should not affect user experience
        console.error("Fallback tracking failed:", error)
      }
    }

    trackPageView()
  }, [pathname, userId, authReady])

  // This component doesn't render anything
  return null
}
