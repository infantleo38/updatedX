"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import Link from "next/link"
import Image from "next/image"
import { ChevronLeft, Trash2, Minus, Plus, RefreshCw, Loader2 } from "lucide-react"
import { useCart } from "@/contexts/cart-context"
import { useRouter } from "next/navigation"

// Function to get model display name
function getModelDisplayName(modelId: string): string {
  switch (modelId) {
    case "round-neck":
      return "Round Neck"
    case "v-neck":
      return "V-Neck"
    case "full-sleeve":
      return "Full Sleeve"
    case "crop-top":
      return "Crop Top"
    default:
      return "T-Shirt"
  }
}

// Using temporary T-shirt image for all models and views
function getTshirtImageSrc(): string {
  return "/temp-tshirt.jpg"
}

export default function CartPage() {
  const router = useRouter()
  const { items, removeItem, updateQuantity, subtotal, discount, shipping, tax, total, applyCoupon } = useCart()

  const [couponCode, setCouponCode] = useState("")
  const [isApplyingCoupon, setIsApplyingCoupon] = useState(false)
  const [isCheckingOut, setIsCheckingOut] = useState(false)

  const handleQuantityChange = (id: string, newQuantity: number) => {
    updateQuantity(id, newQuantity)
  }

  const handleRemoveItem = (id: string) => {
    removeItem(id)
  }

  const handleApplyCoupon = async () => {
    if (!couponCode) return

    setIsApplyingCoupon(true)
    await applyCoupon(couponCode)
    setIsApplyingCoupon(false)
  }

  const handleCheckout = () => {
    setIsCheckingOut(true)

    // Simulate a slight delay for better UX
    setTimeout(() => {
      router.push("/checkout")
    }, 500)
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-5xl">
      <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>

      {items.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow-sm">
          <div className="max-w-md mx-auto">
            <h2 className="text-xl font-bold mb-2">Your cart is empty</h2>
            <p className="text-muted-foreground mb-6">Looks like you haven't added any items to your cart yet.</p>
            <Button asChild>
              <Link href="/customize">Design a Custom T-Shirt</Link>
            </Button>
          </div>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="p-6 border-b">
                <h2 className="text-xl font-bold">Items ({items.length})</h2>
              </div>

              <div className="divide-y">
                {items.map((item) => {
                  const modelName = getModelDisplayName(item.model)
                  const itemTotal = item.price * item.quantity

                  return (
                    <div key={item.id} className="p-6 flex flex-col sm:flex-row gap-6">
                      <div className="w-full sm:w-32 h-32 bg-gray-100 rounded-md relative flex-shrink-0">
                        <Image
                          src={item.image || getTshirtImageSrc()}
                          alt={`${modelName} ${item.side} view`}
                          fill
                          className="object-contain"
                        />
                      </div>

                      <div className="flex-grow">
                        <div className="flex flex-col sm:flex-row sm:justify-between">
                          <div>
                            <h3 className="font-medium mb-1">{item.name}</h3>
                            <p className="text-sm text-muted-foreground mb-2">
                              Size: {item.tshirtSize} • Color: {item.tshirtColor} • View: {item.side}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${item.price.toFixed(2)}</p>
                            <p className="text-sm text-muted-foreground">Item Price</p>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mt-4 gap-4">
                          <div className="flex items-center">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8 rounded-md"
                              onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="w-12 text-center">{item.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8 rounded-md"
                              onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>

                          <div className="flex items-center gap-4">
                            {item.isCustom && (
                              <Button variant="ghost" size="sm" className="text-primary hover:text-primary" asChild>
                                <Link href={`/customize?design=${item.id}`}>
                                  <RefreshCw className="mr-1 h-4 w-4" /> Edit Design
                                </Link>
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-red-500 hover:text-red-600 hover:bg-red-50"
                              onClick={() => handleRemoveItem(item.id)}
                            >
                              <Trash2 className="mr-1 h-4 w-4" /> Remove
                            </Button>
                          </div>
                        </div>

                        <div className="mt-4 text-right">
                          <p className="font-medium">Subtotal: ${itemTotal.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            <div className="mt-6">
              <Button variant="outline" asChild className="flex items-center">
                <Link href="/">
                  <ChevronLeft className="h-4 w-4 mr-2" /> Continue Shopping
                </Link>
              </Button>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
              <h2 className="text-xl font-bold mb-4">Apply Coupon</h2>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter coupon code"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                />
                <Button onClick={handleApplyCoupon} disabled={!couponCode || isApplyingCoupon}>
                  {isApplyingCoupon ? "Applying..." : "Apply"}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Try "SAVE10" for 10% off or "FREESHIP" for free shipping
              </p>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount</span>
                    <span>-${discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>{shipping > 0 ? `$${shipping.toFixed(2)}` : "Free"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
              </div>

              <Separator className="my-4" />

              <div className="flex justify-between font-bold text-lg mb-6">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>

              <Button className="w-full" size="lg" onClick={handleCheckout} disabled={isCheckingOut}>
                {isCheckingOut ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                  </>
                ) : (
                  "Proceed to Checkout"
                )}
              </Button>

              <div className="mt-4 flex items-center justify-center gap-2">
                <Image src="/payment/visa.svg" alt="Visa" width={32} height={20} />
                <Image src="/payment/mastercard.svg" alt="Mastercard" width={32} height={20} />
                <Image src="/payment/paypal.svg" alt="PayPal" width={32} height={20} />
                <Image src="/payment/apple-pay.svg" alt="Apple Pay" width={32} height={20} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
