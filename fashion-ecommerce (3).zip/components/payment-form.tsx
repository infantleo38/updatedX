"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CreditCard, ShoppingCartIcon as Paypal } from "lucide-react"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"
import { useCart } from "@/contexts/cart-context"

interface PaymentFormProps {
  onSuccess: (orderId: string) => void
}

export function PaymentForm({ onSuccess }: PaymentFormProps) {
  const router = useRouter()
  const { toast } = useToast()
  const { total } = useCart()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [shippingMethod, setShippingMethod] = useState("standard")
  const [paymentMethod, setPaymentMethod] = useState("card")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call to process payment and create order
    setTimeout(() => {
      setIsSubmitting(false)

      // Generate a random order ID
      const orderId = `XL${new Date().getFullYear()}${Math.floor(Math.random() * 1000)}`

      // Show success toast
      toast({
        title: "Order placed successfully!",
        description: "Your order has been confirmed. Check your email for details.",
      })

      // Call the success callback with the order ID
      onSuccess(orderId)
    }, 1500)
  }

  return (
    <form onSubmit={handleSubmit}>
      {/* Billing Information */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Billing Information</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="firstName">First Name</Label>
            <Input id="firstName" placeholder="John" required />
          </div>
          <div>
            <Label htmlFor="lastName">Last Name</Label>
            <Input id="lastName" placeholder="Doe" required />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="john.doe@example.com" required />
          </div>
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" type="tel" placeholder="+1 (555) 123-4567" required />
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="address">Address</Label>
            <Input id="address" placeholder="123 Main St" required />
          </div>
          <div>
            <Label htmlFor="city">City</Label>
            <Input id="city" placeholder="New York" required />
          </div>
          <div>
            <Label htmlFor="postalCode">Postal Code</Label>
            <Input id="postalCode" placeholder="10001" required />
          </div>
          <div>
            <Label htmlFor="state">State</Label>
            <Input id="state" placeholder="NY" required />
          </div>
          <div>
            <Label htmlFor="country">Country</Label>
            <Input id="country" placeholder="United States" required />
          </div>
        </div>
      </div>

      {/* Shipping Method */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Shipping Method</h2>
        <RadioGroup value={shippingMethod} onValueChange={setShippingMethod}>
          <div className="flex items-center space-x-2 mb-2">
            <RadioGroupItem value="standard" id="standard" />
            <Label htmlFor="standard" className="flex justify-between w-full">
              <span>Standard Shipping (3-5 business days)</span>
              <span>$5.00</span>
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="express" id="express" />
            <Label htmlFor="express" className="flex justify-between w-full">
              <span>Express Shipping (1-2 business days)</span>
              <span>$12.00</span>
            </Label>
          </div>
        </RadioGroup>
      </div>

      {/* Payment Method */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Payment Method</h2>
        <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="card" className="flex items-center">
              <CreditCard className="mr-2 h-4 w-4" /> Credit/Debit Card
            </TabsTrigger>
            <TabsTrigger value="paypal" className="flex items-center">
              <Paypal className="mr-2 h-4 w-4" /> PayPal
            </TabsTrigger>
          </TabsList>
          <TabsContent value="card" className="pt-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="cardName">Name on Card</Label>
                <Input id="cardName" placeholder="John Doe" required />
              </div>
              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input id="cardNumber" placeholder="1234 5678 9012 3456" required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input id="expiry" placeholder="MM/YY" required />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" placeholder="123" required />
                </div>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="paypal" className="pt-4">
            <div className="text-center p-6">
              <p className="mb-4">You will be redirected to PayPal to complete your payment.</p>
              <Image src="/payment/paypal-full.svg" alt="PayPal" width={200} height={80} className="mx-auto" />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Button type="submit" className="w-full" size="lg" disabled={isSubmitting}>
        {isSubmitting ? "Processing..." : `Place Order • $${total.toFixed(2)}`}
      </Button>
    </form>
  )
}
