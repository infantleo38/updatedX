import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const body = await request.json()

    return NextResponse.json({
      success: true,
      message: "Debug API is working",
      receivedData: body,
      timestamp: new Date().toISOString(),
    })
  } catch (error: any) {
    return NextResponse.json(
      {
        success: false,
        error: error.message || "An unexpected error occurred",
      },
      { status: 500 },
    )
  }
}
