"use client"

import { useState } from "react"
import Image from "next/image"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

interface DesignGalleryProps {
  isOpen: boolean
  onClose: () => void
  onSelect: (imageUrl: string) => void
}

// Mock gallery items
const GALLERY_ITEMS = [
  {
    category: "Logos",
    items: [
      { id: "logo1", name: "Mountain Logo", url: "/gallery/logo-1.png" },
      { id: "logo2", name: "Wave Logo", url: "/gallery/logo-2.png" },
      { id: "logo3", name: "Tree Logo", url: "/gallery/logo-3.png" },
      { id: "logo4", name: "Fire Logo", url: "/gallery/logo-4.png" },
      { id: "logo5", name: "Star Logo", url: "/gallery/logo-5.png" },
      { id: "logo6", name: "Shield Logo", url: "/gallery/logo-6.png" },
    ],
  },
  {
    category: "Icons",
    items: [
      { id: "icon1", name: "Heart Icon", url: "/gallery/icon-1.png" },
      { id: "icon2", name: "Smile Icon", url: "/gallery/icon-2.png" },
      { id: "icon3", name: "Sun Icon", url: "/gallery/icon-3.png" },
      { id: "icon4", name: "Moon Icon", url: "/gallery/icon-4.png" },
      { id: "icon5", name: "Star Icon", url: "/gallery/icon-5.png" },
      { id: "icon6", name: "Cloud Icon", url: "/gallery/icon-6.png" },
    ],
  },
  {
    category: "Text",
    items: [
      { id: "text1", name: "Cool Text", url: "/gallery/text-1.png" },
      { id: "text2", name: "Awesome Text", url: "/gallery/text-2.png" },
      { id: "text3", name: "Happy Text", url: "/gallery/text-3.png" },
      { id: "text4", name: "Love Text", url: "/gallery/text-4.png" },
      { id: "text5", name: "Peace Text", url: "/gallery/text-5.png" },
      { id: "text6", name: "Joy Text", url: "/gallery/text-6.png" },
    ],
  },
]

export function DesignGallery({ isOpen, onClose, onSelect }: DesignGalleryProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState(GALLERY_ITEMS[0].category)

  const filteredItems = GALLERY_ITEMS.map((category) => ({
    ...category,
    items: category.items.filter((item) => item.name.toLowerCase().includes(searchQuery.toLowerCase())),
  }))

  // Function to get a placeholder image if the gallery image is not available
  const getImageSrc = (url: string) => {
    return url || "/placeholder.svg"
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Choose a Design</DialogTitle>
        </DialogHeader>

        <div className="relative mb-4">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search designs..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <Tabs defaultValue={activeCategory} onValueChange={setActiveCategory}>
          <TabsList className="w-full justify-start mb-4 overflow-x-auto">
            {GALLERY_ITEMS.map((category) => (
              <TabsTrigger key={category.category} value={category.category}>
                {category.category}
              </TabsTrigger>
            ))}
          </TabsList>

          {filteredItems.map((category) => (
            <TabsContent key={category.category} value={category.category}>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {category.items.length > 0 ? (
                  category.items.map((item) => (
                    <div
                      key={item.id}
                      className="border rounded-md p-2 cursor-pointer hover:border-primary transition-colors"
                      onClick={() => onSelect(item.url)}
                    >
                      <div className="aspect-square relative mb-2">
                        <Image
                          src={getImageSrc(item.url) || "/placeholder.svg"}
                          alt={item.name}
                          fill
                          className="object-contain p-2"
                        />
                      </div>
                      <p className="text-xs text-center truncate">{item.name}</p>
                    </div>
                  ))
                ) : (
                  <div className="col-span-3 py-8 text-center text-muted-foreground">
                    No designs found matching your search.
                  </div>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
