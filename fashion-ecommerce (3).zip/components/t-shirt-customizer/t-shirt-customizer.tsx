"use client"

import React from "react"

import { useState } from "react"
import { TShirtPreview } from "./t-shirt-preview"
import { DesignTools } from "./design-tools"
import { DesignActions } from "./design-actions"
import { DesignGallery } from "./design-gallery"
import { TShirtOptions } from "./t-shirt-options"
import { TShirtModelSelector } from "./t-shirt-model-selector"
import { useToast } from "@/hooks/use-toast"
import { useActivityTracking } from "@/hooks/use-activity-tracking"

export interface DesignState {
  model: "round-neck" | "v-neck" | "full-sleeve" | "crop-top"
  side: "front" | "back"
  image: string | null
  position: { x: number; y: number }
  scale: number
  rotation: number
  tshirtColor: string
  tshirtSize: string
}

export default function TShirtCustomizer() {
  const { toast } = useToast()
  const [isGalleryOpen, setIsGalleryOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [designState, setDesignState] = useState<DesignState>({
    model: "round-neck",
    side: "front",
    image: null,
    position: { x: 0, y: 0 },
    scale: 1,
    rotation: 0,
    tshirtColor: "#FFFFFF",
    tshirtSize: "M",
  })

  const { trackCustomization } = useActivityTracking()
  const startTime = React.useRef(Date.now())

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          setDesignState({
            ...designState,
            image: e.target.result as string,
            position: { x: 0, y: 0 },
            scale: 1,
            rotation: 0,
          })
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const handleGallerySelect = (imageUrl: string) => {
    if (!imageUrl) return // Prevent empty strings

    setDesignState({
      ...designState,
      image: imageUrl,
      position: { x: 0, y: 0 },
      scale: 1,
      rotation: 0,
    })
    setIsGalleryOpen(false)
  }

  const handleResetDesign = () => {
    setDesignState({
      ...designState,
      image: null,
      position: { x: 0, y: 0 },
      scale: 1,
      rotation: 0,
    })
  }

  const handleDownloadPreview = () => {
    if (!designState.image) {
      toast({
        title: "No Design Selected",
        description: "Please upload an image or select one from the gallery.",
        variant: "destructive",
      })
      return
    }

    // Create a simple canvas rendering of the design
    const canvas = document.createElement("canvas")
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = 800
    canvas.height = 1000

    // Draw background
    ctx.fillStyle = "#F5F5F5"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Create temporary image for t-shirt
    const tshirtImg = new Image()
    tshirtImg.crossOrigin = "anonymous"
    tshirtImg.onload = () => {
      // Draw t-shirt
      ctx.drawImage(tshirtImg, 0, 0, canvas.width, canvas.height)

      // Create temporary image for design
      if (designState.image) {
        const designImg = new Image()
        designImg.crossOrigin = "anonymous"
        designImg.onload = () => {
          // Calculate position
          const centerX = canvas.width / 2

          // Adjust vertical position based on model
          let centerY = canvas.height / 2.5
          if (designState.model === "crop-top") {
            centerY = canvas.height / 3
          } else if (designState.model === "v-neck") {
            centerY = canvas.height / 2.3
          }

          const designWidth = designImg.width * designState.scale
          const designHeight = designImg.height * designState.scale

          // Save context state
          ctx.save()

          // Translate to center of design
          ctx.translate(centerX + designState.position.x, centerY + designState.position.y)

          // Rotate
          ctx.rotate((designState.rotation * Math.PI) / 180)

          // Draw design centered
          ctx.drawImage(designImg, -designWidth / 2, -designHeight / 2, designWidth, designHeight)

          // Restore context state
          ctx.restore()

          // Add model name and color to the preview
          ctx.fillStyle = "#333"
          ctx.font = "bold 20px Arial"
          ctx.textAlign = "center"

          let modelName = "Round Neck"
          switch (designState.model) {
            case "v-neck":
              modelName = "V-Neck"
              break
            case "full-sleeve":
              modelName = "Full Sleeve"
              break
            case "crop-top":
              modelName = "Crop Top"
              break
          }

          ctx.fillText(`${modelName} T-Shirt - Size ${designState.tshirtSize}`, canvas.width / 2, canvas.height - 60)

          // Generate download link
          const dataUrl = canvas.toDataURL("image/png")
          const link = document.createElement("a")
          link.download = `custom-${designState.model}-tshirt-${Date.now()}.png`
          link.href = dataUrl
          link.click()

          toast({
            title: "Preview Downloaded",
            description: "Your design preview has been downloaded.",
          })

          const duration = Math.floor((Date.now() - startTime.current) / 1000)
          trackCustomization({
            designId: undefined, // If available
            tshirtModel: designState.model,
            duration: duration,
            saved: true,
          })
        }
        designImg.src = designState.image
      }
    }

    // Use the temporary T-shirt image
    tshirtImg.src = "/temp-tshirt.jpg"
  }

  React.useEffect(() => {
    return () => {
      const duration = Math.floor((Date.now() - startTime.current) / 1000)
      trackCustomization({
        tshirtModel: designState.model,
        duration: duration,
        saved: false,
      })
    }
  }, [designState.model])

  return (
    <div className="space-y-8">
      {/* T-shirt Model Selection */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Choose a T-shirt Model</h2>
        <TShirtModelSelector designState={designState} setDesignState={setDesignState} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - T-shirt Preview */}
        <div className="lg:col-span-2 bg-white rounded-lg shadow-sm p-6">
          <TShirtPreview designState={designState} setDesignState={setDesignState} />
        </div>

        {/* Right Column - Controls */}
        <div className="space-y-6">
          {/* Upload & Gallery Options */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-semibold mb-4">Add Your Design</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="image-upload"
                  className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <svg
                      className="w-8 h-8 mb-2 text-gray-500"
                      aria-hidden="true"
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 20 16"
                    >
                      <path
                        stroke="currentColor"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="2"
                        d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"
                      />
                    </svg>
                    <p className="text-xs text-gray-500">Upload Image</p>
                  </div>
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                  />
                </label>
              </div>
              <button
                onClick={() => setIsGalleryOpen(true)}
                className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
              >
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <svg
                    className="w-8 h-8 mb-2 text-gray-500"
                    aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 20 18"
                  >
                    <path
                      stroke="currentColor"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M5 4h1M2 1h16a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1Zm3 9.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Zm7 3.5h2a3 3 0 0 0 3-3v-1.5m-8 0a3 3 0 0 1 3-3h2a3 3 0 0 1 3 3v1.5"
                    />
                  </svg>
                  <p className="text-xs text-gray-500">Choose from Gallery</p>
                </div>
              </button>
            </div>
          </div>

          {/* T-shirt Options */}
          <TShirtOptions designState={designState} setDesignState={setDesignState} />

          {/* Design Tools */}
          {designState.image && <DesignTools designState={designState} setDesignState={setDesignState} />}

          {/* Action Buttons */}
          <DesignActions
            onResetDesign={handleResetDesign}
            onDownloadPreview={handleDownloadPreview}
            hasDesign={!!designState.image}
            isLoading={isLoading}
            designState={designState}
          />
        </div>

        {/* Design Gallery Modal */}
        <DesignGallery isOpen={isGalleryOpen} onClose={() => setIsGalleryOpen(false)} onSelect={handleGallerySelect} />
      </div>
    </div>
  )
}
