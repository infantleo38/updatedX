"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Printer, Package } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample data
const pendingOrders = [
  {
    id: "XL2023512",
    customer: "John Doe",
    date: "2023-06-12T09:45:00",
    items: [
      { id: "item1", name: "Custom Round Neck T-Shirt", quantity: 2, size: "L", color: "Black" },
      { id: "item2", name: "Custom V-Neck T-Shirt", quantity: 1, size: "M", color: "White" },
    ],
    status: "Processing",
    priority: "Normal",
  },
  {
    id: "XL2023476",
    customer: "Emily Wilson",
    date: "2023-06-09T16:15:00",
    items: [
      { id: "item3", name: "Custom Full Sleeve T-Shirt", quantity: 1, size: "XL", color: "Navy" },
      { id: "item4", name: "Custom Round Neck T-Shirt", quantity: 2, size: "S", color: "Red" },
      { id: "item5", name: "Custom V-Neck T-Shirt", quantity: 1, size: "L", color: "Gray" },
    ],
    status: "Processing",
    priority: "High",
  },
  {
    id: "XL2023443",
    customer: "David Miller",
    date: "2023-06-06T09:20:00",
    items: [
      { id: "item6", name: "Custom Round Neck T-Shirt", quantity: 1, size: "M", color: "Green" },
      { id: "item7", name: "Custom Full Sleeve T-Shirt", quantity: 2, size: "L", color: "Black" },
    ],
    status: "Processing",
    priority: "Normal",
  },
]

const readyToShipOrders = [
  {
    id: "XL2023498",
    customer: "Jane Smith",
    date: "2023-06-11T14:30:00",
    items: [
      { id: "item8", name: "Custom V-Neck T-Shirt", quantity: 1, size: "S", color: "Blue" },
      { id: "item9", name: "Custom Round Neck T-Shirt", quantity: 1, size: "M", color: "Black" },
    ],
    status: "Ready to Ship",
    packingCompleted: "2023-06-12T10:15:00",
  },
  {
    id: "XL2023465",
    customer: "Michael Brown",
    date: "2023-06-08T10:05:00",
    items: [
      { id: "item10", name: "Custom Full Sleeve T-Shirt", quantity: 1, size: "L", color: "Gray" },
      { id: "item11", name: "Custom Round Neck T-Shirt", quantity: 1, size: "M", color: "White" },
    ],
    status: "Ready to Ship",
    packingCompleted: "2023-06-09T14:30:00",
  },
]

// Priority badge component
function PriorityBadge({ priority }: { priority: string }) {
  let variant: "default" | "secondary" | "outline" | "destructive" = "outline"

  switch (priority) {
    case "High":
      variant = "destructive"
      break
    case "Normal":
      variant = "secondary"
      break
    case "Low":
      variant = "outline"
      break
  }

  return <Badge variant={variant}>{priority}</Badge>
}

export default function ShippingPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedOrders, setSelectedOrders] = useState<string[]>([])
  const [activeTab, setActiveTab] = useState("pending")
  
  // Filter orders based on search term
  const filteredPendingOrders = pendingOrders.filter(order => 
    order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.customer.toLowerCase().includes(searchTerm.toLowerCase())
  )
  
  const filteredReadyToShipOrders = readyToShipOrders.filter(order => 
    order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    order.customer.toLowerCase().includes(searchTerm.toLowerCase())
  )
  
  // Handle checkbox selection
  const handleSelectOrder = (orderId: string) => {
    setSelectedOrders(prev => 
      prev.includes(orderId) 
        ? prev.filter(id => id !== orderId)
        : [...prev, orderId]
    )
  }
  
  const handleSelectAll = (orders: typeof pendingOrders) => {
    if (selectedOrders.length === orders.length) {
      setSelectedOrders([])
    } else {
      setSelectedOrders(orders.map(order => order.id))
    }
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Shipping & Packing</h1>
          <p className="text-muted-foreground">Manage order packing and shipping</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" disabled={selectedOrders.length === 0}>
            <Printer className="mr-2 h-4 w-4" />
            Print Packing Slips
          </Button>
          <Button disabled={selectedOrders.length === 0}>
            <Package className="mr-2 h-4 w-4" />
            Mark as Packed
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Orders</CardTitle>
          <CardDescription>
            View and manage orders that need to be packed and shipped.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search orders..."
                className="pl-8 bg-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <Tabs defaultValue="pending" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="pending" className="relative">
                Pending Orders
                <Badge className="ml-2 bg-primary/20 text-primary hover:bg-primary/20">
                  {pendingOrders.length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="ready" className="relative">
                Ready to Ship
                <Badge className="ml-2 bg-primary/20 text-primary hover:bg-primary/20">
                  {readyToShipOrders.length}
                </Badge>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="pending" className="m-0">
              <div className="rounded-md border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox 
                          checked={selectedOrders.length === filteredPendingOrders.length && filteredPendingOrders.length > 0}
                          onCheckedChange={() => handleSelectAll(filteredPendingOrders)}
                        />
                      </TableHead>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead className="hidden md:table-cell">Date</TableHead>
                      <TableHead className="hidden md:table-cell">Items</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPendingOrders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <Checkbox 
                            checked={selectedOrders.includes(order.id)}
                            onCheckedChange={() => handleSelectOrder(order.id)}
                          />
                        </TableCell>
                        <TableCell className="font-medium">{order.id}</TableCell>
                        <TableCell>{order.customer}</TableCell>
                        <TableCell className="hidden md:table-cell">
                          {new Date(order.date).toLocaleDateString()}
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          {order.items.length} items
                        </TableCell>
                        <TableCell>
                          <PriorityBadge priority={order.priority} />
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="icon">
                              &lt;Eye className="h-4 w-4" /&gt;
                            </Button>
                          </div>

\
