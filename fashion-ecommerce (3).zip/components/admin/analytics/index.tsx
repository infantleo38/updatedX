"use client"

import { useState, useEffect } from "react"
import {
  getActivityOverview,
  getPopularProducts,
  getPopularCustomizations,
  getConversionFunnel,
  getSearchAnalytics,
  getRecentActivities,
} from "@/app/actions/activity-actions"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import {
  Activity,
  ShoppingCart,
  Users,
  UserCheck,
  Monitor,
  Smartphone,
  Search,
  Eye,
  ShoppingBag,
  Palette,
} from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Helper function to format date
function formatDate(dateString: string) {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat("en-US", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
  }).format(date)
}

// Activity Overview Component
export function ActivityOverview() {
  const [data, setData] = useState<any>({
    totalVisits: 0,
    uniqueVisitors: 0,
    registeredUsers: 0,
    guestUsers: 0,
    activityByType: [],
    activityByDevice: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      // Get data for last 30 days
      const endDate = new Date()
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - 30)

      const result = await getActivityOverview({
        start: startDate.toISOString(),
        end: endDate.toISOString(),
      })

      if (!result.error) {
        setData(result)
      }
      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return <div>Loading...</div>
  }

  const overviewCards = [
    {
      title: "Total Visits",
      value: data.totalVisits.toLocaleString(),
      icon: <Activity className="h-4 w-4 text-muted-foreground" />,
      description: "Last 30 days",
    },
    {
      title: "Unique Visitors",
      value: data.uniqueVisitors.toLocaleString(),
      icon: <Users className="h-4 w-4 text-muted-foreground" />,
      description: "Last 30 days",
    },
    {
      title: "Registered Users",
      value: data.registeredUsers.toLocaleString(),
      icon: <UserCheck className="h-4 w-4 text-muted-foreground" />,
      description: `${Math.round((data.registeredUsers / data.uniqueVisitors) * 100)}% of visitors`,
    },
    {
      title: "Device Breakdown",
      value: `${Math.round(((data.activityByDevice.find((d: any) => d.device_type === "desktop")?.count || 0) / data.totalVisits) * 100)}% Desktop`,
      icon: <Monitor className="h-4 w-4 text-muted-foreground" />,
      description: `${Math.round(((data.activityByDevice.find((d: any) => d.device_type === "mobile")?.count || 0) / data.totalVisits) * 100)}% Mobile`,
    },
  ]

  return (
    <>
      {overviewCards.map((card, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
            {card.icon}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{card.value}</div>
            <p className="text-xs text-muted-foreground">{card.description}</p>
          </CardContent>
        </Card>
      ))}
    </>
  )
}

// Conversion Funnel Component
export function ConversionFunnel() {
  const [data, setData] = useState<any>({
    productViews: 0,
    addToCartEvents: 0,
    checkoutEvents: 0,
    addToCartRate: 0,
    checkoutRate: 0,
    conversionRate: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      // Get data for last 30 days
      const endDate = new Date()
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - 30)

      const result = await getConversionFunnel({
        start: startDate.toISOString(),
        end: endDate.toISOString(),
      })

      if (!result.error) {
        setData(result)
      }
      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return <div>Loading...</div>
  }

  const funnelData = [
    {
      name: "Product Views",
      value: data.productViews,
      color: "#4f46e5",
    },
    {
      name: "Add to Cart",
      value: data.addToCartEvents,
      color: "#8b5cf6",
    },
    {
      name: "Checkout",
      value: data.checkoutEvents,
      color: "#ec4899",
    },
  ]

  return (
    <div className="space-y-8">
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={funnelData} layout="vertical" margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis type="number" />
          <YAxis dataKey="name" type="category" />
          <Tooltip />
          <Bar dataKey="value" radius={[0, 4, 4, 0]}>
            {funnelData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>

      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Add to Cart Rate</span>
            <span className="text-sm font-medium">{data.addToCartRate.toFixed(1)}%</span>
          </div>
          <Progress value={data.addToCartRate} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Checkout Rate</span>
            <span className="text-sm font-medium">{data.checkoutRate.toFixed(1)}%</span>
          </div>
          <Progress value={data.checkoutRate} className="h-2" />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Overall Conversion</span>
            <span className="text-sm font-medium">{data.conversionRate.toFixed(1)}%</span>
          </div>
          <Progress value={data.conversionRate} className="h-2" />
        </div>
      </div>
    </div>
  )
}

// Popular Products Component
export function PopularProducts() {
  const [data, setData] = useState<any>({
    mostViewed: [],
    mostAddedToCart: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      // Get data for last 30 days
      const endDate = new Date()
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - 30)

      const result = await getPopularProducts(
        {
          start: startDate.toISOString(),
          end: endDate.toISOString(),
        },
        10,
      )

      if (!result.error) {
        setData(result)
      }
      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-medium mb-4">Most Viewed Products</h3>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead className="text-right">Views</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.mostViewed.map((product: any, index: number) => (
              <TableRow key={index}>
                <TableCell>{product["metadata->product_name"]}</TableCell>
                <TableCell className="text-right">{product.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4">Most Added to Cart</h3>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead className="text-right">Add to Cart Count</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.mostAddedToCart.map((product: any, index: number) => (
              <TableRow key={index}>
                <TableCell>{product["metadata->product_name"]}</TableCell>
                <TableCell className="text-right">{product.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Popular Customizations Component
export function PopularCustomizations() {
  const [data, setData] = useState<any>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      // Get data for last 30 days
      const endDate = new Date()
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - 30)

      const result = await getPopularCustomizations({
        start: startDate.toISOString(),
        end: endDate.toISOString(),
      })

      if (!result.error) {
        setData(result.data)
      }
      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return <div>Loading...</div>
  }

  const chartData = data.map((item: any) => ({
    name: item["metadata->tshirt_model"],
    value: item.count,
  }))

  const COLORS = ["#4f46e5", "#8b5cf6", "#ec4899", "#f43f5e", "#f97316"]

  return (
    <div className="grid grid-cols-2 gap-8">
      <div>
        <h3 className="text-lg font-medium mb-4">Most Popular T-Shirt Models</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            >
              {chartData.map((entry: any, index: number) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4">T-Shirt Model Popularity</h3>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Model</TableHead>
              <TableHead className="text-right">Customizations</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((item: any, index: number) => (
              <TableRow key={index}>
                <TableCell>{item["metadata->tshirt_model"]}</TableCell>
                <TableCell className="text-right">{item.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Search Analytics Component
export function SearchAnalytics() {
  const [data, setData] = useState<any>({
    popularQueries: [],
    zeroResultQueries: [],
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      // Get data for last 30 days
      const endDate = new Date()
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - 30)

      const result = await getSearchAnalytics({
        start: startDate.toISOString(),
        end: endDate.toISOString(),
      })

      if (!result.error) {
        setData(result)
      }
      setLoading(false)
    }

    fetchData()
  }, [])

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="grid grid-cols-2 gap-8">
      <div>
        <h3 className="text-lg font-medium mb-4">Popular Search Queries</h3>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Search Term</TableHead>
              <TableHead className="text-right">Count</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.popularQueries.map((query: any, index: number) => (
              <TableRow key={index}>
                <TableCell>{query.query}</TableCell>
                <TableCell className="text-right">{query.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4">Zero Results Queries</h3>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Search Term</TableHead>
              <TableHead className="text-right">Count</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.zeroResultQueries.map((query: any, index: number) => (
              <TableRow key={index}>
                <TableCell>{query.query}</TableCell>
                <TableCell className="text-right">{query.count}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Activity Feed Component
export function ActivityFeed() {
  const [activities, setActivities] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      const result = await getRecentActivities(20)

      if (!result.error) {
        setActivities(result.data || [])
      }
      setLoading(false)
    }

    fetchData()

    // Set up polling for real-time updates
    const interval = setInterval(fetchData, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return <div>Loading...</div>
  }

  // Helper function to get activity icon
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "page_view":
        return <Eye className="h-4 w-4" />
      case "product_view":
        return <Eye className="h-4 w-4" />
      case "add_to_cart":
        return <ShoppingCart className="h-4 w-4" />
      case "checkout":
        return <ShoppingBag className="h-4 w-4" />
      case "search":
        return <Search className="h-4 w-4" />
      case "customization":
        return <Palette className="h-4 w-4" />
      default:
        return <Activity className="h-4 w-4" />
    }
  }

  // Helper function to format activity description
  const getActivityDescription = (activity: any) => {
    switch (activity.activity_type) {
      case "page_view":
        return `Viewed page: ${activity.page}`
      case "product_view":
        return `Viewed product: ${activity.metadata?.product_name || "Unknown product"}`
      case "add_to_cart":
        return `Added to cart: ${activity.metadata?.product_name || "Unknown product"}`
      case "checkout":
        return `Completed checkout: Order #${activity.metadata?.order_id}`
      case "search":
        return `Searched for: "${activity.metadata?.query}"`
      case "customization":
        return `Customized a ${activity.metadata?.tshirt_model} t-shirt`
      default:
        return `${activity.activity_type}`
    }
  }

  return (
    <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-4 p-3 rounded-md border">
          <Avatar className="h-8 w-8">
            <AvatarImage src={activity.users?.avatar || ""} />
            <AvatarFallback>{activity.users?.name ? activity.users.name.charAt(0).toUpperCase() : "?"}</AvatarFallback>
          </Avatar>

          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">{activity.users?.name || "Anonymous User"}</p>
              <span className="text-xs text-muted-foreground">{formatDate(activity.timestamp)}</span>
            </div>

            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="flex items-center space-x-1">
                {getActivityIcon(activity.activity_type)}
                <span className="text-xs capitalize">{activity.activity_type.replace("_", " ")}</span>
              </Badge>
              <p className="text-sm">{getActivityDescription(activity)}</p>
            </div>

            {activity.device_type && (
              <div className="flex items-center space-x-1">
                {activity.device_type === "mobile" ? (
                  <Smartphone className="h-3 w-3 text-muted-foreground" />
                ) : (
                  <Monitor className="h-3 w-3 text-muted-foreground" />
                )}
                <span className="text-xs text-muted-foreground capitalize">{activity.device_type}</span>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  )
}

// User Retention Chart Component
export function UserRetentionChart() {
  // Mock data for now - would be replaced with real data
  const data = [
    { name: "Mon", DAU: 400, WAU: 240 },
    { name: "Tue", DAU: 300, WAU: 250 },
    { name: "Wed", DAU: 520, WAU: 260 },
    { name: "Thu", DAU: 480, WAU: 270 },
    { name: "Fri", DAU: 380, WAU: 280 },
    { name: "Sat", DAU: 600, WAU: 290 },
    { name: "Sun", DAU: 700, WAU: 300 },
  ]

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="DAU" stroke="#4f46e5" name="Daily Active Users" />
        <Line type="monotone" dataKey="WAU" stroke="#ec4899" name="Weekly Active Users" />
      </LineChart>
    </ResponsiveContainer>
  )
}
