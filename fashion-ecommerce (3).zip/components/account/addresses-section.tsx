"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Loader2, Plus, Pencil, Trash2 } from "lucide-react"
import type { Address } from "@/lib/types"

interface AddressesSectionProps {
  addresses: Address[]
  onAddAddress: (address: Omit<Address, "id">) => Promise<boolean>
  onUpdateAddress: (id: string, address: Partial<Address>) => Promise<boolean>
  onDeleteAddress: (id: string) => Promise<boolean>
}

export default function AddressesSection({
  addresses,
  onAddAddress,
  onUpdateAddress,
  onDeleteAddress,
}: AddressesSectionProps) {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [deletingAddressId, setDeletingAddressId] = useState<string | null>(null)

  const editingAddress = editingAddressId ? addresses.find((addr) => addr.id === editingAddressId) : null

  const [formData, setFormData] = useState<Omit<Address, "id">>({
    name: "",
    street: "",
    apartment: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
    isDefault: false,
    phone: "",
  })

  const resetForm = () => {
    setFormData({
      name: "",
      street: "",
      apartment: "",
      city: "",
      state: "",
      zipCode: "",
      country: "",
      isDefault: false,
      phone: "",
    })
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, isDefault: checked }))
  }

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const success = await onAddAddress(formData)
      if (success) {
        setIsAddDialogOpen(false)
        resetForm()
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingAddressId) return

    setIsSubmitting(true)

    try {
      const success = await onUpdateAddress(editingAddressId, formData)
      if (success) {
        setEditingAddressId(null)
        resetForm()
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleEditClick = (address: Address) => {
    setFormData({
      name: address.name,
      street: address.street,
      apartment: address.apartment || "",
      city: address.city,
      state: address.state,
      zipCode: address.zipCode,
      country: address.country,
      isDefault: address.isDefault,
      phone: address.phone,
    })
    setEditingAddressId(address.id)
  }

  const handleDeleteClick = async (id: string) => {
    setDeletingAddressId(id)

    try {
      await onDeleteAddress(id)
    } finally {
      setDeletingAddressId(null)
    }
  }

  const handleCancelEdit = () => {
    setEditingAddressId(null)
    resetForm()
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Saved Addresses</CardTitle>
          <CardDescription>Manage your shipping and billing addresses</CardDescription>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" /> Add Address
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Address</DialogTitle>
              <DialogDescription>Add a new shipping or billing address to your account.</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Address Name
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Home, Work, etc."
                    value={formData.name}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="street" className="text-right">
                    Street
                  </Label>
                  <Input
                    id="street"
                    name="street"
                    placeholder="123 Main St"
                    value={formData.street}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="apartment" className="text-right">
                    Apartment
                  </Label>
                  <Input
                    id="apartment"
                    name="apartment"
                    placeholder="Apt 4B (Optional)"
                    value={formData.apartment}
                    onChange={handleChange}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="city" className="text-right">
                    City
                  </Label>
                  <Input
                    id="city"
                    name="city"
                    placeholder="New York"
                    value={formData.city}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="state" className="text-right">
                    State
                  </Label>
                  <Input
                    id="state"
                    name="state"
                    placeholder="NY"
                    value={formData.state}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="zipCode" className="text-right">
                    ZIP Code
                  </Label>
                  <Input
                    id="zipCode"
                    name="zipCode"
                    placeholder="10001"
                    value={formData.zipCode}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="country" className="text-right">
                    Country
                  </Label>
                  <Input
                    id="country"
                    name="country"
                    placeholder="United States"
                    value={formData.country}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="phone" className="text-right">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="+1 (555) 123-4567"
                    value={formData.phone}
                    onChange={handleChange}
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <div className="col-start-2 col-span-3 flex items-center space-x-2">
                    <Checkbox id="isDefault" checked={formData.isDefault} onCheckedChange={handleCheckboxChange} />
                    <Label htmlFor="isDefault">Set as default address</Label>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Add Address
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {addresses.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">You don't have any saved addresses yet.</p>
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" /> Add Your First Address
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {addresses.map((address) => (
              <div
                key={address.id}
                className={`border rounded-lg p-4 ${editingAddressId === address.id ? "border-primary" : ""}`}
              >
                {editingAddressId === address.id ? (
                  <form onSubmit={handleEditSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`edit-name-${address.id}`}>Address Name</Label>
                        <Input
                          id={`edit-name-${address.id}`}
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-phone-${address.id}`}>Phone</Label>
                        <Input
                          id={`edit-phone-${address.id}`}
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <Label htmlFor={`edit-street-${address.id}`}>Street</Label>
                        <Input
                          id={`edit-street-${address.id}`}
                          name="street"
                          value={formData.street}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <Label htmlFor={`edit-apartment-${address.id}`}>Apartment (Optional)</Label>
                        <Input
                          id={`edit-apartment-${address.id}`}
                          name="apartment"
                          value={formData.apartment}
                          onChange={handleChange}
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-city-${address.id}`}>City</Label>
                        <Input
                          id={`edit-city-${address.id}`}
                          name="city"
                          value={formData.city}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-state-${address.id}`}>State</Label>
                        <Input
                          id={`edit-state-${address.id}`}
                          name="state"
                          value={formData.state}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-zipCode-${address.id}`}>ZIP Code</Label>
                        <Input
                          id={`edit-zipCode-${address.id}`}
                          name="zipCode"
                          value={formData.zipCode}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor={`edit-country-${address.id}`}>Country</Label>
                        <Input
                          id={`edit-country-${address.id}`}
                          name="country"
                          value={formData.country}
                          onChange={handleChange}
                          required
                        />
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`edit-isDefault-${address.id}`}
                        checked={formData.isDefault}
                        onCheckedChange={handleCheckboxChange}
                        disabled={address.isDefault}
                      />
                      <Label htmlFor={`edit-isDefault-${address.id}`}>
                        {address.isDefault ? "This is your default address" : "Set as default address"}
                      </Label>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save Changes
                      </Button>
                      <Button type="button" variant="outline" onClick={handleCancelEdit}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div>
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-medium">{address.name}</h3>
                          {address.isDefault && <Badge variant="outline">Default</Badge>}
                        </div>
                        <p className="text-sm">{address.phone}</p>
                        <p className="text-sm">
                          {address.street}
                          {address.apartment && `, ${address.apartment}`}
                        </p>
                        <p className="text-sm">
                          {address.city}, {address.state} {address.zipCode}
                        </p>
                        <p className="text-sm">{address.country}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => handleEditClick(address)}>
                          <Pencil className="h-4 w-4 mr-1" /> Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteClick(address.id)}
                          disabled={deletingAddressId === address.id || address.isDefault}
                          className={address.isDefault ? "opacity-50 cursor-not-allowed" : ""}
                        >
                          {deletingAddressId === address.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4 mr-1" />
                          )}
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
