import { Suspense } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ActivityOverview,
  ConversionFunnel,
  PopularProducts,
  PopularCustomizations,
  SearchAnalytics,
  ActivityFeed,
  UserRetentionChart,
} from "@/components/admin/analytics"
import { DateRangePicker } from "@/components/admin/date-range-picker"

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Activity Analytics</h1>
          <p className="text-muted-foreground">Monitor user behavior and interactions across your store</p>
        </div>
        <DateRangePicker />
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="customization">Customization</TabsTrigger>
          <TabsTrigger value="search">Search</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Suspense fallback={<Card className="h-28 animate-pulse bg-muted" />}>
              <ActivityOverview />
            </Suspense>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Conversion Funnel</CardTitle>
                <CardDescription>Product view to purchase conversion rate</CardDescription>
              </CardHeader>
              <CardContent>
                <Suspense fallback={<div className="h-80 animate-pulse bg-muted rounded-md" />}>
                  <ConversionFunnel />
                </Suspense>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Retention</CardTitle>
                <CardDescription>Daily and weekly active users</CardDescription>
              </CardHeader>
              <CardContent>
                <Suspense fallback={<div className="h-80 animate-pulse bg-muted rounded-md" />}>
                  <UserRetentionChart />
                </Suspense>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Live Activity Feed</CardTitle>
              <CardDescription>Real-time user interactions across your store</CardDescription>
            </CardHeader>
            <CardContent>
              <Suspense fallback={<div className="h-96 animate-pulse bg-muted rounded-md" />}>
                <ActivityFeed />
              </Suspense>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="products" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Popular Products</CardTitle>
              <CardDescription>Most viewed and added to cart products</CardDescription>
            </CardHeader>
            <CardContent>
              <Suspense fallback={<div className="h-96 animate-pulse bg-muted rounded-md" />}>
                <PopularProducts />
              </Suspense>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="customization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>T-Shirt Customization Analytics</CardTitle>
              <CardDescription>Most popular models and customization patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <Suspense fallback={<div className="h-96 animate-pulse bg-muted rounded-md" />}>
                <PopularCustomizations />
              </Suspense>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Search Analytics</CardTitle>
              <CardDescription>Popular search terms and zero-result queries</CardDescription>
            </CardHeader>
            <CardContent>
              <Suspense fallback={<div className="h-96 animate-pulse bg-muted rounded-md" />}>
                <SearchAnalytics />
              </Suspense>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>User Behavior Analysis</CardTitle>
              <CardDescription>Detailed user activity and behavior patterns</CardDescription>
            </CardHeader>
            <CardContent className="h-[600px]">
              <p className="text-center text-muted-foreground py-8">
                User behavior analysis component will be implemented here
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
