import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronLeft, Truck, Package, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

interface OrderDetailPageProps {
  params: {
    id: string
  }
}

export default function OrderDetailPage({ params }: OrderDetailPageProps) {
  const { id } = params

  // Mock order data
  const order = {
    id,
    date: "April 12, 2023",
    status: "Shipped",
    statusColor: "blue",
    paymentStatus: "Paid",
    paymentStatusColor: "green",
    trackingId: "1Z999AA10123456784",
    carrier: "UPS",
    estimatedDelivery: "April 15, 2023",
    total: 67.06,
    subtotal: 58.0,
    shipping: 5.0,
    tax: 4.06,
    items: [
      {
        id: 1,
        name: "Custom Round Neck T-Shirt",
        size: "M",
        color: "White",
        price: 25.0,
        quantity: 1,
        isCustom: true,
      },
      {
        id: 2,
        name: "Custom V-Neck T-Shirt",
        size: "L",
        color: "Black",
        price: 28.0,
        quantity: 1,
        isCustom: true,
      },
    ],
    shippingAddress: {
      name: "John Doe",
      address: "123 Main Street, Apt 4B",
      city: "New York",
      state: "NY",
      zip: "10001",
      country: "United States",
      phone: "+1 (555) 123-4567",
    },
    billingAddress: {
      name: "John Doe",
      address: "123 Main Street, Apt 4B",
      city: "New York",
      state: "NY",
      zip: "10001",
      country: "United States",
      phone: "+1 (555) 123-4567",
    },
  }

  // Get status icon based on order status
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Processing":
        return <Package className="h-5 w-5" />
      case "Shipped":
        return <Truck className="h-5 w-5" />
      case "Delivered":
        return <CheckCircle className="h-5 w-5" />
      case "Cancelled":
        return <AlertCircle className="h-5 w-5" />
      default:
        return <Package className="h-5 w-5" />
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <Button variant="outline" size="sm" asChild className="mb-2">
            <Link href="/orders">
              <ChevronLeft className="mr-1 h-4 w-4" /> Back to Orders
            </Link>
          </Button>
          <h1 className="text-3xl font-bold">Order #{id}</h1>
          <p className="text-muted-foreground">Placed on {order.date}</p>
        </div>
        <div className="flex flex-col sm:items-end">
          <div className="flex items-center gap-2 mb-2">
            <Badge
              variant="outline"
              className={`bg-${order.statusColor}-50 text-${order.statusColor}-600 hover:bg-${order.statusColor}-50`}
            >
              {order.status}
            </Badge>
            <Badge
              variant="outline"
              className={`bg-${order.paymentStatusColor}-50 text-${order.paymentStatusColor}-600 hover:bg-${order.paymentStatusColor}-50`}
            >
              {order.paymentStatus}
            </Badge>
          </div>
          <Button asChild>
            <Link href={`/tracking/${id}`}>Track Order</Link>
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          {/* Order Items */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {order.items.map((item) => (
                  <div key={item.id} className="flex flex-col sm:flex-row gap-4">
                    <div className="w-full sm:w-24 h-24 bg-gray-100 rounded-md relative flex-shrink-0">
                      <Image src="/temp-tshirt.jpg" alt={item.name} fill className="object-contain p-1" />
                    </div>
                    <div className="flex-grow">
                      <div className="flex flex-col sm:flex-row sm:justify-between">
                        <div>
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            Size: {item.size} • Color: {item.color} • Qty: {item.quantity}
                          </p>
                          {item.isCustom && (
                            <Badge variant="outline" className="mt-1">
                              Custom Design
                            </Badge>
                          )}
                        </div>
                        <p className="font-medium mt-2 sm:mt-0">${item.price.toFixed(2)}</p>
                      </div>
                      {item.isCustom && (
                        <Button variant="outline" size="sm" className="mt-3">
                          <Link href={`/customize?design=${item.id}`}>Reorder Design</Link>
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Shipping Information */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Shipping Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-medium mb-2">Shipping Address</h3>
                  <p className="text-sm">{order.shippingAddress.name}</p>
                  <p className="text-sm">{order.shippingAddress.address}</p>
                  <p className="text-sm">
                    {order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.zip}
                  </p>
                  <p className="text-sm">{order.shippingAddress.country}</p>
                  <p className="text-sm">{order.shippingAddress.phone}</p>
                </div>
                <div>
                  <h3 className="font-medium mb-2">Billing Address</h3>
                  <p className="text-sm">{order.billingAddress.name}</p>
                  <p className="text-sm">{order.billingAddress.address}</p>
                  <p className="text-sm">
                    {order.billingAddress.city}, {order.billingAddress.state} {order.billingAddress.zip}
                  </p>
                  <p className="text-sm">{order.billingAddress.country}</p>
                  <p className="text-sm">{order.billingAddress.phone}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-1">
          {/* Order Summary */}
          <Card className="mb-8 sticky top-24">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${order.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>${order.shipping.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tax</span>
                  <span>${order.tax.toFixed(2)}</span>
                </div>
                <Separator className="my-2" />
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>${order.total.toFixed(2)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tracking Information */}
          <Card>
            <CardHeader>
              <CardTitle>Tracking Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Tracking Number</p>
                  <p className="font-medium">{order.trackingId}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Carrier</p>
                  <p className="font-medium">{order.carrier}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Estimated Delivery</p>
                  <p className="font-medium">{order.estimatedDelivery}</p>
                </div>
                <Button className="w-full" asChild>
                  <Link href={`/tracking/${id}`}>Track Package</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
