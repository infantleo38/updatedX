"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, Package, Truck, Download, CheckCircle, Printer } from "lucide-react"
import Image from "next/image"
import { useToast } from "@/hooks/use-toast"

// Mock orders data
const orders = [
  {
    id: "XL2023405",
    date: "April 12, 2023",
    customer: {
      name: "John Doe",
      email: "john.doe@example.com",
      address: "123 Main Street, Apt 4B, New York, NY 10001, United States",
      phone: "+1 (555) 123-4567",
    },
    items: [
      {
        id: 1,
        name: "Custom Round Neck T-Shirt",
        size: "M",
        color: "White",
        quantity: 1,
        isCustom: true,
      },
      {
        id: 2,
        name: "Custom V-Neck T-Shirt",
        size: "L",
        color: "Black",
        quantity: 1,
        isCustom: true,
      },
    ],
    status: "new",
  },
  {
    id: "XL2023404",
    date: "April 11, 2023",
    customer: {
      name: "Jane Smith",
      email: "jane.smith@example.com",
      address: "456 Park Avenue, Suite 201, Boston, MA 02108, United States",
      phone: "+1 (555) 987-6543",
    },
    items: [
      {
        id: 3,
        name: "Custom Full Sleeve T-Shirt",
        size: "XL",
        color: "Navy",
        quantity: 2,
        isCustom: true,
      },
    ],
    status: "new",
  },
  {
    id: "XL2023403",
    date: "April 10, 2023",
    customer: {
      name: "Robert Johnson",
      email: "robert.johnson@example.com",
      address: "789 Oak Street, San Francisco, CA 94103, United States",
      phone: "+1 (555) 456-7890",
    },
    items: [
      {
        id: 4,
        name: "Custom Round Neck T-Shirt",
        size: "S",
        color: "Red",
        quantity: 1,
        isCustom: true,
      },
      {
        id: 5,
        name: "Custom Crop Top T-Shirt",
        size: "M",
        color: "Green",
        quantity: 1,
        isCustom: true,
      },
      {
        id: 6,
        name: "Custom V-Neck T-Shirt",
        size: "M",
        color: "Black",
        quantity: 1,
        isCustom: true,
      },
    ],
    status: "new",
  },
]

export default function PackingPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("new")
  const [packedOrders, setPackedOrders] = useState<string[]>([])
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({})

  const handleMarkAsPacked = (orderId: string) => {
    setPackedOrders([...packedOrders, orderId])

    toast({
      title: "Order marked as packed",
      description: `Order #${orderId} has been moved to the shipping queue.`,
    })
  }

  const handleDownloadPackingSlip = (orderId: string) => {
    // In a real app, this would generate and download a PDF
    toast({
      title: "Packing slip downloaded",
      description: `Packing slip for order #${orderId} has been downloaded.`,
    })
  }

  const handleToggleItem = (itemId: string) => {
    setCheckedItems({
      ...checkedItems,
      [itemId]: !checkedItems[itemId],
    })
  }

  const filteredOrders = orders.filter((order) => {
    if (activeTab === "new") return !packedOrders.includes(order.id)
    if (activeTab === "packed") return packedOrders.includes(order.id)
    return true
  })

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Order Packing</h1>
          <p className="text-muted-foreground">Manage and process orders for shipping</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Printer className="mr-2 h-4 w-4" /> Print All Slips
          </Button>
          <Button>
            <Truck className="mr-2 h-4 w-4" /> Move to Shipping
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6">
        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input placeholder="Search orders by ID or customer name" className="pl-10" />
          </div>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
            <TabsList>
              <TabsTrigger value="new" className="flex items-center gap-2">
                <Package className="h-4 w-4" /> New Orders
                <Badge variant="secondary" className="ml-1">
                  {orders.filter((o) => !packedOrders.includes(o.id)).length}
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="packed" className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" /> Packed
                <Badge variant="secondary" className="ml-1">
                  {packedOrders.length}
                </Badge>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Orders List */}
        <div className="space-y-6">
          {filteredOrders.length === 0 ? (
            <div className="text-center py-12">
              <Package className="mx-auto h-12 w-12 text-muted-foreground opacity-50" />
              <h2 className="mt-4 text-lg font-medium">No orders to display</h2>
              <p className="text-muted-foreground">
                {activeTab === "new"
                  ? "There are no new orders to pack at this time."
                  : "There are no packed orders waiting for shipping."}
              </p>
            </div>
          ) : (
            filteredOrders.map((order) => (
              <Card key={order.id}>
                <CardHeader className="bg-muted/30">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <CardTitle className="text-lg">
                      Order #{order.id}
                      <span className="ml-2 text-sm font-normal text-muted-foreground">Placed on {order.date}</span>
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => handleDownloadPackingSlip(order.id)}>
                        <Download className="mr-2 h-4 w-4" /> Packing Slip
                      </Button>
                      {activeTab === "new" && (
                        <Button size="sm" onClick={() => handleMarkAsPacked(order.id)}>
                          <CheckCircle className="mr-2 h-4 w-4" /> Mark as Packed
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    {/* Customer Information */}
                    <div>
                      <h3 className="font-medium mb-2">Customer Information</h3>
                      <p className="text-sm">{order.customer.name}</p>
                      <p className="text-sm">{order.customer.email}</p>
                      <p className="text-sm">{order.customer.phone}</p>
                      <Separator className="my-3" />
                      <h3 className="font-medium mb-2">Shipping Address</h3>
                      <p className="text-sm">{order.customer.address}</p>
                    </div>

                    {/* Order Items */}
                    <div>
                      <h3 className="font-medium mb-2">Items to Pack</h3>
                      <div className="space-y-4">
                        {order.items.map((item) => (
                          <div key={item.id} className="flex items-start gap-3">
                            <Checkbox
                              id={`item-${item.id}`}
                              checked={checkedItems[`item-${item.id}`] || false}
                              onCheckedChange={() => handleToggleItem(`item-${item.id}`)}
                            />
                            <div className="w-16 h-16 bg-gray-100 rounded-md relative flex-shrink-0">
                              <Image src="/temp-tshirt.jpg" alt={item.name} fill className="object-contain p-1" />
                            </div>
                            <div className="flex-grow">
                              <Label htmlFor={`item-${item.id}`} className="font-medium cursor-pointer">
                                {item.name}
                              </Label>
                              <p className="text-sm text-muted-foreground">
                                Size: {item.size} • Color: {item.color} • Qty: {item.quantity}
                              </p>
                              {item.isCustom && (
                                <Badge variant="outline" className="mt-1">
                                  Custom Design
                                </Badge>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
