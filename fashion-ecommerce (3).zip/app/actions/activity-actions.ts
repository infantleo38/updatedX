"use server"

import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"
import { v4 as uuidv4 } from "uuid"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY
const supabase = createClient(supabaseUrl || "", supabaseKey || "", {
  auth: {
    persistSession: false,
  },
})

// Helper function to check if error is about missing table
function isTableNotExistError(error: any): boolean {
  if (!error) return false

  // Log the error for debugging
  console.log("Checking error type:", error)

  // Check if error has a message property that includes "does not exist"
  if (typeof error === "object" && error.message && typeof error.message === "string") {
    return error.message.includes("does not exist")
  }

  // Check if error has a code property that indicates a missing table
  if (typeof error === "object" && error.code) {
    return error.code === "42P01" // PostgreSQL code for undefined_table
  }

  // Convert error to string and check
  const errorStr = String(error)
  return errorStr.includes("does not exist") || errorStr.includes("42P01")
}

// Get or create a session ID
export async function getSessionId() {
  try {
    const cookieStore = cookies()
    let sessionId = cookieStore.get("session_id")?.value

    if (!sessionId) {
      sessionId = uuidv4()
      try {
        cookieStore.set("session_id", sessionId, {
          maxAge: 60 * 60 * 24 * 30, // 30 days
          path: "/",
        })
      } catch (error) {
        console.error("Error setting session cookie:", error)
        // Continue with the generated sessionId even if we couldn't set the cookie
      }
    }

    return sessionId
  } catch (error) {
    console.error("Error in getSessionId:", error)
    // Return a fallback session ID if there's an error
    return `fallback-${uuidv4()}`
  }
}

// Create tables using raw SQL directly
async function createTablesWithRawSQL() {
  try {
    // Create UUID extension if it doesn't exist
    const createExtensionQuery = `
      CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
    `

    // Try to execute the extension query directly
    const { error: extensionError } = await supabase.rpc("exec_sql", {
      sql_query: createExtensionQuery,
    })

    if (extensionError) {
      console.error("Error creating UUID extension:", extensionError)
      // If RPC fails, try direct SQL query
      await supabase.from("_exec_sql").insert({ query: createExtensionQuery })
    }

    // Create user_activities table
    const createActivitiesTableQuery = `
      CREATE TABLE IF NOT EXISTS public.user_activities (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID,
        session_id TEXT NOT NULL,
        activity_type TEXT NOT NULL,
        page TEXT,
        duration INTEGER,
        ip_address TEXT,
        user_agent TEXT,
        device_type TEXT,
        referrer TEXT,
        metadata JSONB DEFAULT '{}'::jsonb,
        timestamp TIMESTAMPTZ DEFAULT NOW()
      );
      
      CREATE INDEX IF NOT EXISTS idx_user_activities_user_id ON public.user_activities(user_id);
      CREATE INDEX IF NOT EXISTS idx_user_activities_session_id ON public.user_activities(session_id);
      CREATE INDEX IF NOT EXISTS idx_user_activities_activity_type ON public.user_activities(activity_type);
      CREATE INDEX IF NOT EXISTS idx_user_activities_timestamp ON public.user_activities(timestamp);
    `

    // Try to execute the activities table query
    const { error: activitiesError } = await supabase.rpc("exec_sql", {
      sql_query: createActivitiesTableQuery,
    })

    if (activitiesError) {
      console.error("Error creating user_activities table:", activitiesError)
      // If RPC fails, try direct SQL query
      await supabase.from("_exec_sql").insert({ query: createActivitiesTableQuery })
    }

    // Create search_queries table
    const createSearchTableQuery = `
      CREATE TABLE IF NOT EXISTS public.search_queries (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID,
        session_id TEXT NOT NULL,
        query TEXT NOT NULL,
        results_count INTEGER DEFAULT 0,
        timestamp TIMESTAMPTZ DEFAULT NOW()
      );
      
      CREATE INDEX IF NOT EXISTS idx_search_queries_query ON public.search_queries(query);
      CREATE INDEX IF NOT EXISTS idx_search_queries_timestamp ON public.search_queries(timestamp);
    `

    // Try to execute the search table query
    const { error: searchError } = await supabase.rpc("exec_sql", {
      sql_query: createSearchTableQuery,
    })

    if (searchError) {
      console.error("Error creating search_queries table:", searchError)
      // If RPC fails, try direct SQL query
      await supabase.from("_exec_sql").insert({ query: createSearchTableQuery })
    }

    console.log("Tables created successfully")
    return true
  } catch (error) {
    console.error("Error creating tables with raw SQL:", error)
    return false
  }
}

// Fallback method to create tables using direct SQL
async function createTablesDirectly() {
  try {
    // Create a temporary table to execute SQL
    const { error: tempTableError } = await supabase.from("_temp_exec").insert({
      sql: `
        -- Create UUID extension
        CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
        
        -- Create user_activities table
        CREATE TABLE IF NOT EXISTS public.user_activities (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id UUID,
          session_id TEXT NOT NULL,
          activity_type TEXT NOT NULL,
          page TEXT,
          duration INTEGER,
          ip_address TEXT,
          user_agent TEXT,
          device_type TEXT,
          referrer TEXT,
          metadata JSONB DEFAULT '{}'::jsonb,
          timestamp TIMESTAMPTZ DEFAULT NOW()
        );
        
        -- Create search_queries table
        CREATE TABLE IF NOT EXISTS public.search_queries (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          user_id UUID,
          session_id TEXT NOT NULL,
          query TEXT NOT NULL,
          results_count INTEGER DEFAULT 0,
          timestamp TIMESTAMPTZ DEFAULT NOW()
        );
      `,
    })

    if (tempTableError) {
      console.error("Error with direct SQL execution:", tempTableError)
      return false
    }

    return true
  } catch (error) {
    console.error("Error in createTablesDirectly:", error)
    return false
  }
}

// Record user activity
export async function recordActivity(activityData: {
  userId?: string
  activityType: string
  page?: string
  duration?: number
  metadata?: any
  userAgent?: string
  ipAddress?: string
  referrer?: string
}) {
  try {
    const sessionId = await getSessionId()

    // Determine device type from user agent
    const deviceType = activityData.userAgent?.toLowerCase().includes("mobile") ? "mobile" : "desktop"

    // Log the data being inserted for debugging
    console.log("Recording activity with data:", {
      user_id: activityData.userId || null,
      session_id: sessionId,
      activity_type: activityData.activityType,
      page: activityData.page || null,
      device_type: deviceType,
    })

    // Try to insert directly first
    try {
      // First, check if the table exists
      const { count, error: checkError } = await supabase
        .from("user_activities")
        .select("*", { count: "exact", head: true })
        .limit(1)

      // If there's an error checking the table, it probably doesn't exist
      if (checkError) {
        console.log("Error checking table existence:", checkError)
        console.log("Table doesn't exist, creating it...")

        // Try to create tables
        const tablesCreated = await createTablesWithRawSQL()

        if (!tablesCreated) {
          // Try fallback method
          await createTablesDirectly()
        }
      }

      // Now try to insert the activity
      const { error } = await supabase.from("user_activities").insert({
        user_id: activityData.userId || null,
        session_id: sessionId,
        activity_type: activityData.activityType,
        page: activityData.page || null,
        duration: activityData.duration || null,
        ip_address: activityData.ipAddress || null,
        user_agent: activityData.userAgent || null,
        device_type: deviceType,
        referrer: activityData.referrer || null,
        metadata: activityData.metadata || {},
      })

      // Log any error for debugging
      if (error) {
        console.error("Error recording activity:", error)
        return { success: false, error: error.message || "Unknown error" }
      }

      return { success: true }
    } catch (error: any) {
      console.error("Error in recordActivity insert:", error)

      // Try one more time with a simplified approach
      try {
        // Create a minimal record
        const { error: retryError } = await supabase.from("user_activities").insert({
          session_id: sessionId,
          activity_type: activityData.activityType,
        })

        if (retryError) {
          console.error("Final retry error:", retryError)
          return { success: false, error: retryError.message || "Failed to record activity" }
        }

        return { success: true }
      } catch (finalError) {
        console.error("Final error in recordActivity:", finalError)
        return { success: false, error: "Failed to record activity after multiple attempts" }
      }
    }
  } catch (error: any) {
    console.error("Error in recordActivity:", error)
    return { success: false, error: error.message || "Failed to record activity" }
  }
}

// Record page view
export async function recordPageView(pageData: {
  userId?: string
  page: string
  referrer?: string
  userAgent?: string
  ipAddress?: string
}) {
  return recordActivity({
    userId: pageData.userId,
    activityType: "page_view",
    page: pageData.page,
    referrer: pageData.referrer,
    userAgent: pageData.userAgent,
    ipAddress: pageData.ipAddress,
  })
}

// Record product view
export async function recordProductView(productData: {
  userId?: string
  productId: string
  productName: string
  userAgent?: string
  ipAddress?: string
}) {
  return recordActivity({
    userId: productData.userId,
    activityType: "product_view",
    page: `/products/${productData.productId}`,
    metadata: {
      product_id: productData.productId,
      product_name: productData.productName,
    },
    userAgent: productData.userAgent,
    ipAddress: productData.ipAddress,
  })
}

// Record add to cart
export async function recordAddToCart(cartData: {
  userId?: string
  productId: string
  productName: string
  quantity: number
  price: number
  userAgent?: string
  ipAddress?: string
}) {
  return recordActivity({
    userId: cartData.userId,
    activityType: "add_to_cart",
    metadata: {
      product_id: cartData.productId,
      product_name: cartData.productName,
      quantity: cartData.quantity,
      price: cartData.price,
    },
    userAgent: cartData.userAgent,
    ipAddress: cartData.ipAddress,
  })
}

// Record search query
export async function recordSearchQuery(searchData: {
  userId?: string
  query: string
  resultsCount: number
  userAgent?: string
  ipAddress?: string
}) {
  try {
    const sessionId = await getSessionId()

    // Try to record in search_queries table
    try {
      const { error: searchError } = await supabase.from("search_queries").insert({
        user_id: searchData.userId || null,
        session_id: sessionId,
        query: searchData.query,
        results_count: searchData.resultsCount,
      })

      // If table doesn't exist, create it
      if (searchError && isTableNotExistError(searchError)) {
        await createTablesWithRawSQL()

        // Try again
        await supabase.from("search_queries").insert({
          user_id: searchData.userId || null,
          session_id: sessionId,
          query: searchData.query,
          results_count: searchData.resultsCount,
        })
      }
    } catch (error) {
      console.error("Error recording search query:", error)
      // Continue to record in general activity log
    }

    // Also record in general activity log
    return recordActivity({
      userId: searchData.userId,
      activityType: "search",
      metadata: {
        query: searchData.query,
        results_count: searchData.resultsCount,
      },
      userAgent: searchData.userAgent,
      ipAddress: searchData.ipAddress,
    })
  } catch (error: any) {
    console.error("Error in recordSearchQuery:", error)
    return { success: false, error: error.message || "Failed to record search query" }
  }
}

// Record checkout
export async function recordCheckout(checkoutData: {
  userId?: string
  orderId: string
  totalAmount: number
  itemCount: number
  userAgent?: string
  ipAddress?: string
}) {
  return recordActivity({
    userId: checkoutData.userId,
    activityType: "checkout",
    metadata: {
      order_id: checkoutData.orderId,
      total_amount: checkoutData.totalAmount,
      item_count: checkoutData.itemCount,
    },
    userAgent: checkoutData.userAgent,
    ipAddress: checkoutData.ipAddress,
  })
}

// Record t-shirt customization
export async function recordCustomization(customizationData: {
  userId?: string
  designId?: string
  tshirtModel: string
  duration: number
  saved: boolean
  userAgent?: string
  ipAddress?: string
}) {
  return recordActivity({
    userId: customizationData.userId,
    activityType: "customization",
    page: "/customize",
    duration: customizationData.duration,
    metadata: {
      design_id: customizationData.designId,
      tshirt_model: customizationData.tshirtModel,
      saved: customizationData.saved,
    },
    userAgent: customizationData.userAgent,
    ipAddress: customizationData.ipAddress,
  })
}

// Admin Dashboard Analytics Functions

// Get activity overview for dashboard
export async function getActivityOverview(dateRange: { start: string; end: string }) {
  try {
    // Get total visits
    const { count: totalVisits, error: visitsError } = await supabase
      .from("user_activities")
      .select("*", { count: "exact", head: true })
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)

    if (visitsError) {
      console.error("Error fetching total visits:", visitsError)
      return { error: visitsError.message }
    }

    // Get unique visitors
    const { data: uniqueVisitors, error: uniqueError } = await supabase
      .from("user_activities")
      .select("session_id")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .distinct()

    if (uniqueError) {
      console.error("Error fetching unique visitors:", uniqueError)
      return { error: uniqueError.message }
    }

    // Get registered users
    const { data: registeredUsers, error: registeredError } = await supabase
      .from("user_activities")
      .select("user_id")
      .not("user_id", "is", null)
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .distinct()

    if (registeredError) {
      console.error("Error fetching registered users:", registeredError)
      return { error: registeredError.message }
    }

    // Get activity by type
    const { data: activityByType, error: activityTypeError } = await supabase
      .from("user_activities")
      .select("activity_type, count")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("activity_type")

    if (activityTypeError) {
      console.error("Error fetching activity by type:", activityTypeError)
      return { error: activityTypeError.message }
    }

    // Get activity by device
    const { data: activityByDevice, error: deviceError } = await supabase
      .from("user_activities")
      .select("device_type, count")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("device_type")

    if (deviceError) {
      console.error("Error fetching activity by device:", deviceError)
      return { error: deviceError.message }
    }

    return {
      totalVisits: totalVisits || 0,
      uniqueVisitors: uniqueVisitors?.length || 0,
      registeredUsers: registeredUsers?.length || 0,
      guestUsers: (uniqueVisitors?.length || 0) - (registeredUsers?.length || 0),
      activityByType: activityByType || [],
      activityByDevice: activityByDevice || [],
      error: null,
    }
  } catch (error: any) {
    console.error("Error in getActivityOverview:", error)
    return { error: error.message || "Failed to fetch activity overview" }
  }
}

// Get popular products
export async function getPopularProducts(dateRange: { start: string; end: string }, limit = 10) {
  try {
    // Get most viewed products
    const { data: viewedProducts, error: viewError } = await supabase
      .from("user_activities")
      .select(`
        metadata->product_id,
        metadata->product_name,
        count
      `)
      .eq("activity_type", "product_view")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("metadata->product_id, metadata->product_name")
      .order("count", { ascending: false })
      .limit(limit)

    if (viewError) {
      console.error("Error fetching viewed products:", viewError)
      return { error: viewError.message }
    }

    // Get most added to cart products
    const { data: cartProducts, error: cartError } = await supabase
      .from("user_activities")
      .select(`
        metadata->product_id,
        metadata->product_name,
        count
      `)
      .eq("activity_type", "add_to_cart")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("metadata->product_id, metadata->product_name")
      .order("count", { ascending: false })
      .limit(limit)

    if (cartError) {
      console.error("Error fetching cart products:", cartError)
      return { error: cartError.message }
    }

    return {
      mostViewed: viewedProducts || [],
      mostAddedToCart: cartProducts || [],
      error: null,
    }
  } catch (error: any) {
    console.error("Error in getPopularProducts:", error)
    return { error: error.message || "Failed to fetch popular products" }
  }
}

// Get most popular t-shirt customizations
export async function getPopularCustomizations(dateRange: { start: string; end: string }, limit = 5) {
  try {
    const { data, error } = await supabase
      .from("user_activities")
      .select(`
        metadata->tshirt_model,
        count
      `)
      .eq("activity_type", "customization")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("metadata->tshirt_model")
      .order("count", { ascending: false })
      .limit(limit)

    if (error) {
      console.error("Error fetching popular customizations:", error)
      return { data: [], error: error.message }
    }

    return { data, error: null }
  } catch (error: any) {
    console.error("Error in getPopularCustomizations:", error)
    return { data: [], error: error.message || "Failed to fetch popular customizations" }
  }
}

// Get recent user activities for live feed
export async function getRecentActivities(limit = 20) {
  try {
    const { data, error } = await supabase
      .from("user_activities")
      .select(`
        id,
        user_id,
        activity_type,
        page,
        timestamp,
        metadata,
        users (
          name,
          email
        )
      `)
      .order("timestamp", { ascending: false })
      .limit(limit)

    if (error) {
      console.error("Error fetching recent activities:", error)
      return { data: [], error: error.message }
    }

    return { data, error: null }
  } catch (error: any) {
    console.error("Error in getRecentActivities:", error)
    return { data: [], error: error.message || "Failed to fetch recent activities" }
  }
}

// Get conversion funnel data
export async function getConversionFunnel(dateRange: { start: string; end: string }) {
  try {
    // Get product views
    const { count: productViews, error: viewsError } = await supabase
      .from("user_activities")
      .select("*", { count: "exact", head: true })
      .eq("activity_type", "product_view")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)

    if (viewsError) {
      console.error("Error fetching product views:", viewsError)
      return { error: viewsError.message }
    }

    // Get add to cart events
    const { count: addToCartEvents, error: cartError } = await supabase
      .from("user_activities")
      .select("*", { count: "exact", head: true })
      .eq("activity_type", "add_to_cart")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)

    if (cartError) {
      console.error("Error fetching add to cart events:", cartError)
      return { error: cartError.message }
    }

    // Get checkout events
    const { count: checkoutEvents, error: checkoutError } = await supabase
      .from("user_activities")
      .select("*", { count: "exact", head: true })
      .eq("activity_type", "checkout")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)

    if (checkoutError) {
      console.error("Error fetching checkout events:", checkoutError)
      return { error: checkoutError.message }
    }

    return {
      productViews: productViews || 0,
      addToCartEvents: addToCartEvents || 0,
      checkoutEvents: checkoutEvents || 0,
      addToCartRate: productViews ? ((addToCartEvents || 0) / productViews) * 100 : 0,
      checkoutRate: addToCartEvents ? ((checkoutEvents || 0) / addToCartEvents) * 100 : 0,
      conversionRate: productViews ? ((checkoutEvents || 0) / productViews) * 100 : 0,
      error: null,
    }
  } catch (error: any) {
    console.error("Error in getConversionFunnel:", error)
    return { error: error.message || "Failed to fetch conversion funnel data" }
  }
}

// Get search analytics
export async function getSearchAnalytics(dateRange: { start: string; end: string }, limit = 10) {
  try {
    // Get most popular search queries
    const { data: popularQueries, error: queriesError } = await supabase
      .from("search_queries")
      .select("query, count")
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("query")
      .order("count", { ascending: false })
      .limit(limit)

    if (queriesError) {
      console.error("Error fetching popular search queries:", queriesError)
      return { error: queriesError.message }
    }

    // Get zero results queries
    const { data: zeroResultQueries, error: zeroError } = await supabase
      .from("search_queries")
      .select("query, count")
      .eq("results_count", 0)
      .gte("timestamp", dateRange.start)
      .lte("timestamp", dateRange.end)
      .group("query")
      .order("count", { ascending: false })
      .limit(limit)

    if (zeroError) {
      console.error("Error fetching zero result queries:", zeroError)
      return { error: zeroError.message }
    }

    return {
      popularQueries: popularQueries || [],
      zeroResultQueries: zeroResultQueries || [],
      error: null,
    }
  } catch (error: any) {
    console.error("Error in getSearchAnalytics:", error)
    return { error: error.message || "Failed to fetch search analytics" }
  }
}

// Get user activity timeline for a specific user
export async function getUserActivityTimeline(userId: string, limit = 50) {
  try {
    const { data, error } = await supabase
      .from("user_activities")
      .select("*")
      .eq("user_id", userId)
      .order("timestamp", { ascending: false })
      .limit(limit)

    if (error) {
      console.error("Error fetching user activity timeline:", error)
      return { data: [], error: error.message }
    }

    return { data, error: null }
  } catch (error: any) {
    console.error("Error in getUserActivityTimeline:", error)
    return { data: [], error: error.message || "Failed to fetch user activity timeline" }
  }
}
