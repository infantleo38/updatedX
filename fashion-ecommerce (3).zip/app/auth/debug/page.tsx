"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"

export default function DebugPage() {
  const [action, setAction] = useState("")
  const [result, setResult] = useState<any>(null)
  const { toast } = useToast()

  const testSimpleAction = async () => {
    try {
      setAction("Testing simple action")

      // Simple test to ensure actions are working
      const response = await fetch("/api/debug", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ test: true }),
      })

      const data = await response.json()
      setResult(data)

      toast({
        title: "Success",
        description: "Action completed successfully",
      })
    } catch (error: any) {
      console.error("Debug error:", error)
      setResult({ error: error.message })
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Debug Tools</CardTitle>
          <CardDescription>Test functionality and diagnose issues</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Current Action</Label>
            <div className="p-2 bg-muted rounded-md">{action || "No action running"}</div>
          </div>

          <div className="space-y-2">
            <Label>Test Button</Label>
            <Button onClick={testSimpleAction} className="w-full">
              Test Simple Action
            </Button>
          </div>

          {result && (
            <div className="space-y-2">
              <Label>Result</Label>
              <pre className="p-2 bg-muted rounded-md overflow-auto text-xs">{JSON.stringify(result, null, 2)}</pre>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button variant="outline" className="w-full" onClick={() => setResult(null)}>
            Clear Results
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
