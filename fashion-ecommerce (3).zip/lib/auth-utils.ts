"use server"

import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"

// Initialize Supabase client with cookies for server components
export function createServerSupabaseClient() {
  const cookieStore = cookies()

  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_ANON_KEY!, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value
      },
      set(name: string, value: string, options: any) {
        cookieStore.set({ name, value, ...options })
      },
      remove(name: string, options: any) {
        cookieStore.set({ name, value: "", ...options })
      },
    },
  })
}

// Get the current session
export async function getSession() {
  const supabase = createServerSupabaseClient()

  try {
    const {
      data: { session },
    } = await supabase.auth.getSession()
    return session
  } catch (error) {
    console.error("Error getting session:", error)
    return null
  }
}

// Get the current user with role information
export async function getCurrentUser() {
  const supabase = createServerSupabaseClient()

  try {
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session?.user) {
      return null
    }

    // Get user data including role from the users table
    const { data: userData, error } = await supabase.from("users").select("*").eq("id", session.user.id).single()

    if (error || !userData) {
      console.error("Error fetching user data:", error)
      return null
    }

    return {
      ...session.user,
      role: userData.role,
      name: userData.name,
      phone: userData.phone || "",
      avatar: userData.avatar_url || "",
    }
  } catch (error) {
    console.error("Error in getCurrentUser:", error)
    return null
  }
}

// Check if the current user has admin role
export async function isAdmin() {
  const user = await getCurrentUser()
  return user?.role === "admin"
}

// Protect a route to only allow authenticated users
export async function requireAuth() {
  const session = await getSession()

  if (!session) {
    redirect("/auth/login")
  }

  return session
}

// Protect a route to only allow admin users
export async function requireAdmin() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/auth/login")
  }

  if (user.role !== "admin") {
    redirect("/unauthorized")
  }

  return user
}

// Create a new user and set their role
export async function createUser(email: string, password: string, name: string, role = "user") {
  const supabase = createServerSupabaseClient()

  try {
    // Create the auth user
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    })

    if (authError || !authData.user) {
      console.error("Error creating auth user:", authError)
      return { success: false, error: authError?.message || "Failed to create user" }
    }

    // Add user data to the users table with role
    const { error: userError } = await supabase.from("users").insert({
      id: authData.user.id,
      email,
      name,
      role,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })

    if (userError) {
      console.error("Error creating user record:", userError)
      return { success: false, error: userError.message }
    }

    return { success: true, userId: authData.user.id }
  } catch (error: any) {
    console.error("Error in createUser:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Sign in a user
export async function signIn(email: string, password: string) {
  const supabase = createServerSupabaseClient()

  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    // Get user role
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("role")
      .eq("id", data.user.id)
      .single()

    if (userError) {
      console.error("Error fetching user role:", userError)
      return { success: true, user: data.user, role: "user" } // Default to user role if error
    }

    return { success: true, user: data.user, role: userData.role }
  } catch (error: any) {
    console.error("Error in signIn:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}

// Sign out a user
export async function signOut() {
  const supabase = createServerSupabaseClient()

  try {
    await supabase.auth.signOut()
    return { success: true }
  } catch (error: any) {
    console.error("Error in signOut:", error)
    return { success: false, error: error.message || "An unexpected error occurred" }
  }
}
