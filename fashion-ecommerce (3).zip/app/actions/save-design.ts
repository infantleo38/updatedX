"use server"

import { createClient } from "@supabase/supabase-js"
import { revalidatePath } from "next/cache"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

interface SaveDesignParams {
  userId: string
  model: string
  side: "front" | "back"
  imageData: string
  position: { x: number; y: number }
  scale: number
  rotation: number
  tshirtColor: string
  tshirtSize: string
}

export async function saveDesign({
  userId,
  model,
  side,
  imageData,
  position,
  scale,
  rotation,
  tshirtColor,
  tshirtSize,
}: SaveDesignParams) {
  try {
    const { data, error } = await supabase
      .from("tshirt_designs")
      .insert([
        {
          user_id: userId,
          model,
          side,
          image_data: imageData,
          position_x: position.x,
          position_y: position.y,
          scale,
          rotation,
          tshirt_color: tshirtColor,
          tshirt_size: tshirtSize,
        },
      ])
      .select()

    if (error) throw error

    // Revalidate relevant paths
    revalidatePath("/customize")
    revalidatePath("/cart")

    return { success: true, designId: data[0].id }
  } catch (error) {
    console.error("Error saving design:", error)
    return { success: false, error: "Failed to save design" }
  }
}

export async function getUserDesigns(userId: string) {
  try {
    const { data, error } = await supabase
      .from("tshirt_designs")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    if (error) throw error

    return data
  } catch (error) {
    console.error("Error fetching designs:", error)
    return []
  }
}
