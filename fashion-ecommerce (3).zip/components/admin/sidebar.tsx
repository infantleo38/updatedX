import { LayoutDashboard, Settings, User, ShoppingCart, Activity } from "lucide-react"

import { MainNav } from "@/components/main-nav"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar"
import { UserAccountNav } from "@/components/user-account-nav"
import { Link } from "@nextui-org/react"

export function DashboardSidebar() {
  return (
    <Sidebar>
      <SidebarHeader>
        <MainNav className="flex flex-col gap-4" />
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin">
                <LayoutDashboard className="mr-2 h-4 w-4" />
                <span>Dashboard</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          {/* ADDED MENU ITEM */}
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/analytics">
                <Activity className="mr-2 h-4 w-4" />
                <span>User Analytics</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/users">
                <User className="mr-2 h-4 w-4" />
                <span>Users</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/products">
                <ShoppingCart className="mr-2 h-4 w-4" />
                <span>Products</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/settings">
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter>
        <UserAccountNav name="John Doe" email="john.doe@example.com" imageUrl="/examples/image-1.jpg" />
      </SidebarFooter>
    </Sidebar>
  )
}
