"use client"
import Link from "next/link"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ProductCardButtons } from "@/components/product-card-buttons"
import { useActivityTracking } from "@/hooks/use-activity-tracking"

type ProductCardProps = {
  product: {
    id: string
    name: string
    price: number
    image: string
    category?: string
  }
}

export function ProductCard({ product }: ProductCardProps) {
  const { trackProductView } = useActivityTracking()

  const handleProductClick = () => {
    trackProductView(product.id, product.name)
  }

  return (
    <Card className="overflow-hidden">
      <Link href={`/products/${product.id}`} onClick={handleProductClick}>
        <div className="aspect-square overflow-hidden">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-full object-cover transition-transform hover:scale-105 duration-300"
          />
        </div>
      </Link>
      <CardContent className="p-4">
        <Link href={`/products/${product.id}`} className="hover:underline">
          <h3 className="font-medium text-lg">{product.name}</h3>
        </Link>
        {product.category && <p className="text-sm text-muted-foreground">{product.category}</p>}
        <p className="font-semibold mt-1">${product.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <ProductCardButtons product={product} />
      </CardFooter>
    </Card>
  )
}

export default ProductCard
