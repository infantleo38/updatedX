"use server"

import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

// In a real app with authentication, this would get the user ID from the session
// For now, we'll fetch the first user from the database
export async function getCurrentUserId(): Promise<string | null> {
  try {
    const { data, error } = await supabase.from("users").select("id").limit(1).single()

    if (error || !data) {
      console.error("Error fetching current user ID:", error)
      return null
    }

    return data.id
  } catch (error) {
    console.error("Error in getCurrentUserId:", error)
    return null
  }
}
