"use client"

import { forwardRef, useRef } from "react"
import Image from "next/image"
import { useDraggable } from "@/hooks/use-draggable"

interface DesignCanvasProps {
  tshirtColor: string
  designImage: string | null
  designPosition: { x: number; y: number }
  designScale: number
  designRotation: number
  onPositionChange: (position: { x: number; y: number }) => void
  view: "front" | "back"
}

const DesignCanvas = forwardRef<HTMLDivElement, DesignCanvasProps>(
  ({ tshirtColor, designImage, designPosition, designScale, designRotation, onPositionChange, view }, ref) => {
    const designRef = useRef<HTMLDivElement>(null)
    const canvasRef = useRef<HTMLDivElement>(null)

    // Set up draggable functionality
    useDraggable(designRef, {
      onDrag: (deltaX, deltaY) => {
        onPositionChange({
          x: designPosition.x + deltaX,
          y: designPosition.y + deltaY,
        })
      },
      bounds: canvasRef,
    })

    return (
      <div ref={canvasRef} className="relative w-full h-full">
        {/* T-shirt image */}
        <div className="relative w-full h-full">
          <Image
            src={`/plain-blue-tee.png?height=600&width=400&query=t-shirt ${view} template`}
            alt={`T-shirt ${view} view`}
            fill
            className="object-contain"
            style={{ filter: tshirtColor !== "#FFFFFF" ? "brightness(0) saturate(100%)" : undefined }}
          />

          {/* Colored overlay for t-shirt */}
          {tshirtColor !== "#FFFFFF" && (
            <div
              className="absolute inset-0"
              style={{
                backgroundColor: tshirtColor,
                mixBlendMode: "multiply",
                opacity: 0.9,
              }}
            />
          )}

          {/* Design placement area */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div
              className="absolute w-[40%] h-[40%] flex items-center justify-center"
              style={{
                border: designImage ? "none" : "2px dashed #ccc",
                borderRadius: "4px",
              }}
            >
              {/* Design image */}
              {designImage && (
                <div
                  ref={designRef}
                  className="absolute cursor-move"
                  style={{
                    transform: `translate(${designPosition.x}px, ${designPosition.y}px) rotate(${designRotation}deg) scale(${designScale})`,
                    maxWidth: "100%",
                    maxHeight: "100%",
                    touchAction: "none",
                  }}
                >
                  <Image
                    src={designImage || "/placeholder.svg"}
                    alt="Custom design"
                    width={200}
                    height={200}
                    className="pointer-events-none max-w-full max-h-full object-contain"
                    style={{
                      filter: tshirtColor === "#000000" ? "invert(1)" : undefined,
                    }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    )
  },
)

DesignCanvas.displayName = "DesignCanvas"

export default DesignCanvas
