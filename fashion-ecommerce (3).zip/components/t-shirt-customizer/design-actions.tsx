"use client"

import { Button } from "@/components/ui/button"
import { RefreshCw, Download, ShoppingCart, Loader2 } from "lucide-react"
import { useCart } from "@/contexts/cart-context"
import { useState } from "react"
import { useRouter } from "next/navigation"
import type { DesignState } from "./t-shirt-customizer"

interface DesignActionsProps {
  onResetDesign: () => void
  onDownloadPreview: () => void
  hasDesign: boolean
  isLoading?: boolean
  designState: DesignState
}

export function DesignActions({
  onResetDesign,
  onDownloadPreview,
  hasDesign,
  isLoading = false,
  designState,
}: DesignActionsProps) {
  const { addItem } = useCart()
  const router = useRouter()
  const [isAddingToCart, setIsAddingToCart] = useState(false)
  const [isBuyingNow, setIsBuyingNow] = useState(false)

  // Get model price
  const getModelPrice = (modelId: string): number => {
    switch (modelId) {
      case "round-neck":
        return 25
      case "v-neck":
        return 28
      case "full-sleeve":
        return 32
      case "crop-top":
        return 30
      default:
        return 25
    }
  }

  // Create a unique ID for this custom design
  const getDesignId = () => `custom-${Date.now()}`

  const handleAddToCart = async () => {
    if (!hasDesign) return

    setIsAddingToCart(true)
    const designId = getDesignId()

    // Add to cart
    setTimeout(() => {
      addItem({
        id: designId,
        model: designState.model,
        side: designState.side,
        tshirtColor: designState.tshirtColor,
        tshirtSize: designState.tshirtSize,
        quantity: 1,
        price: getModelPrice(designState.model),
        name: `Custom ${designState.model.replace("-", " ")} T-Shirt`,
        image: "/temp-tshirt.jpg",
        isCustom: true,
        designData: {
          image: designState.image || "",
          position: designState.position,
          scale: designState.scale,
          rotation: designState.rotation,
        },
      })

      setIsAddingToCart(false)
    }, 500)
  }

  const handleBuyNow = async () => {
    if (!hasDesign) return

    setIsBuyingNow(true)
    const designId = getDesignId()

    // Add to cart
    setTimeout(() => {
      addItem({
        id: designId,
        model: designState.model,
        side: designState.side,
        tshirtColor: designState.tshirtColor,
        tshirtSize: designState.tshirtSize,
        quantity: 1,
        price: getModelPrice(designState.model),
        name: `Custom ${designState.model.replace("-", " ")} T-Shirt`,
        image: "/temp-tshirt.jpg",
        isCustom: true,
        designData: {
          image: designState.image || "",
          position: designState.position,
          scale: designState.scale,
          rotation: designState.rotation,
        },
      })

      // Navigate to checkout
      router.push("/checkout")
      setIsBuyingNow(false)
    }, 500)
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Button
            className="w-full h-12 touch-manipulation"
            size="lg"
            onClick={handleAddToCart}
            disabled={!hasDesign || isLoading || isAddingToCart || isBuyingNow}
          >
            {isAddingToCart ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Adding...
              </>
            ) : (
              <>
                <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
              </>
            )}
          </Button>
          <Button
            className="w-full h-12 touch-manipulation"
            size="lg"
            variant="secondary"
            onClick={handleBuyNow}
            disabled={!hasDesign || isLoading || isAddingToCart || isBuyingNow}
          >
            {isBuyingNow ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
              </>
            ) : (
              "Buy Now"
            )}
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <Button
            variant="outline"
            onClick={onResetDesign}
            disabled={!hasDesign || isLoading || isAddingToCart || isBuyingNow}
          >
            <RefreshCw className="mr-2 h-4 w-4" /> Reset Design
          </Button>
          <Button
            variant="outline"
            onClick={onDownloadPreview}
            disabled={!hasDesign || isLoading || isAddingToCart || isBuyingNow}
          >
            <Download className="mr-2 h-4 w-4" /> Download Preview
          </Button>
        </div>
      </div>
    </div>
  )
}
