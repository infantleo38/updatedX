-- Create a function to create the user_activities table if it doesn't exist
CREATE OR REPLACE FUNCTION create_activity_table()
RETURNS void AS $$
BEGIN
  -- Check if the table exists
  IF NOT EXISTS (
    SELECT FROM information_schema.tables 
    WHERE table_schema = 'public' 
    AND table_name = 'user_activities'
  ) THEN
    -- Create the table
    CREATE TABLE public.user_activities (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id UUID,
      session_id TEXT NOT NULL,
      activity_type TEXT NOT NULL,
      page TEXT,
      duration INTEGER,
      ip_address TEXT,
      user_agent TEXT,
      device_type TEXT,
      referrer TEXT,
      metadata JSONB DEFAULT '{}'::jsonb,
      timestamp TIMESTAMPTZ DEFAULT NOW()
    );

    -- Create indexes for better performance
    CREATE INDEX idx_user_activities_user_id ON public.user_activities(user_id);
    CREATE INDEX idx_user_activities_session_id ON public.user_activities(session_id);
    CREATE INDEX idx_user_activities_activity_type ON public.user_activities(activity_type);
    CREATE INDEX idx_user_activities_timestamp ON public.user_activities(timestamp);
    
    -- Create the search_queries table if it doesn't exist
    IF NOT EXISTS (
      SELECT FROM information_schema.tables 
      WHERE table_schema = 'public' 
      AND table_name = 'search_queries'
    ) THEN
      CREATE TABLE public.search_queries (
        id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID,
        session_id TEXT NOT NULL,
        query TEXT NOT NULL,
        results_count INTEGER DEFAULT 0,
        timestamp TIMESTAMPTZ DEFAULT NOW()
      );
      
      CREATE INDEX idx_search_queries_query ON public.search_queries(query);
      CREATE INDEX idx_search_queries_timestamp ON public.search_queries(timestamp);
    END IF;
  END IF;
END;
$$ LANGUAGE plpgsql;
