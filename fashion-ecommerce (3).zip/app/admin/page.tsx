import Link from "next/link"
import { ArrowRight, ArrowUpRight, DollarSign, Package, Palette, ShoppingBag, Users } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { SalesChart } from "@/components/admin/charts"
import { RecentOrdersTable } from "@/components/admin/tables"
import { getDashboardStats } from "../actions/admin-actions"

export default async function AdminDashboard() {
  const { usersCount, ordersCount, pendingOrdersCount, monthlyRevenue, recentOrders, salesChartData, error } =
    await getDashboardStats()

  // Mock data for custom designs (would need a designs table)
  const customDesignsCount = 42

  if (error) {
    return (
      <div className="p-6">
        <h1 className="text-2xl font-bold mb-4">Error Loading Dashboard</h1>
        <p className="text-red-500">{error}</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your store's performance and recent activity</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{usersCount}</div>
            <p className="text-xs text-muted-foreground">+12% from last month</p>
          </CardContent>
          <CardFooter>
            <Link href="/admin/users" className="text-xs text-muted-foreground flex items-center">
              View all users
              <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{ordersCount}</div>
            <p className="text-xs text-muted-foreground">+8% from last month</p>
          </CardContent>
          <CardFooter>
            <Link href="/admin/orders" className="text-xs text-muted-foreground flex items-center">
              View all orders
              <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Orders</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingOrdersCount}</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
          <CardFooter>
            <Link href="/admin/shipping" className="text-xs text-muted-foreground flex items-center">
              Process orders
              <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenue This Month</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${monthlyRevenue.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">+15% from last month</p>
          </CardContent>
          <CardFooter>
            <Link href="/admin/analytics" className="text-xs text-muted-foreground flex items-center">
              View analytics
              <ArrowRight className="ml-1 h-3 w-3" />
            </Link>
          </CardFooter>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Sales Trend</CardTitle>
            <CardDescription>Daily sales for the past 30 days</CardDescription>
          </CardHeader>
          <CardContent>
            <SalesChart data={salesChartData} />
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Custom Designs</CardTitle>
              <CardDescription>Overview of custom design orders</CardDescription>
            </div>
            <Palette className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{customDesignsCount}</div>
            <p className="text-sm text-muted-foreground mt-2">Total custom designs created by users</p>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="rounded-md border p-3">
                <div className="text-sm font-medium">Most Popular</div>
                <div className="mt-1 text-2xl font-bold">V-Neck</div>
                <div className="text-xs text-muted-foreground">42% of designs</div>
              </div>
              <div className="rounded-md border p-3">
                <div className="text-sm font-medium">Trending</div>
                <div className="mt-1 text-2xl font-bold">Full Sleeve</div>
                <div className="text-xs text-muted-foreground">+28% this week</div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Link href="/admin/customizations" className="text-sm text-muted-foreground flex items-center">
              View all custom designs
              <ArrowUpRight className="ml-1 h-4 w-4" />
            </Link>
          </CardFooter>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>Latest 5 orders placed on your store</CardDescription>
        </CardHeader>
        <CardContent>
          <RecentOrdersTable orders={recentOrders} />
        </CardContent>
        <CardFooter className="flex justify-end">
          <Link href="/admin/orders" className="text-sm text-muted-foreground flex items-center">
            View all orders
            <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
