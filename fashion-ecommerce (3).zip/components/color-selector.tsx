"use client"

import { Check } from "lucide-react"

interface Color {
  name: string
  value: string
}

interface ColorSelectorProps {
  colors: Color[]
  activeColor: Color
  onChange: (color: Color) => void
}

export default function ColorSelector({ colors, activeColor, onChange }: ColorSelectorProps) {
  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm font-medium mr-2">Color:</span>
      <div className="flex space-x-1">
        {colors.map((color) => (
          <button
            key={color.value}
            className={`w-8 h-8 rounded-full flex items-center justify-center ${
              color.value === "#FFFFFF" ? "border border-gray-200" : ""
            } ${activeColor.value === color.value ? "ring-2 ring-primary ring-offset-2" : ""}`}
            style={{ backgroundColor: color.value }}
            onClick={() => onChange(color)}
            title={color.name}
          >
            {activeColor.value === color.value && color.value === "#FFFFFF" && <Check className="h-4 w-4 text-black" />}
            {activeColor.value === color.value && color.value !== "#FFFFFF" && <Check className="h-4 w-4 text-white" />}
          </button>
        ))}
      </div>
    </div>
  )
}
