"use server"

import { createClient } from "@supabase/supabase-js"
import { revalidatePath } from "next/cache"
import type { User } from "@/lib/types"
import { getCurrentUserId } from "@/lib/auth"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

export async function getCurrentUser(): Promise<User | null> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      console.error("No user ID found")
      return null
    }

    const { data, error } = await supabase.from("users").select("*").eq("id", userId).single()

    if (error) {
      console.error("Error fetching user:", error)
      return null
    }

    return {
      id: data.id,
      name: data.name,
      email: data.email,
      phone: data.phone || "",
      avatar: data.avatar_url || "",
      createdAt: data.created_at,
    }
  } catch (error) {
    console.error("Error in getCurrentUser:", error)
    return null
  }
}

export async function updateUserProfile(userData: Partial<User>): Promise<{ success: boolean; error?: string }> {
  try {
    const userId = await getCurrentUserId()

    if (!userId) {
      return { success: false, error: "User not found" }
    }

    const { error } = await supabase
      .from("users")
      .update({
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        avatar_url: userData.avatar,
        updated_at: new Date().toISOString(),
      })
      .eq("id", userId)

    if (error) {
      console.error("Error updating user:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/account")
    return { success: true }
  } catch (error) {
    console.error("Error in updateUserProfile:", error)
    return { success: false, error: "Failed to update profile" }
  }
}
