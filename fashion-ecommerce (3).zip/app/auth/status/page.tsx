"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { useAuth } from "@/app/context/auth-context"

export default function AuthStatusPage() {
  const { user, isLoading, logout } = useAuth()
  const router = useRouter()
  const [localStorageUser, setLocalStorageUser] = useState<string | null>(null)

  useEffect(() => {
    // Check localStorage directly
    const storedUser = localStorage.getItem("user")
    setLocalStorageUser(storedUser)
  }, [])

  if (isLoading) {
    return (
      <div className="flex min-h-[80vh] items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Authentication Status</CardTitle>
            <CardDescription>Loading authentication status...</CardDescription>
          </CardHeader>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex min-h-[80vh] items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Authentication Status</CardTitle>
          <CardDescription>Current authentication information</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="text-lg font-medium">Auth Context</h3>
            <pre className="mt-2 rounded-md bg-muted p-4 overflow-auto text-xs">
              {JSON.stringify(user, null, 2) || "Not authenticated"}
            </pre>
          </div>

          <div>
            <h3 className="text-lg font-medium">Local Storage</h3>
            <pre className="mt-2 rounded-md bg-muted p-4 overflow-auto text-xs">
              {localStorageUser || "No user in localStorage"}
            </pre>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col space-y-2">
          {user ? (
            <Button onClick={logout} className="w-full">
              Logout
            </Button>
          ) : (
            <Button onClick={() => router.push("/auth/db-login")} className="w-full">
              Go to Login
            </Button>
          )}
          <Button variant="outline" onClick={() => router.push("/")} className="w-full">
            Go to Home
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
