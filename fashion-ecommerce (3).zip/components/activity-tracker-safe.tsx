"use client"

import { useEffect, useState } from "react"
import { usePathname } from "next/navigation"
import { v4 as uuidv4 } from "uuid"

export function ActivityTrackerSafe() {
  const pathname = usePathname()
  const [sessionId, setSessionId] = useState<string>("")

  // Initialize session ID
  useEffect(() => {
    // Try to get existing session ID from localStorage
    let existingSessionId = localStorage.getItem("session_id")

    // If no session ID exists, create a new one
    if (!existingSessionId) {
      existingSessionId = uuidv4()
      localStorage.setItem("session_id", existingSessionId)
    }

    setSessionId(existingSessionId)
  }, [])

  // Track page views
  useEffect(() => {
    // Skip if no session ID yet or if on admin pages
    if (!sessionId || pathname.startsWith("/admin")) return

    // Simple client-side tracking
    const trackPageView = async () => {
      try {
        await fetch("/api/track", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            sessionId,
            activityType: "page_view",
            page: pathname,
            referrer: document.referrer || "direct",
            userAgent: navigator.userAgent,
            timestamp: new Date().toISOString(),
          }),
        })
      } catch (error) {
        // Silently fail - tracking should not affect user experience
        console.error("Tracking failed:", error)
      }
    }

    trackPageView()
  }, [pathname, sessionId])

  // This component doesn't render anything
  return null
}
