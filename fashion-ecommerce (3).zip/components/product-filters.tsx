"use client"

import { useState } from "react"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface ProductFiltersProps {
  category: string
}

export function ProductFilters({ category }: ProductFiltersProps) {
  const [priceRange, setPriceRange] = useState([0, 200])

  // Define subcategories based on the main category
  const subcategories =
    {
      Men: ["T-Shirts", "Shirts", "Jeans", "Trousers", "Jackets", "Activewear", "Accessories"],
      Women: ["Dresses", "Tops", "Skirts", "Jeans", "Activewear", "Shoes", "Bags", "Jewelry"],
      Kids: ["Boys", "Girls", "Infants", "School Wear", "Shoes", "Accessories"],
    }[category] || []

  // Define colors
  const colors = ["Black", "White", "Blue", "Red", "Green", "Yellow", "Pink", "Purple", "Brown", "Gray"]

  // Define sizes
  const sizes =
    {
      Men: ["XS", "S", "M", "L", "XL", "XXL"],
      Women: ["XS", "S", "M", "L", "XL"],
      Kids: ["2T", "3T", "4T", "5", "6", "7", "8", "10", "12", "14"],
    }[category] || []

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Filters</h3>
        <Button variant="outline" size="sm" className="w-full">
          Clear All
        </Button>
      </div>

      <Accordion type="multiple" defaultValue={["subcategory", "price", "color", "size"]}>
        <AccordionItem value="subcategory">
          <AccordionTrigger>Subcategory</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {subcategories.map((subcategory) => (
                <div key={subcategory} className="flex items-center space-x-2">
                  <Checkbox id={`subcategory-${subcategory}`} />
                  <label
                    htmlFor={`subcategory-${subcategory}`}
                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {subcategory}
                  </label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4">
              <Slider defaultValue={[0, 200]} max={500} step={10} value={priceRange} onValueChange={setPriceRange} />
              <div className="flex items-center justify-between">
                <span className="text-sm">${priceRange[0]}</span>
                <span className="text-sm">${priceRange[1]}</span>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="color">
          <AccordionTrigger>Color</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2">
              {colors.map((color) => (
                <div key={color} className="flex items-center space-x-2">
                  <Checkbox id={`color-${color}`} />
                  <label
                    htmlFor={`color-${color}`}
                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    {color}
                  </label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="size">
          <AccordionTrigger>Size</AccordionTrigger>
          <AccordionContent>
            <div className="flex flex-wrap gap-2">
              {sizes.map((size) => (
                <div key={size} className="border rounded px-3 py-1 text-sm cursor-pointer hover:bg-muted">
                  {size}
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Button className="w-full">Apply Filters</Button>
    </div>
  )
}
