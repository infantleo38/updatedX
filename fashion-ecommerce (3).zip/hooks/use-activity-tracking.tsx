"use client"

import { useEffect, useCallback } from "react"
import { usePathname, useSearchParams } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import {
  recordPageView,
  recordProductView,
  recordAddToCart,
  recordSearchQuery,
  recordCheckout,
  recordCustomization,
} from "@/app/actions/activity-actions"

export function useActivityTracking() {
  const pathname = usePathname()
  const searchParams = useSearchParams()
  const { user } = useAuth()

  // Track page views
  useEffect(() => {
    // Don't track admin pages
    if (pathname.startsWith("/admin")) return

    const referrer = document.referrer
    const userAgent = navigator.userAgent

    recordPageView({
      userId: user?.id,
      page: pathname,
      referrer,
      userAgent,
    })
  }, [pathname, user?.id])

  // Track product views
  const trackProductView = useCallback(
    (productId: string, productName: string) => {
      recordProductView({
        userId: user?.id,
        productId,
        productName,
        userAgent: navigator.userAgent,
      })
    },
    [user?.id],
  )

  // Track add to cart
  const trackAddToCart = useCallback(
    (productId: string, productName: string, quantity: number, price: number) => {
      recordAddToCart({
        userId: user?.id,
        productId,
        productName,
        quantity,
        price,
        userAgent: navigator.userAgent,
      })
    },
    [user?.id],
  )

  // Track search queries
  const trackSearchQuery = useCallback(
    (query: string, resultsCount: number) => {
      recordSearchQuery({
        userId: user?.id,
        query,
        resultsCount,
        userAgent: navigator.userAgent,
      })
    },
    [user?.id],
  )

  // Track checkout
  const trackCheckout = useCallback(
    (orderId: string, totalAmount: number, itemCount: number) => {
      recordCheckout({
        userId: user?.id,
        orderId,
        totalAmount,
        itemCount,
        userAgent: navigator.userAgent,
      })
    },
    [user?.id],
  )

  // Track t-shirt customization
  const trackCustomization = useCallback(
    (data: {
      designId?: string
      tshirtModel: string
      duration: number
      saved: boolean
    }) => {
      recordCustomization({
        userId: user?.id,
        designId: data.designId,
        tshirtModel: data.tshirtModel,
        duration: data.duration,
        saved: data.saved,
        userAgent: navigator.userAgent,
      })
    },
    [user?.id],
  )

  // Track search queries from URL
  useEffect(() => {
    const query = searchParams.get("q")
    if (query && pathname === "/search") {
      // Assuming you have a way to know the results count
      // For now, we'll use a placeholder
      const resultsCount = 0 // Replace with actual results count
      trackSearchQuery(query, resultsCount)
    }
  }, [pathname, searchParams, trackSearchQuery])

  return {
    trackProductView,
    trackAddToCart,
    trackSearchQuery,
    trackCheckout,
    trackCustomization,
  }
}
