"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Menu, Search, User, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { CartIcon } from "./cart-icon"
import { useAuth } from "@/contexts/auth-context"

export default function Header() {
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const pathname = usePathname()

  // Initialize auth state with default values
  const auth = useAuth()
  const user = auth.user
  const isAdmin = auth.isAdmin
  const signOut = auth.signOut
  const isLoading = auth.isLoading

  // Check if the current path is an admin route
  const isAdminRoute = pathname?.startsWith("/admin")

  // Don't show the regular header on admin routes
  if (isAdminRoute) {
    return null
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] sm:w-[400px]">
            <nav className="flex flex-col gap-4">
              <Link href="/" className="text-lg font-medium transition-colors hover:text-primary">
                Home
              </Link>
              <Link href="/categories/men" className="text-lg font-medium transition-colors hover:text-primary">
                Men
              </Link>
              <Link href="/categories/women" className="text-lg font-medium transition-colors hover:text-primary">
                Women
              </Link>
              <Link href="/categories/kids" className="text-lg font-medium transition-colors hover:text-primary">
                Kids
              </Link>
              <Link href="/customize" className="text-lg font-medium transition-colors hover:text-primary">
                Customize
              </Link>
              {isAdmin && (
                <Link href="/admin" className="text-lg font-medium transition-colors hover:text-primary">
                  Admin Dashboard
                </Link>
              )}
            </nav>
          </SheetContent>
        </Sheet>

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 md:mr-6">
          <span className="text-xl font-bold">Xillusions</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <Link href="/" className="font-medium transition-colors hover:text-primary">
            Home
          </Link>
          <Link href="/categories/men" className="font-medium transition-colors hover:text-primary">
            Men
          </Link>
          <Link href="/categories/women" className="font-medium transition-colors hover:text-primary">
            Women
          </Link>
          <Link href="/categories/kids" className="font-medium transition-colors hover:text-primary">
            Kids
          </Link>
          <Link href="/customize" className="font-medium transition-colors hover:text-primary">
            Customize
          </Link>
          {isAdmin && (
            <Link href="/admin" className="font-medium transition-colors hover:text-primary">
              Admin Dashboard
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-2">
          {/* Search */}
          {isSearchOpen ? (
            <div className="flex items-center gap-2">
              <Input type="search" placeholder="Search..." className="w-[200px] md:w-[300px]" />
              <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(false)}>
                <X className="h-5 w-5" />
                <span className="sr-only">Close search</span>
              </Button>
            </div>
          ) : (
            <Button variant="ghost" size="icon" onClick={() => setIsSearchOpen(true)}>
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
          )}

          {/* User Menu */}
          {!isLoading && (
            <>
              {user ? (
                <div className="relative group">
                  <Button variant="ghost" size="icon" asChild>
                    <Link href="/account">
                      <User className="h-5 w-5" />
                      <span className="sr-only">Account</span>
                    </Link>
                  </Button>
                  <div className="absolute right-0 mt-2 w-48 bg-background rounded-md shadow-lg border overflow-hidden z-50 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300">
                    <div className="py-2 px-4 border-b">
                      <p className="text-sm font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                    <div className="py-1">
                      <Link href="/account" className="block px-4 py-2 text-sm hover:bg-muted">
                        My Account
                      </Link>
                      <Link href="/orders" className="block px-4 py-2 text-sm hover:bg-muted">
                        My Orders
                      </Link>
                      {isAdmin && (
                        <Link href="/admin" className="block px-4 py-2 text-sm hover:bg-muted">
                          Admin Dashboard
                        </Link>
                      )}
                      <button
                        onClick={() => signOut()}
                        className="block w-full text-left px-4 py-2 text-sm hover:bg-muted text-red-500"
                      >
                        Sign Out
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <Button variant="ghost" size="icon" asChild>
                  <Link href="/auth/login">
                    <User className="h-5 w-5" />
                    <span className="sr-only">Sign in</span>
                  </Link>
                </Button>
              )}
            </>
          )}

          {/* Cart - Use CartIcon directly without wrapping it in another Link */}
          <CartIcon />
        </div>
      </div>
    </header>
  )
}
