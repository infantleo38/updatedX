"use client"

import type React from "react"

import { ToastProvider } from "@/hooks/use-toast"

export default function CustomizeLayout({ children }: { children: React.ReactNode }) {
  return <ToastProvider>{children}</ToastProvider>
}
