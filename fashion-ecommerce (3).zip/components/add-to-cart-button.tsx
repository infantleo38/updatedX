"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Minus, Plus } from "lucide-react"
import type { Product } from "@/lib/types"
import { useCart } from "@/contexts/cart-context"
import { useRouter } from "next/navigation"
import { useActivityTracking } from "@/hooks/use-activity-tracking"

interface AddToCartButtonProps {
  product: Product
}

export default function AddToCartButton({ product }: AddToCartButtonProps) {
  const router = useRouter()
  const { addItem } = useCart()
  const [quantity, setQuantity] = useState(1)
  const [isAdding, setIsAdding] = useState(false)
  const { trackAddToCart } = useActivityTracking()

  const incrementQuantity = () => {
    if (quantity < (product.stock || 10)) {
      setQuantity(quantity + 1)
    }
  }

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const handleAddToCart = () => {
    setIsAdding(true)

    // Add item to cart
    addItem({
      id: product.id,
      name: product.name,
      model: "standard", // Default model for regular products
      side: "front",
      tshirtColor: "N/A",
      tshirtSize: "M", // Default size
      quantity,
      price: product.price,
      image: product.image,
      isCustom: false,
    })

    trackAddToCart(product.id, product.name, quantity, product.price)

    // Reset state
    setTimeout(() => {
      setIsAdding(false)
      setQuantity(1)
    }, 500)
  }

  const handleBuyNow = () => {
    handleAddToCart()
    router.push("/cart")
  }

  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="quantity" className="text-sm font-medium">
          Quantity
        </label>
        <div className="mt-2 flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            className="h-10 w-10 rounded-md"
            onClick={decrementQuantity}
            disabled={quantity <= 1 || isAdding}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="w-12 text-center">{quantity}</span>
          <Button
            variant="outline"
            size="icon"
            className="h-10 w-10 rounded-md"
            onClick={incrementQuantity}
            disabled={quantity >= (product.stock || 10) || isAdding}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <Button size="lg" className="flex-1" onClick={handleAddToCart} disabled={isAdding}>
          {isAdding ? "Adding..." : "Add to Cart"}
        </Button>
        <Button size="lg" variant="secondary" className="flex-1" onClick={handleBuyNow} disabled={isAdding}>
          Buy Now
        </Button>
      </div>
    </div>
  )
}
