"use server"

import { createClient } from "@supabase/supabase-js"
import { revalidatePath } from "next/cache"

// Initialize Supabase client - server-side only
const supabaseUrl = process.env.SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient(supabaseUrl, supabaseKey)

// User Management Actions
export async function getUsers(searchTerm = "", page = 1, limit = 10) {
  try {
    let query = supabase.from("users").select("*", { count: "exact" })

    if (searchTerm) {
      query = query.or(`name.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%`)
    }

    const { data, count, error } = await query
      .order("created_at", { ascending: false })
      .range((page - 1) * limit, page * limit - 1)

    if (error) {
      console.error("Error fetching users:", error)
      return { data: [], count: 0, error: error.message }
    }

    return { data, count, error: null }
  } catch (error) {
    console.error("Error in getUsers:", error)
    return { data: [], count: 0, error: "Failed to fetch users" }
  }
}

export async function getUserById(userId: string) {
  try {
    const { data, error } = await supabase
      .from("users")
      .select(`
        *,
        addresses(*),
        orders(*)
      `)
      .eq("id", userId)
      .single()

    if (error) {
      console.error("Error fetching user:", error)
      return { data: null, error: error.message }
    }

    return { data, error: null }
  } catch (error) {
    console.error("Error in getUserById:", error)
    return { data: null, error: "Failed to fetch user" }
  }
}

export async function updateUser(userId: string, userData: any) {
  try {
    const { error } = await supabase
      .from("users")
      .update({
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        avatar_url: userData.avatar_url,
        updated_at: new Date().toISOString(),
      })
      .eq("id", userId)

    if (error) {
      console.error("Error updating user:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/users")
    return { success: true, error: null }
  } catch (error) {
    console.error("Error in updateUser:", error)
    return { success: false, error: "Failed to update user" }
  }
}

export async function deleteUser(userId: string) {
  try {
    // First delete related records
    await supabase.from("addresses").delete().eq("user_id", userId)

    // Then delete the user
    const { error } = await supabase.from("users").delete().eq("id", userId)

    if (error) {
      console.error("Error deleting user:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/users")
    return { success: true, error: null }
  } catch (error) {
    console.error("Error in deleteUser:", error)
    return { success: false, error: "Failed to delete user" }
  }
}

// Order Management Actions
export async function getOrders(searchTerm = "", status = "all", page = 1, limit = 10) {
  try {
    let query = supabase.from("orders").select(
      `
      *,
      users (
        name,
        email
      )
    `,
      { count: "exact" },
    )

    if (searchTerm) {
      query = query.or(`id.ilike.%${searchTerm}%,users.name.ilike.%${searchTerm}%,users.email.ilike.%${searchTerm}%`)
    }

    if (status !== "all") {
      query = query.eq("status", status)
    }

    const { data, count, error } = await query
      .order("created_at", { ascending: false })
      .range((page - 1) * limit, page * limit - 1)

    if (error) {
      console.error("Error fetching orders:", error)
      return { data: [], count: 0, error: error.message }
    }

    return { data, count, error: null }
  } catch (error) {
    console.error("Error in getOrders:", error)
    return { data: [], count: 0, error: "Failed to fetch orders" }
  }
}

export async function getOrderById(orderId: string) {
  try {
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select(`
        *,
        users (
          id,
          name,
          email,
          phone
        )
      `)
      .eq("id", orderId)
      .single()

    if (orderError) {
      console.error("Error fetching order:", orderError)
      return { data: null, error: orderError.message }
    }

    const { data: items, error: itemsError } = await supabase.from("order_items").select("*").eq("order_id", orderId)

    if (itemsError) {
      console.error("Error fetching order items:", itemsError)
      return { data: { ...order, items: [] }, error: itemsError.message }
    }

    return { data: { ...order, items }, error: null }
  } catch (error) {
    console.error("Error in getOrderById:", error)
    return { data: null, error: "Failed to fetch order" }
  }
}

export async function updateOrderStatus(orderId: string, status: string) {
  try {
    const { error } = await supabase
      .from("orders")
      .update({
        status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", orderId)

    if (error) {
      console.error("Error updating order status:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/orders")
    revalidatePath(`/admin/orders/${orderId}`)
    return { success: true, error: null }
  } catch (error) {
    console.error("Error in updateOrderStatus:", error)
    return { success: false, error: "Failed to update order status" }
  }
}

export async function updateOrderTracking(orderId: string, trackingNumber: string, carrier: string) {
  try {
    const { error } = await supabase
      .from("orders")
      .update({
        tracking_number: trackingNumber,
        carrier,
        updated_at: new Date().toISOString(),
      })
      .eq("id", orderId)

    if (error) {
      console.error("Error updating order tracking:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/orders")
    revalidatePath(`/admin/orders/${orderId}`)
    return { success: true, error: null }
  } catch (error) {
    console.error("Error in updateOrderTracking:", error)
    return { success: false, error: "Failed to update order tracking" }
  }
}

// Dashboard Analytics Actions
export async function getDashboardStats() {
  try {
    // Get total users count
    const { count: usersCount, error: usersError } = await supabase
      .from("users")
      .select("*", { count: "exact", head: true })

    if (usersError) {
      console.error("Error fetching users count:", usersError)
      return { error: usersError.message }
    }

    // Get total orders count
    const { count: ordersCount, error: ordersError } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })

    if (ordersError) {
      console.error("Error fetching orders count:", ordersError)
      return { error: ordersError.message }
    }

    // Get pending orders count
    const { count: pendingOrdersCount, error: pendingError } = await supabase
      .from("orders")
      .select("*", { count: "exact", head: true })
      .eq("status", "Processing")

    if (pendingError) {
      console.error("Error fetching pending orders count:", pendingError)
      return { error: pendingError.message }
    }

    // Get revenue this month
    const startOfMonth = new Date()
    startOfMonth.setDate(1)
    startOfMonth.setHours(0, 0, 0, 0)

    const { data: monthlyOrders, error: revenueError } = await supabase
      .from("orders")
      .select("total")
      .gte("created_at", startOfMonth.toISOString())

    if (revenueError) {
      console.error("Error fetching monthly revenue:", revenueError)
      return { error: revenueError.message }
    }

    const monthlyRevenue = monthlyOrders?.reduce((sum, order) => sum + Number(order.total), 0) || 0

    // Get recent orders
    const { data: recentOrders, error: recentError } = await supabase
      .from("orders")
      .select(`
        id,
        total,
        status,
        created_at,
        users (
          name,
          email
        )
      `)
      .order("created_at", { ascending: false })
      .limit(5)

    if (recentError) {
      console.error("Error fetching recent orders:", recentError)
      return { error: recentError.message }
    }

    // Get sales data for chart
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const { data: salesData, error: salesError } = await supabase
      .from("orders")
      .select("created_at, total")
      .gte("created_at", thirtyDaysAgo.toISOString())
      .order("created_at", { ascending: true })

    if (salesError) {
      console.error("Error fetching sales data:", salesError)
      return { error: salesError.message }
    }

    // Process sales data for chart
    const dailySales = salesData?.reduce((acc: Record<string, number>, order) => {
      const date = new Date(order.created_at).toISOString().split("T")[0]
      acc[date] = (acc[date] || 0) + Number(order.total)
      return acc
    }, {})

    const chartData = Object.entries(dailySales || {}).map(([date, total]) => ({
      date,
      total,
    }))

    return {
      usersCount: usersCount || 0,
      ordersCount: ordersCount || 0,
      pendingOrdersCount: pendingOrdersCount || 0,
      monthlyRevenue,
      recentOrders: recentOrders || [],
      salesChartData: chartData,
      error: null,
    }
  } catch (error) {
    console.error("Error in getDashboardStats:", error)
    return { error: "Failed to fetch dashboard stats" }
  }
}

// Shipping & Packing Actions
export async function getPendingOrders() {
  try {
    const { data, error } = await supabase
      .from("orders")
      .select(`
        id,
        created_at,
        status,
        users (
          name,
          email
        ),
        order_items (*)
      `)
      .eq("status", "Processing")
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching pending orders:", error)
      return { data: [], error: error.message }
    }

    return { data, error: null }
  } catch (error) {
    console.error("Error in getPendingOrders:", error)
    return { data: [], error: "Failed to fetch pending orders" }
  }
}

export async function markOrderAsPacked(orderId: string) {
  try {
    const { error } = await supabase
      .from("orders")
      .update({
        status: "Shipped",
        updated_at: new Date().toISOString(),
      })
      .eq("id", orderId)

    if (error) {
      console.error("Error marking order as packed:", error)
      return { success: false, error: error.message }
    }

    revalidatePath("/admin/shipping")
    revalidatePath("/admin/orders")
    return { success: true, error: null }
  } catch (error) {
    console.error("Error in markOrderAsPacked:", error)
    return { success: false, error: "Failed to mark order as packed" }
  }
}
