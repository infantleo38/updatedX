"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, Download, Eye, MoreHorizontal, Truck, Printer, AlertCircle } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Sample data
const orders = [
  {
    id: "XL2023512",
    customer: "John Doe",
    email: "john.doe@example.com",
    date: "2023-06-12T09:45:00",
    amount: 129.99,
    status: "Processing",
    paymentStatus: "Paid",
    items: 3,
    trackingNumber: "",
    carrier: "",
  },
  {
    id: "XL2023498",
    customer: "Jane Smith",
    email: "jane.smith@example.com",
    date: "2023-06-11T14:30:00",
    amount: 79.95,
    status: "Shipped",
    paymentStatus: "Paid",
    items: 2,
    trackingNumber: "1Z999AA10123456784",
    carrier: "UPS",
  },
  {
    id: "XL2023487",
    customer: "Robert Johnson",
    email: "robert.j@example.com",
    date: "2023-06-10T11:20:00",
    amount: 199.99,
    status: "Delivered",
    paymentStatus: "Paid",
    items: 1,
    trackingNumber: "1Z999AA10123456785",
    carrier: "UPS",
  },
  {
    id: "XL2023476",
    customer: "Emily Wilson",
    email: "emily.w@example.com",
    date: "2023-06-09T16:15:00",
    amount: 149.95,
    status: "Processing",
    paymentStatus: "Paid",
    items: 4,
    trackingNumber: "",
    carrier: "",
  },
  {
    id: "XL2023465",
    customer: "Michael Brown",
    email: "michael.b@example.com",
    date: "2023-06-08T10:05:00",
    amount: 89.99,
    status: "Shipped",
    paymentStatus: "Paid",
    items: 2,
    trackingNumber: "1Z999AA10123456786",
    carrier: "FedEx",
  },
  {
    id: "XL2023454",
    customer: "Sarah Davis",
    email: "sarah.d@example.com",
    date: "2023-06-07T13:40:00",
    amount: 59.99,
    status: "Delivered",
    paymentStatus: "Paid",
    items: 1,
    trackingNumber: "1Z999AA10123456787",
    carrier: "USPS",
  },
  {
    id: "XL2023443",
    customer: "David Miller",
    email: "david.m@example.com",
    date: "2023-06-06T09:20:00",
    amount: 109.95,
    status: "Processing",
    paymentStatus: "Pending",
    items: 3,
    trackingNumber: "",
    carrier: "",
  },
]

// Status badge component
function OrderStatusBadge({ status }: { status: string }) {
  let variant: "default" | "secondary" | "outline" | "destructive" = "outline"

  switch (status) {
    case "Processing":
      variant = "secondary"
      break
    case "Shipped":
      variant = "default"
      break
    case "Delivered":
      variant = "outline"
      break
    case "Cancelled":
      variant = "destructive"
      break
  }

  return <Badge variant={variant}>{status}</Badge>
}

// Payment status badge component
function PaymentStatusBadge({ status }: { status: string }) {
  let variant: "default" | "secondary" | "outline" | "destructive" = "outline"

  switch (status) {
    case "Paid":
      variant = "default"
      break
    case "Pending":
      variant = "secondary"
      break
    case "Failed":
      variant = "destructive"
      break
  }

  return <Badge variant={variant}>{status}</Badge>
}

export default function OrderManagementPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  // Filter orders based on search term and status
  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus = statusFilter === "all" || order.status.toLowerCase() === statusFilter.toLowerCase()

    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Order Management</h1>
          <p className="text-muted-foreground">View and manage customer orders</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="mr-2 h-4 w-4" />
            Export Orders
          </Button>
          <Button>
            <Printer className="mr-2 h-4 w-4" />
            Print Orders
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Orders</CardTitle>
          <CardDescription>View and manage all customer orders on your platform.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search orders..."
                className="pl-8 bg-white"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="shipped">Shipped</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" className="flex gap-2">
              <Filter className="h-4 w-4" />
              <span>More Filters</span>
            </Button>
          </div>

          <div className="rounded-md border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="hidden md:table-cell">Date</TableHead>
                  <TableHead className="hidden md:table-cell">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden md:table-cell">Payment</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.id}</TableCell>
                    <TableCell>
                      <div>
                        {order.customer}
                        <div className="text-xs text-muted-foreground">{order.email}</div>
                        <div className="md:hidden text-xs mt-1">{new Date(order.date).toLocaleDateString()}</div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">{new Date(order.date).toLocaleDateString()}</TableCell>
                    <TableCell className="hidden md:table-cell">${order.amount.toFixed(2)}</TableCell>
                    <TableCell>
                      <OrderStatusBadge status={order.status} />
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <PaymentStatusBadge status={order.paymentStatus} />
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <Eye className="mr-2 h-4 w-4" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Truck className="mr-2 h-4 w-4" />
                            Update Status
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Printer className="mr-2 h-4 w-4" />
                            Print Order
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-500">
                            <AlertCircle className="mr-2 h-4 w-4" />
                            Cancel Order
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-muted-foreground">
              Showing <strong>{filteredOrders.length}</strong> of <strong>{orders.length}</strong> orders
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="outline" size="sm">
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
