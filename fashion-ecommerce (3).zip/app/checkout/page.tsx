"use client"

import { useState } from "react"
import { Separator } from "@/components/ui/separator"
import Image from "next/image"
import { PaymentForm } from "@/components/payment-form"
import { OrderConfirmation } from "@/components/order-confirmation"
import { useCart } from "@/contexts/cart-context"
import { useActivityTracking } from "@/hooks/use-activity-tracking"

export default function CheckoutPage() {
  const [orderId, setOrderId] = useState<string | null>(null)
  const { items, subtotal, discount, shipping, tax, total } = useCart()
  const { trackCheckout } = useActivityTracking()

  const handleOrderSuccess = (newOrderId: string) => {
    setOrderId(newOrderId)
    trackCheckout(newOrderId, total, items.length)
  }

  if (orderId) {
    return <OrderConfirmation orderId={orderId} />
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <h1 className="text-3xl font-bold mb-8">Checkout</h1>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <PaymentForm onSuccess={handleOrderSuccess} />
        </div>

        {/* Order Summary */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
            <h2 className="text-xl font-bold mb-4">Order Summary</h2>

            <div className="space-y-4 mb-4">
              {items.map((item) => (
                <div key={item.id} className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-md relative mr-3">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        fill
                        className="object-contain p-1"
                      />
                    </div>
                    <div>
                      <p className="font-medium">{item.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Size: {item.tshirtSize} • Qty: {item.quantity}
                      </p>
                    </div>
                  </div>
                  <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
            </div>

            <Separator className="my-4" />

            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount</span>
                  <span>-${discount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span>${shipping.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span>${tax.toFixed(2)}</span>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="flex justify-between font-bold text-lg mb-4">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>

            <div className="text-xs text-center text-muted-foreground">
              <p>By placing your order, you agree to our Terms of Service and Privacy Policy</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
