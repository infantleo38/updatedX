"use client"

import type React from "react"

import { useRef } from "react"
import Image from "next/image"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useDraggable } from "@/hooks/use-draggable"
import type { DesignState } from "./t-shirt-customizer"

interface TShirtPreviewProps {
  designState: DesignState
  setDesignState: React.Dispatch<React.SetStateAction<DesignState>>
}

export function TShirtPreview({ designState, setDesignState }: TShirtPreviewProps) {
  const designRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLDivElement>(null)

  // Set up draggable functionality
  useDraggable(designRef, {
    onDrag: (deltaX, deltaY) => {
      setDesignState((prev) => ({
        ...prev,
        position: {
          x: prev.position.x + deltaX,
          y: prev.position.y + deltaY,
        },
      }))
    },
    bounds: canvasRef,
  })

  // Get model name for display
  const getModelDisplayName = () => {
    switch (designState.model) {
      case "round-neck":
        return "Round Neck"
      case "v-neck":
        return "V-Neck"
      case "full-sleeve":
        return "Full Sleeve"
      case "crop-top":
        return "Crop Top"
      default:
        return "T-Shirt"
    }
  }

  // Get design placement area dimensions based on model
  const getDesignAreaDimensions = () => {
    switch (designState.model) {
      case "crop-top":
        return { width: "35%", height: "30%" }
      case "full-sleeve":
        return { width: "25%", height: "25%" }
      case "v-neck":
        return { width: "40%", height: "40%" }
      case "round-neck":
      default:
        return { width: "40%", height: "40%" }
    }
  }

  // Using temporary T-shirt image for all models and views
  const getTshirtImageSrc = () => {
    return "/temp-tshirt.jpg"
  }

  const designAreaDimensions = getDesignAreaDimensions()

  return (
    <div>
      <div className="mb-4 text-center">
        <h3 className="text-lg font-medium">{getModelDisplayName()} Preview</h3>
        <p className="text-sm text-muted-foreground">Customize your design on the selected t-shirt model</p>
      </div>

      <Tabs
        defaultValue="front"
        value={designState.side}
        onValueChange={(value) => setDesignState((prev) => ({ ...prev, side: value as "front" | "back" }))}
      >
        <div className="flex justify-center mb-6">
          <TabsList>
            <TabsTrigger value="front">Front View</TabsTrigger>
            <TabsTrigger value="back">Back View</TabsTrigger>
          </TabsList>
        </div>

        <div className="relative aspect-[3/4] max-h-[600px] mx-auto">
          <TabsContent value="front" className="h-full">
            <div ref={canvasRef} className="relative w-full h-full">
              {/* T-shirt image */}
              <div className="relative w-full h-full">
                <Image
                  src={getTshirtImageSrc() || "/placeholder.svg"}
                  alt={`${getModelDisplayName()} front view`}
                  fill
                  className="object-contain"
                  style={{ filter: designState.tshirtColor !== "#FFFFFF" ? "brightness(0) saturate(100%)" : undefined }}
                />

                {/* Colored overlay for t-shirt */}
                {designState.tshirtColor !== "#FFFFFF" && (
                  <div
                    className="absolute inset-0"
                    style={{
                      backgroundColor: designState.tshirtColor,
                      mixBlendMode: "multiply",
                      opacity: 0.9,
                    }}
                  />
                )}

                {/* Design placement area */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div
                    className="absolute flex items-center justify-center"
                    style={{
                      width: designAreaDimensions.width,
                      height: designAreaDimensions.height,
                      border: designState.image ? "none" : "2px dashed #ccc",
                      borderRadius: "4px",
                      // Adjust vertical position based on model
                      transform: designState.model === "crop-top" ? "translateY(-15%)" : "translateY(0)",
                    }}
                  >
                    {/* Design image */}
                    {designState.image && (
                      <div
                        ref={designRef}
                        className="absolute cursor-move"
                        style={{
                          transform: `translate(${designState.position.x}px, ${designState.position.y}px) rotate(${designState.rotation}deg) scale(${designState.scale})`,
                          maxWidth: "100%",
                          maxHeight: "100%",
                          touchAction: "none",
                        }}
                      >
                        <Image
                          src={designState.image || "/placeholder.svg"}
                          alt="Custom design"
                          width={200}
                          height={200}
                          className="pointer-events-none max-w-full max-h-full object-contain"
                          style={{
                            filter: designState.tshirtColor === "#000000" ? "invert(1)" : undefined,
                          }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="back" className="h-full">
            <div ref={canvasRef} className="relative w-full h-full">
              {/* T-shirt image - using same image for back view temporarily */}
              <div className="relative w-full h-full">
                <Image
                  src={getTshirtImageSrc() || "/placeholder.svg"}
                  alt={`${getModelDisplayName()} back view`}
                  fill
                  className="object-contain"
                  style={{ filter: designState.tshirtColor !== "#FFFFFF" ? "brightness(0) saturate(100%)" : undefined }}
                />

                {/* Colored overlay for t-shirt */}
                {designState.tshirtColor !== "#FFFFFF" && (
                  <div
                    className="absolute inset-0"
                    style={{
                      backgroundColor: designState.tshirtColor,
                      mixBlendMode: "multiply",
                      opacity: 0.9,
                    }}
                  />
                )}

                {/* Design placement area */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div
                    className="absolute flex items-center justify-center"
                    style={{
                      width: designAreaDimensions.width,
                      height: designAreaDimensions.height,
                      border: designState.image ? "none" : "2px dashed #ccc",
                      borderRadius: "4px",
                      // Adjust vertical position based on model
                      transform: designState.model === "crop-top" ? "translateY(-15%)" : "translateY(0)",
                    }}
                  >
                    {/* Design image */}
                    {designState.image && (
                      <div
                        ref={designRef}
                        className="absolute cursor-move"
                        style={{
                          transform: `translate(${designState.position.x}px, ${designState.position.y}px) rotate(${designState.rotation}deg) scale(${designState.scale})`,
                          maxWidth: "100%",
                          maxHeight: "100%",
                          touchAction: "none",
                        }}
                      >
                        <Image
                          src={designState.image || "/placeholder.svg"}
                          alt="Custom design"
                          width={200}
                          height={200}
                          className="pointer-events-none max-w-full max-h-full object-contain"
                          style={{
                            filter: designState.tshirtColor === "#000000" ? "invert(1)" : undefined,
                          }}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </div>
      </Tabs>

      <div className="mt-4 text-center text-sm text-muted-foreground">
        <p>Drag to position your design • Use controls to resize and rotate</p>
      </div>
    </div>
  )
}
