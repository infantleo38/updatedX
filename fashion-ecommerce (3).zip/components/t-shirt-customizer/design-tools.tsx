"use client"

import type React from "react"

import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { RotateCw, RotateCcw, ZoomIn, ZoomOut } from "lucide-react"
import type { DesignState } from "./t-shirt-customizer"

interface DesignToolsProps {
  designState: DesignState
  setDesignState: React.Dispatch<React.SetStateAction<DesignState>>
}

export function DesignTools({ designState, setDesignState }: DesignToolsProps) {
  const handleScaleChange = (value: number[]) => {
    setDesignState((prev) => ({
      ...prev,
      scale: value[0],
    }))
  }

  const handleRotateLeft = () => {
    setDesignState((prev) => ({
      ...prev,
      rotation: prev.rotation - 15,
    }))
  }

  const handleRotateRight = () => {
    setDesignState((prev) => ({
      ...prev,
      rotation: prev.rotation + 15,
    }))
  }

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold mb-4">Adjust Your Design</h2>

      {/* Scale Control */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Size</span>
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDesignState((prev) => ({ ...prev, scale: Math.max(0.5, prev.scale - 0.1) }))}
            >
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setDesignState((prev) => ({ ...prev, scale: Math.min(2, prev.scale + 0.1) }))}
            >
              <ZoomIn className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <Slider value={[designState.scale]} min={0.5} max={2} step={0.01} onValueChange={handleScaleChange} />
      </div>

      {/* Rotation Control */}
      <div className="mb-2">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium">Rotation</span>
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={handleRotateLeft}>
              <RotateCcw className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleRotateRight}>
              <RotateCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="text-center text-sm text-muted-foreground">{designState.rotation}°</div>
      </div>
    </div>
  )
}
